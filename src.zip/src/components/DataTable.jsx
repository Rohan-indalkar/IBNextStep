import { useState } from 'react';
import { LoadingState, EmptyState } from './States';

function buildPageWindow(page, totalPages) {
  // 0-indexed page, totalPages count. Always show first, last, current ±1,
  // with ellipses for gaps — keeps the control usable even at 50+ pages.
  const pages = new Set([0, totalPages - 1, page, page - 1, page + 1]);
  return [...pages]
    .filter((p) => p >= 0 && p < totalPages)
    .sort((a, b) => a - b);
}

export default function DataTable({ columns, rows, loading, emptyLabel = 'No records found.', page = 0, totalPages = 0, onPageChange }) {
  const [jumpValue, setJumpValue] = useState('');

  function handleJump(e) {
    e.preventDefault();
    const target = Number(jumpValue) - 1;
    if (Number.isInteger(target) && target >= 0 && target < totalPages) {
      onPageChange(target);
    }
    setJumpValue('');
  }

  const pageWindow = totalPages > 1 ? buildPageWindow(page, totalPages) : [];

  return (
    <div className="card data-table" style={{ overflow: 'hidden' }}>
      {loading ? (
        <div style={{ padding: 20 }}>
          <LoadingState rows={4} />
        </div>
      ) : rows.length === 0 ? (
        <EmptyState title={emptyLabel} />
      ) : (
        <>
          {/* Desktop/tablet: real table */}
          <div className="data-table-scroll">
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 14 }}>
              <thead>
                <tr style={{ background: 'var(--color-surface-alt)' }}>
                  {columns.map((col) => (
                    <th
                      key={col.key}
                      style={{
                        textAlign: 'left',
                        padding: '12px 16px',
                        color: 'var(--color-text-muted)',
                        fontWeight: 600,
                        fontSize: 12,
                        textTransform: 'uppercase',
                        letterSpacing: '0.04em',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      {col.header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((row, i) => (
                  <tr key={row.id ?? i} style={{ borderTop: '1px solid var(--color-border)' }}>
                    {columns.map((col) => (
                      <td key={col.key} style={{ padding: '12px 16px', verticalAlign: 'middle' }}>
                        {col.render ? col.render(row) : row[col.key]}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile: stacked cards, same data/columns, no horizontal scroll */}
          <div className="data-table-cards">
            {rows.map((row, i) => (
              <div key={row.id ?? i} className="data-table-card">
                {columns
                  .filter((col) => col.header)
                  .map((col) => (
                    <div key={col.key} className="data-table-card-row">
                      <span className="data-table-card-label">{col.header}</span>
                      <span>{col.render ? col.render(row) : row[col.key]}</span>
                    </div>
                  ))}
                {columns.find((col) => !col.header) && (
                  <div className="data-table-card-actions">
                    {(() => {
                      const actionsCol = columns.find((col) => !col.header);
                      return actionsCol.render ? actionsCol.render(row) : null;
                    })()}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      )}

      {totalPages > 1 && (
        <div className="data-table-pagination">
          <button
            className="btn btn-ghost"
            style={{ padding: '6px 14px', fontSize: 13 }}
            disabled={page <= 0}
            onClick={() => onPageChange(page - 1)}
          >
            Prev
          </button>

          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            {pageWindow.map((p, idx) => (
              <span key={p} style={{ display: 'flex', alignItems: 'center' }}>
                {idx > 0 && pageWindow[idx - 1] !== p - 1 && (
                  <span style={{ padding: '0 4px', color: 'var(--color-text-muted)', fontSize: 13 }}>…</span>
                )}
                <button
                  onClick={() => onPageChange(p)}
                  aria-current={p === page ? 'page' : undefined}
                  style={{
                    width: 30,
                    height: 30,
                    borderRadius: 'var(--radius-sm)',
                    border: '1px solid var(--color-border)',
                    background: p === page ? 'var(--color-primary)' : 'transparent',
                    color: p === page ? '#fff' : 'var(--color-text)',
                    fontSize: 13,
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  {p + 1}
                </button>
              </span>
            ))}
          </div>

          <button
            className="btn btn-ghost"
            style={{ padding: '6px 14px', fontSize: 13 }}
            disabled={page >= totalPages - 1}
            onClick={() => onPageChange(page + 1)}
          >
            Next
          </button>

          {totalPages > 5 && (
            <form onSubmit={handleJump} style={{ display: 'flex', alignItems: 'center', gap: 6, marginLeft: 'auto' }}>
              <label htmlFor="jump-page" style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>
                Go to
              </label>
              <input
                id="jump-page"
                type="number"
                min={1}
                max={totalPages}
                value={jumpValue}
                onChange={(e) => setJumpValue(e.target.value)}
                style={{ width: 56, padding: '5px 8px', fontSize: 13, borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                placeholder={String(page + 1)}
              />
              <button type="submit" className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }}>
                Go
              </button>
            </form>
          )}
        </div>
      )}
    </div>
  );
}
