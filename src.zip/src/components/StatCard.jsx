export default function StatCard({ label, value, accent = false }) {
  return (
    <div className="card" style={{ padding: '20px 24px', minWidth: 160, flex: 1 }}>
      <div
        style={{
          fontFamily: 'var(--font-display)',
          fontSize: 30,
          fontWeight: 800,
          color: accent ? 'var(--color-accent)' : 'var(--color-primary)',
        }}
      >
        {value}
      </div>
      <div style={{ color: 'var(--color-text-muted)', fontSize: 13, marginTop: 4 }}>{label}</div>
    </div>
  );
}
