export function LoadingState({ label = 'Loading…', rows = 3 }) {
  return (
    <div role="status" aria-label={label} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="skeleton" style={{ height: 52, borderRadius: 'var(--radius-sm)' }} />
      ))}
    </div>
  );
}

export function EmptyState({ title = 'Nothing here yet', description, action }) {
  return (
    <div className="state-block">
      <span className="state-icon" aria-hidden="true">○</span>
      <span className="state-title">{title}</span>
      {description && <span style={{ fontSize: 'var(--text-sm)' }}>{description}</span>}
      {action}
    </div>
  );
}

export function ErrorState({ message = 'Something went wrong.', onRetry }) {
  return (
    <div className="state-block">
      <span className="state-icon" aria-hidden="true">!</span>
      <span className="state-title" style={{ color: 'var(--color-danger)' }}>{message}</span>
      {onRetry && (
        <button className="btn btn-ghost" onClick={onRetry} style={{ marginTop: 4 }}>
          Try again
        </button>
      )}
    </div>
  );
}
