import { NavLink } from 'react-router-dom';

const LINKS = [
  { to: '/app/student', label: 'Dashboard', end: true },
  { to: '/app/student/study-materials', label: 'Study materials' },
  { to: '/app/student/attendance', label: 'Attendance' },
  { to: '/app/student/assignments', label: 'Assignments' },
  { to: '/app/student/quizzes', label: 'Quizzes' },
  { to: '/app/student/assessments', label: 'Coding assessments' },
  { to: '/app/student/evaluations', label: 'Evaluations' },
  { to: '/app/student/resume', label: 'Resume' },
  { to: '/app/student/placements', label: 'Placements' },
];

export default function StudentSidebar() {
  return (
    <nav style={{ display: 'flex', flexDirection: 'column', gap: 4, minWidth: 200 }}>
      {LINKS.map((link) => (
        <NavLink
          key={link.to}
          to={link.to}
          end={link.end}
          style={({ isActive }) => ({
            padding: '10px 14px',
            borderRadius: 'var(--radius-sm)',
            fontSize: 14,
            fontWeight: 600,
            color: isActive ? 'var(--color-accent)' : 'var(--color-text)',
            background: isActive ? 'var(--color-surface-alt)' : 'transparent',
          })}
        >
          {link.label}
        </NavLink>
      ))}
    </nav>
  );
}
