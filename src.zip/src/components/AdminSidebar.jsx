import { NavLink } from 'react-router-dom';

const LINKS = [
  { to: '/app/admin', label: 'Dashboard', end: true },
  { to: '/app/admin/departments', label: 'Departments' },
  { to: '/app/admin/users', label: 'Users' },
  { to: '/app/admin/courses', label: 'Courses & skills' },
  { to: '/app/admin/batches', label: 'Batches' },
  { to: '/app/admin/evaluation-rubrics', label: 'Evaluation rubrics' },
  { to: '/app/admin/notifications', label: 'Notifications' },
  { to: '/app/admin/audit-logs', label: 'Audit logs' },
  { to: '/app/admin/reports', label: 'Reports' },
];

export default function AdminSidebar() {
  return (
    <nav style={{ display: 'flex', flexDirection: 'column', gap: 4, minWidth: 200 }}>
      {LINKS.map((link) => (
        <NavLink
          key={link.to}
          to={link.to}
          end={link.end}
          style={({ isActive }) => ({
            padding: '10px 14px',
            borderRadius: 'var(--radius-sm)',
            fontSize: 14,
            fontWeight: 600,
            color: isActive ? 'var(--color-accent)' : 'var(--color-text)',
            background: isActive ? 'var(--color-surface-alt)' : 'transparent',
          })}
        >
          {link.label}
        </NavLink>
      ))}
    </nav>
  );
}
