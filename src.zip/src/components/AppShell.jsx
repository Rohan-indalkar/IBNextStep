import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Logo from './Logo';
import ProfileDropdown from './ProfileDropdown';
import NotificationButton from './NotificationButton';
import ThemeToggle from './ThemeToggle';
import { useAuth } from '../context/AuthContext';
import { useConfirm } from './ConfirmDialog';

export default function AppShell({ roleLabel, sidebar, children }) {
  const { signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const confirm = useConfirm();
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileOpen]);

  async function handleLogout() {
    const ok = await confirm('You will be signed out of IBNextStep.', { title: 'Log out?' });
    if (!ok) return;
    await signOut();
    navigate('/auth/login', { replace: true });
  }

  return (
    <div style={{ minHeight: '100vh', background: 'var(--color-bg)' }}>
      <header className="app-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          {sidebar && (
            <button
              className="btn-icon shell-hamburger"
              onClick={() => setMobileOpen((o) => !o)}
              aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={mobileOpen}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
              </svg>
            </button>
          )}
          <Logo size={32} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span className="role-pill">{roleLabel}</span>
          <ThemeToggle />
          <NotificationButton />
          <ProfileDropdown />
        </div>
      </header>

      <div className="shell-body">
        {sidebar && (
          <>
            {mobileOpen && <div className="shell-backdrop" onClick={() => setMobileOpen(false)} />}
            <aside className={`shell-sidebar${mobileOpen ? ' shell-sidebar-open' : ''}`}>
              <div style={{ flex: 1, overflowY: 'auto' }}>{sidebar}</div>
              <div style={{ borderTop: '1px solid var(--color-border)', paddingTop: 10, marginTop: 10 }}>
                <button
                  onClick={handleLogout}
                  className="dropdown-item"
                  style={{ color: 'var(--color-danger)', display: 'flex', alignItems: 'center', gap: 8 }}
                >
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Log out
                </button>
              </div>
            </aside>
          </>
        )}
        <main className="shell-main">{children}</main>
      </div>
    </div>
  );
}
