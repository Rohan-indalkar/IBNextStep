import { NavLink } from 'react-router-dom';

const LINKS = [
  { to: '/app/trainer', label: 'Dashboard', end: true },
  { to: '/app/trainer/study-materials', label: 'Study materials' },
  { to: '/app/trainer/attendance', label: 'Attendance' },
  { to: '/app/trainer/assignments', label: 'Assignments' },
  { to: '/app/trainer/quizzes', label: 'Quizzes' },
  { to: '/app/trainer/assessments', label: 'Coding assessments' },
  { to: '/app/trainer/mock-interviews', label: 'Mock interviews' },
  { to: '/app/trainer/evaluations', label: 'Student evaluations' },
  { to: '/app/trainer/resumes', label: 'Resume review' },
];

export default function TrainerSidebar() {
  return (
    <nav style={{ display: 'flex', flexDirection: 'column', gap: 4, minWidth: 200 }}>
      {LINKS.map((link) => (
        <NavLink
          key={link.to}
          to={link.to}
          end={link.end}
          style={({ isActive }) => ({
            padding: '10px 14px',
            borderRadius: 'var(--radius-sm)',
            fontSize: 14,
            fontWeight: 600,
            color: isActive ? 'var(--color-accent)' : 'var(--color-text)',
            background: isActive ? 'var(--color-surface-alt)' : 'transparent',
          })}
        >
          {link.label}
        </NavLink>
      ))}
    </nav>
  );
}
