export default function ChartCard({ title, data, colorVar = '--color-accent' }) {
  const max = Math.max(1, ...data.map((d) => d.value));

  return (
    <div className="card" style={{ padding: 24 }}>
      <h2 style={{ fontSize: 16, marginBottom: 18 }}>{title}</h2>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {data.map((d) => (
          <div key={d.label}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 4 }}>
              <span style={{ color: 'var(--color-text-muted)' }}>{d.label}</span>
              <span style={{ fontWeight: 700 }}>{d.value}</span>
            </div>
            <div style={{ height: 8, borderRadius: 999, background: 'var(--color-surface-alt)', overflow: 'hidden' }}>
              <div
                style={{
                  height: '100%',
                  width: `${(d.value / max) * 100}%`,
                  background: `var(${colorVar})`,
                  borderRadius: 999,
                  transition: 'width 400ms var(--ease-out)',
                }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
