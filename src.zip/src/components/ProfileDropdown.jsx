import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import Modal from './Modal';
import { getProfile, updateProfile, changePassword } from '../api/profile';

export default function ProfileDropdown() {
  const { email, signOut } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [profile, setProfile] = useState(null);
  const [editOpen, setEditOpen] = useState(false);
  const [pwOpen, setPwOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    getProfile()
      .then((res) => setProfile(res.data.data))
      .catch(() => {});
  }, []);

  useEffect(() => {
    function onClickOutside(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  const initials = profile ? `${profile.firstName?.[0] || ''}${profile.lastName?.[0] || ''}`.toUpperCase() : (email?.[0] || '?').toUpperCase();
  const displayName = profile ? `${profile.firstName} ${profile.lastName}` : email;

  async function handleLogout() {
    setOpen(false);
    await signOut();
    navigate('/auth/login', { replace: true });
  }

  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <button
        className="btn-icon"
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label="Open profile menu"
        style={{ width: 'auto', borderRadius: 999, padding: '4px 12px 4px 4px', gap: 8, display: 'flex', alignItems: 'center' }}
      >
        <span
          aria-hidden="true"
          style={{
            width: 30, height: 30, borderRadius: '50%', background: 'var(--color-primary)', color: 'var(--color-text-inverse)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700,
          }}
        >
          {initials}
        </span>
        <span style={{ fontSize: 13, fontWeight: 600, maxWidth: 130, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {displayName}
        </span>
      </button>

      {open && (
        <div
          role="menu"
          className="card"
          style={{ position: 'absolute', right: 0, top: 'calc(100% + 8px)', minWidth: 200, padding: 8, zIndex: 40 }}
        >
          <div style={{ padding: '8px 12px', marginBottom: 4, borderBottom: '1px solid var(--color-border)' }}>
            <p style={{ fontSize: 13, fontWeight: 700 }}>{displayName}</p>
            <p style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>{email}</p>
          </div>
          <button role="menuitem" className="dropdown-item" onClick={() => { setOpen(false); setEditOpen(true); }}>
            Edit profile
          </button>
          <button role="menuitem" className="dropdown-item" onClick={() => { setOpen(false); setPwOpen(true); }}>
            Change password
          </button>
          <button role="menuitem" className="dropdown-item" style={{ color: 'var(--color-danger)' }} onClick={handleLogout}>
            Log out
          </button>
        </div>
      )}

      <EditProfileModal open={editOpen} onClose={() => setEditOpen(false)} profile={profile} onSaved={(p) => { setProfile(p); toast.success('Profile updated.'); }} />
      <ChangePasswordModal open={pwOpen} onClose={() => setPwOpen(false)} onSaved={() => toast.success('Password changed.')} />
    </div>
  );
}

function EditProfileModal({ open, onClose, profile, onSaved }) {
  const [firstName, setFirstName] = useState(profile?.firstName || '');
  const [lastName, setLastName] = useState(profile?.lastName || '');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setFirstName(profile?.firstName || '');
      setLastName(profile?.lastName || '');
      setError('');
    }
  }, [open, profile]);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setSaving(true);
    try {
      const res = await updateProfile({ firstName, lastName });
      onSaved(res.data.data);
      onClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal open={open} title="Edit profile" onClose={onClose}>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div className="field">
          <label htmlFor="pfFirst">First name</label>
          <input id="pfFirst" required value={firstName} onChange={(e) => setFirstName(e.target.value)} />
        </div>
        <div className="field">
          <label htmlFor="pfLast">Last name</label>
          <input id="pfLast" required value={lastName} onChange={(e) => setLastName(e.target.value)} />
        </div>
        {error && <p className="error-text">{error}</p>}
        <button className="btn btn-primary" type="submit" disabled={saving}>
          {saving ? 'Saving…' : 'Save changes'}
        </button>
      </form>
    </Modal>
  );
}

function ChangePasswordModal({ open, onClose, onSaved }) {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setCurrentPassword('');
      setNewPassword('');
      setConfirm('');
      setError('');
    }
  }, [open]);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    if (newPassword !== confirm) {
      setError('Passwords do not match.');
      return;
    }
    if (newPassword.length < 8) {
      setError('Password must be at least 8 characters.');
      return;
    }
    setSaving(true);
    try {
      await changePassword({ currentPassword, newPassword });
      onSaved();
      onClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal open={open} title="Change password" onClose={onClose}>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div className="field">
          <label htmlFor="pwCurrent">Current password</label>
          <input id="pwCurrent" type="password" required value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} />
        </div>
        <div className="field">
          <label htmlFor="pwNew">New password</label>
          <input id="pwNew" type="password" required value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="At least 8 characters" />
        </div>
        <div className="field">
          <label htmlFor="pwConfirm">Confirm new password</label>
          <input id="pwConfirm" type="password" required value={confirm} onChange={(e) => setConfirm(e.target.value)} />
        </div>
        {error && <p className="error-text">{error}</p>}
        <button className="btn btn-primary" type="submit" disabled={saving}>
          {saving ? 'Saving…' : 'Change password'}
        </button>
      </form>
    </Modal>
  );
}
