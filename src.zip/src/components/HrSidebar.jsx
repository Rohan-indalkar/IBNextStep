import { NavLink } from 'react-router-dom';

const LINKS = [
  { to: '/app/hr', label: 'Dashboard', end: true },
  { to: '/app/hr/companies', label: 'Companies' },
  { to: '/app/hr/placements', label: 'Placement drives' },
  { to: '/app/hr/applications', label: 'Applications' },
];

export default function HrSidebar() {
  return (
    <nav style={{ display: 'flex', flexDirection: 'column', gap: 4, minWidth: 200 }}>
      {LINKS.map((link) => (
        <NavLink
          key={link.to}
          to={link.to}
          end={link.end}
          style={({ isActive }) => ({
            padding: '10px 14px',
            borderRadius: 'var(--radius-sm)',
            fontSize: 14,
            fontWeight: 600,
            color: isActive ? 'var(--color-accent)' : 'var(--color-text)',
            background: isActive ? 'var(--color-surface-alt)' : 'transparent',
          })}
        >
          {link.label}
        </NavLink>
      ))}
    </nav>
  );
}
