import { useEffect, useRef, useState } from 'react';
import client from '../api/client';

function myNotifications(page = 0, size = 30) {
  return client.get('/notifications/me', { params: { page, size } });
}
function markRead(id) {
  return client.patch(`/notifications/${id}/read`);
}

export default function NotificationButton() {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const ref = useRef(null);

  function load() {
    setLoading(true);
    setError('');
    myNotifications()
      .then((res) => setItems(res.data.data.content))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  useEffect(() => {
    function onClickOutside(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  const unreadCount = items.filter((n) => !n.read).length;

  async function handleOpenItem(n) {
    if (!n.read) {
      try {
        await markRead(n.id);
        setItems((list) => list.map((x) => (x.id === n.id ? { ...x, read: true } : x)));
      } catch {
        // non-critical
      }
    }
  }

  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <button className="btn-icon" onClick={() => setOpen((o) => !o)} aria-haspopup="menu" aria-expanded={open} aria-label={`Notifications${unreadCount ? `, ${unreadCount} unread` : ''}`}>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M13.73 21a2 2 0 01-3.46 0" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        {unreadCount > 0 && (
          <span
            aria-hidden="true"
            style={{
              position: 'absolute', top: -2, right: -2, minWidth: 16, height: 16, borderRadius: 999, background: 'var(--color-accent)',
              color: '#fff', fontSize: 10, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 3px',
            }}
          >
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div role="menu" className="card" style={{ position: 'absolute', right: 0, top: 'calc(100% + 8px)', width: 320, maxHeight: 420, overflowY: 'auto', padding: 8, zIndex: 40 }}>
          <p style={{ fontSize: 12, fontWeight: 700, color: 'var(--color-text-muted)', padding: '6px 10px', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
            Notifications
          </p>
          {loading ? (
            <p style={{ fontSize: 13, color: 'var(--color-text-muted)', padding: '10px' }}>Loading…</p>
          ) : error ? (
            <p className="error-text" style={{ padding: '10px' }}>{error}</p>
          ) : items.length === 0 ? (
            <p style={{ fontSize: 13, color: 'var(--color-text-muted)', padding: '10px' }}>No notifications yet.</p>
          ) : (
            items.map((n) => (
              <button
                key={n.id}
                onClick={() => handleOpenItem(n)}
                style={{
                  display: 'block', width: '100%', textAlign: 'left', background: n.read ? 'transparent' : 'var(--color-surface-alt)',
                  border: 'none', borderRadius: 'var(--radius-sm)', padding: '10px 12px', marginBottom: 4, cursor: 'pointer',
                }}
              >
                <p style={{ fontSize: 13, fontWeight: n.read ? 500 : 700, marginBottom: 2 }}>{n.title}</p>
                <p style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>{n.message}</p>
                <p style={{ fontSize: 11, color: 'var(--color-text-muted)', marginTop: 4 }}>
                  {n.createdAt ? new Date(n.createdAt).toLocaleString() : ''}
                </p>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}
