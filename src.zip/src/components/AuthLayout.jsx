import { motion } from 'framer-motion';
import Logo from './Logo';

const HIGHLIGHTS = [
  { title: 'Structured Learning', body: 'Batches, courses and study material organised like a real training program.' },
  { title: 'Practice That Counts', body: 'Coding assessments, quizzes and mock interviews before it matters.' },
  { title: 'A Real Next Step', body: 'Evaluations and resume readiness roll into one placement pipeline.' },
];

export default function AuthLayout({ title, subtitle, children }) {
  return (
    <div className="auth-split">
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '32px 20px', background: 'var(--color-bg)' }}>
        <div style={{ marginBottom: 28 }}>
          <Logo size={36} />
        </div>
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
          className="card"
          style={{ width: '100%', maxWidth: 400, padding: '36px 32px' }}
        >
          <h1 style={{ fontSize: 22, marginBottom: 6 }}>{title}</h1>
          {subtitle && (
            <p style={{ color: 'var(--color-text-muted)', fontSize: 14, marginBottom: 24 }}>{subtitle}</p>
          )}
          {children}
        </motion.div>
      </div>

      <div className="auth-brand-panel" aria-hidden="true">
        <div style={{ position: 'absolute', top: -60, right: -60, width: 240, height: 240, borderRadius: '50%', background: 'rgba(255,255,255,0.05)' }} />
        <div style={{ position: 'absolute', bottom: -80, left: -40, width: 200, height: 200, borderRadius: '50%', background: 'rgba(255,255,255,0.04)' }} />
        <div style={{ position: 'relative', maxWidth: 380 }}>
          <Logo size={40} dark />
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 28, marginTop: 28, marginBottom: 16, lineHeight: 1.25 }}>
            From first class to offer letter — one platform.
          </h2>
          <p style={{ fontSize: 15, opacity: 0.8, marginBottom: 36 }}>
            IBNextStep runs the whole InfoBeans Foundation training journey — coursework, practice,
            evaluation and placement — in one connected system.
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            {HIGHLIGHTS.map((h) => (
              <div key={h.title} style={{ display: 'flex', gap: 12 }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--color-text-inverse)', opacity: 0.7, marginTop: 7, flexShrink: 0 }} />
                <div>
                  <p style={{ fontWeight: 700, fontSize: 14, marginBottom: 2 }}>{h.title}</p>
                  <p style={{ fontSize: 13, opacity: 0.75 }}>{h.body}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
