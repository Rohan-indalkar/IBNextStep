const TONE_MAP = {
  // Generic
  ACTIVE: 'success', INACTIVE: 'neutral', DRAFT: 'neutral', PUBLISHED: 'success', SCHEDULED: 'warning',
  CLOSED: 'danger', ARCHIVED: 'neutral', COMPLETED: 'neutral', EXPIRED: 'danger',
  // Users
  APPROVED: 'success', PENDING_REVIEW: 'warning', NEEDS_CHANGES: 'danger',
  // Applications / placements
  APPLIED: 'neutral', SHORTLISTED: 'warning', REJECTED: 'danger', INTERVIEW_SCHEDULED: 'info',
  SELECTED: 'success', NOT_SELECTED: 'danger',
  // Attendance / assignments
  PRESENT: 'success', ABSENT: 'danger', LATE: 'warning', SUBMITTED: 'warning', GRADED: 'success',
  // Sessions
  CONDUCTED: 'info', EVALUATED: 'info', CANCELLED: 'danger', IN_PROGRESS: 'info',
};

export default function StatusBadge({ status, tone, solid = false }) {
  if (!status) return null;
  const resolvedTone = tone || TONE_MAP[status] || 'neutral';
  const label = String(status).replace(/_/g, ' ');

  if (solid) {
    const bg = {
      success: 'var(--color-success)', warning: 'var(--color-warning)', danger: 'var(--color-danger)',
      info: 'var(--color-info)', neutral: 'var(--color-neutral)',
    }[resolvedTone];
    return <span className="badge badge-solid" style={{ background: bg }}>{label}</span>;
  }

  return <span className={`badge badge-${resolvedTone}`}>{label}</span>;
}
