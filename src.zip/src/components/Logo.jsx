export default function Logo({ size = 40, withWordmark = true, dark = false }) {
  const textColor = dark ? '#FFFDF9' : 'var(--color-text)';
  // On a dark-red splash background, the standard crimson accent would
  // vanish against it — swap to cream so "NextStep" still reads clearly.
  const accentColor = dark ? '#F2C9A0' : 'var(--color-accent)';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <svg width={size} height={size} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="40" height="40" rx="12" fill="var(--color-primary)" />
        <path d="M14 12L22 20L14 28" stroke="var(--color-bg)" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M22 12L27 20L22 28" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" opacity="0.5" />
      </svg>
      {withWordmark && (
        <span
          style={{
            fontFamily: 'var(--font-display)',
            fontWeight: 700,
            fontSize: size * 0.5,
            color: textColor,
            letterSpacing: '-0.02em',
          }}
        >
          IB<span style={{ color: accentColor }}>NextStep</span>
        </span>
      )}
    </div>
  );
}
