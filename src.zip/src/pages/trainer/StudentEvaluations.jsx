import { useEffect, useState } from 'react';
import AppShell from '../../components/AppShell';
import TrainerSidebar from '../../components/TrainerSidebar';
import Modal from '../../components/Modal';
import useMyBatches from '../../hooks/useMyBatches';
import {
  getRubric,
  getBatchOverview,
  getMetrics,
  submitEvaluation,
  exportPdf,
  exportExcel,
} from '../../api/studentEvaluation';

export default function StudentEvaluations() {
  const { batches } = useMyBatches();
  const [batchId, setBatchId] = useState('');
  const [overview, setOverview] = useState(null);
  const [rubric, setRubric] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [evalModal, setEvalModal] = useState(null);
  const [metrics, setMetrics] = useState(null);
  const [scores, setScores] = useState({});
  const [remarks, setRemarks] = useState('');
  const [overrideFinal, setOverrideFinal] = useState('');
  const [overrideReason, setOverrideReason] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    getRubric()
      .then((res) => setRubric(res.data.data))
      .catch((err) => setError(err.message));
  }, []);

  useEffect(() => {
    if (batches.length && !batchId) setBatchId(batches[0].id);
  }, [batches, batchId]);

  useEffect(() => {
    if (!batchId) return;
    setLoading(true);
    setError('');
    getBatchOverview(batchId)
      .then((res) => setOverview(res.data.data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [batchId]);

  function openEvaluate(student) {
    setEvalModal(student);
    setMetrics(null);
    setRemarks('');
    setOverrideFinal('');
    setOverrideReason('');
    const initial = {};
    (rubric?.skills || []).forEach((s) => (initial[s] = 5));
    setScores(initial);
    getMetrics(student.studentId)
      .then((res) => setMetrics(res.data.data))
      .catch((err) => setError(err.message));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    if (overrideFinal !== '' && Boolean(overrideFinal === 'true') !== metrics?.systemEligible && !overrideReason) {
      setError('An override reason is required when your decision differs from the system verdict.');
      return;
    }
    setSaving(true);
    try {
      await submitEvaluation(evalModal.studentId, {
        skillScores: scores,
        remarks: remarks || null,
        finalEligibleOverride: overrideFinal === '' ? null : overrideFinal === 'true',
        overrideReason: overrideReason || null,
      });
      setEvalModal(null);
      getBatchOverview(batchId).then((res) => setOverview(res.data.data));
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  const selectStyle = { padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', fontSize: 14 };

  return (
    <AppShell roleLabel="Trainer" sidebar={<TrainerSidebar />}>
      <h1 style={{ fontSize: 24, marginBottom: 20 }}>Student evaluations</h1>

      <div style={{ marginBottom: 20 }}>
        <select value={batchId} onChange={(e) => setBatchId(e.target.value)} style={selectStyle}>
          <option value="">Select a batch…</option>
          {batches.map((b) => (
            <option key={b.id} value={b.id}>{b.name}</option>
          ))}
        </select>
      </div>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      {loading ? (
        <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
      ) : overview ? (
        <div className="card" style={{ padding: 20 }}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)', marginBottom: 16 }}>
            {overview.evaluatedByMe} of {overview.totalStudents} evaluated by you · {overview.pendingEvaluationByMe} pending
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {overview.students.map((s) => (
              <div key={s.studentId} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)' }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{s.studentName}</div>
                  <div style={{ fontSize: 12, color: s.systemEligible ? 'var(--color-success)' : 'var(--color-text-muted)' }}>
                    {s.systemEligible ? 'System eligible' : 'Not yet eligible'}
                    {s.evaluatedByMyRubric && ` · last scored ${s.lastOverallRubricScore ?? '—'}/10`}
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <button className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} onClick={() => openEvaluate(s)}>
                    {s.evaluatedByMyRubric ? 'Re-evaluate' : 'Evaluate'}
                  </button>
                  {s.lastEvaluationId && (
                    <>
                      <button className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} onClick={() => exportPdf(s.lastEvaluationId).catch((err) => setError(err.message))}>
                        PDF
                      </button>
                      <button className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} onClick={() => exportExcel(s.lastEvaluationId).catch((err) => setError(err.message))}>
                        Excel
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <p style={{ color: 'var(--color-text-muted)' }}>Select a batch to view its roster.</p>
      )}

      <Modal open={Boolean(evalModal)} title={`Evaluate — ${evalModal?.studentName || ''}`} onClose={() => setEvalModal(null)}>
        {!metrics ? (
          <p style={{ color: 'var(--color-text-muted)' }}>Loading metrics…</p>
        ) : (
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{ padding: '12px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 13 }}>
              <p>Attendance: {metrics.attendancePercentage ?? 'N/A'}% (min {metrics.minAttendancePercentage}%)</p>
              <p>Avg quiz: {metrics.avgQuizPercentage ?? 'N/A'}% (min {metrics.minQuizPercentage}%)</p>
              <p>Avg coding: {metrics.avgCodingPercentage ?? 'N/A'}% (min {metrics.minCodingPercentage}%)</p>
              <p>Avg mock interview: {metrics.avgMockInterviewRating ?? 'N/A'} (min {metrics.minMockInterviewRating})</p>
              <p style={{ fontWeight: 700, color: metrics.systemEligible ? 'var(--color-success)' : 'var(--color-danger)', marginTop: 6 }}>
                System verdict: {metrics.systemEligible ? 'Eligible' : 'Not eligible'}
              </p>
              {metrics.systemIneligibilityReasons?.length > 0 && (
                <ul style={{ margin: '6px 0 0', paddingLeft: 18 }}>
                  {metrics.systemIneligibilityReasons.map((r, i) => <li key={i}>{r}</li>)}
                </ul>
              )}
            </div>

            <div className="field">
              <label>Rubric scores (0-10)</label>
              {(rubric?.skills || []).map((skill) => (
                <div key={skill} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
                  <span style={{ fontSize: 13, flex: 1 }}>{skill}</span>
                  <input type="number" min={0} max={10} value={scores[skill] ?? 5} onChange={(e) => setScores((s) => ({ ...s, [skill]: Number(e.target.value) }))} style={{ width: 70 }} />
                </div>
              ))}
            </div>

            <div className="field">
              <label htmlFor="remarks">Remarks</label>
              <textarea id="remarks" rows={3} value={remarks} onChange={(e) => setRemarks(e.target.value)} style={{ fontFamily: 'var(--font-body)', fontSize: 14, padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', resize: 'vertical' }} />
            </div>

            <div className="field">
              <label htmlFor="overrideFinal">Final decision</label>
              <select id="overrideFinal" value={overrideFinal} onChange={(e) => setOverrideFinal(e.target.value)} style={selectStyle}>
                <option value="">Agree with system verdict</option>
                <option value="true">Override: Eligible</option>
                <option value="false">Override: Not eligible</option>
              </select>
            </div>
            {overrideFinal !== '' && (
              <div className="field">
                <label htmlFor="overrideReason">Override reason</label>
                <input id="overrideReason" value={overrideReason} onChange={(e) => setOverrideReason(e.target.value)} />
              </div>
            )}

            <button className="btn btn-primary" type="submit" disabled={saving}>
              {saving ? 'Submitting…' : 'Submit evaluation'}
            </button>
          </form>
        )}
      </Modal>
    </AppShell>
  );
}
