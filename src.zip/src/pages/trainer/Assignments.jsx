import { useEffect, useState, useCallback } from 'react';
import AppShell from '../../components/AppShell';
import TrainerSidebar from '../../components/TrainerSidebar';
import DataTable from '../../components/DataTable';
import Modal from '../../components/Modal';
import useMyBatches from '../../hooks/useMyBatches';
import { searchCourses } from '../../api/course';
import {
  dashboardAssignments,
  createAssignment,
  generateAssignmentWithAi,
  publishAssignmentNow,
  scheduleAssignment,
  closeAssignment,
  deleteAssignment,
  getSubmissions,
  gradeSubmission,
} from '../../api/assignment';

const SKILL_TYPES = ['TECHNICAL', 'SOFT_SKILL'];
const DIFFICULTIES = ['BEGINNER', 'INTERMEDIATE', 'ADVANCED'];

const EMPTY_MANUAL = {
  title: '', description: '', courseId: '', module: '', topic: '',
  skillType: 'TECHNICAL', difficultyLevel: 'BEGINNER', batchIds: [],
  questions: [''], dueDate: '', publishOption: 'SAVE_AS_DRAFT', scheduledAt: '',
};

const EMPTY_AI = {
  title: '', description: '', courseId: '', module: '', topic: '',
  skillType: 'TECHNICAL', difficultyLevel: 'BEGINNER', numberOfQuestions: 5,
  additionalInstructions: '', dueDate: '', batchIds: [],
};

function StatusBadge({ status }) {
  const colors = { DRAFT: 'var(--color-text-muted)', SCHEDULED: 'var(--color-warning)', PUBLISHED: 'var(--color-success)', CLOSED: 'var(--color-danger)' };
  return (
    <span style={{ fontSize: 12, fontWeight: 700, padding: '3px 10px', borderRadius: 999, color: '#fff', background: colors[status] || '#888' }}>
      {status}
    </span>
  );
}

export default function Assignments() {
  const { batches } = useMyBatches();
  const [courses, setCourses] = useState([]);
  const [rows, setRows] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState(null);

  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [mode, setMode] = useState('manual');
  const [manualForm, setManualForm] = useState(EMPTY_MANUAL);
  const [aiForm, setAiForm] = useState(EMPTY_AI);
  const [files, setFiles] = useState([]);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  const [submissionsModal, setSubmissionsModal] = useState(null);
  const [submissions, setSubmissions] = useState([]);
  const [submissionsLoading, setSubmissionsLoading] = useState(false);
  const [gradingFor, setGradingFor] = useState(null);
  const [feedback, setFeedback] = useState('');
  const [rating, setRating] = useState(5);
  const [gradeSaving, setGradeSaving] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    setError('');
    dashboardAssignments({ search: search || undefined, page, size: 10 })
      .then((res) => {
        const paged = res.data.data;
        setRows(paged.content);
        setTotalPages(paged.totalPages);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [search, page]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    searchCourses({ page: 0, size: 100 })
      .then((res) => setCourses(res.data.data.content))
      .catch(() => {});
  }, []);

  function openCreate() {
    setMode('manual');
    setManualForm(EMPTY_MANUAL);
    setAiForm(EMPTY_AI);
    setFiles([]);
    setFormError('');
    setCreateModalOpen(true);
  }

  function toggleBatch(form, setForm, id) {
    setForm((f) => ({ ...f, batchIds: f.batchIds.includes(id) ? f.batchIds.filter((b) => b !== id) : [...f.batchIds, id] }));
  }

  function updateQuestion(i, value) {
    setManualForm((f) => ({ ...f, questions: f.questions.map((q, idx) => (idx === i ? value : q)) }));
  }
  function addQuestion() {
    setManualForm((f) => ({ ...f, questions: [...f.questions, ''] }));
  }
  function removeQuestion(i) {
    setManualForm((f) => ({ ...f, questions: f.questions.filter((_, idx) => idx !== i) }));
  }

  async function handleManualSave(e) {
    e.preventDefault();
    setFormError('');
    if (manualForm.publishOption === 'SCHEDULE_PUBLISH' && !manualForm.scheduledAt) {
      setFormError('Pick a schedule date/time.');
      return;
    }
    setSaving(true);
    try {
      const payload = {
        title: manualForm.title,
        description: manualForm.description || null,
        courseId: manualForm.courseId,
        module: manualForm.module || null,
        topic: manualForm.topic || null,
        skillType: manualForm.skillType,
        difficultyLevel: manualForm.difficultyLevel,
        batchIds: manualForm.batchIds,
        questions: manualForm.questions.filter((q) => q.trim()).map((q) => ({ questionText: q })),
        dueDate: manualForm.dueDate ? new Date(manualForm.dueDate).toISOString() : null,
        publishOption: manualForm.publishOption,
        scheduledAt: manualForm.publishOption === 'SCHEDULE_PUBLISH' ? new Date(manualForm.scheduledAt).toISOString() : null,
      };
      await createAssignment(payload, files);
      setCreateModalOpen(false);
      load();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleAiGenerate(e) {
    e.preventDefault();
    setFormError('');
    setSaving(true);
    try {
      await generateAssignmentWithAi({
        title: aiForm.title,
        description: aiForm.description || null,
        courseId: aiForm.courseId,
        module: aiForm.module || null,
        topic: aiForm.topic,
        skillType: aiForm.skillType,
        difficultyLevel: aiForm.difficultyLevel,
        numberOfQuestions: Number(aiForm.numberOfQuestions),
        additionalInstructions: aiForm.additionalInstructions || null,
        dueDate: aiForm.dueDate ? new Date(aiForm.dueDate).toISOString() : null,
        batchIds: aiForm.batchIds,
      });
      setCreateModalOpen(false);
      load();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleAction(assignment, action) {
    setBusyId(assignment.id);
    setError('');
    try {
      if (action === 'publish') await publishAssignmentNow(assignment.id);
      else if (action === 'close') await closeAssignment(assignment.id);
      else if (action === 'delete') {
        if (!window.confirm(`Delete "${assignment.title}"?`)) return;
        await deleteAssignment(assignment.id);
      }
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  async function handleSchedule(assignment) {
    const input = window.prompt('Schedule publish for (YYYY-MM-DDTHH:mm)');
    if (!input) return;
    setBusyId(assignment.id);
    try {
      await scheduleAssignment(assignment.id, new Date(input).toISOString());
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  function openSubmissions(assignment) {
    setSubmissionsModal(assignment);
    setSubmissionsLoading(true);
    getSubmissions(assignment.id)
      .then((res) => setSubmissions(res.data.data))
      .catch((err) => setError(err.message))
      .finally(() => setSubmissionsLoading(false));
  }

  function openGrade(submission) {
    setGradingFor(submission);
    setFeedback(submission.feedback || '');
    setRating(submission.rating || 5);
  }

  async function handleGrade(e) {
    e.preventDefault();
    setGradeSaving(true);
    try {
      await gradeSubmission(submissionsModal.id, gradingFor.studentId, { feedback, rating: Number(rating) });
      setGradingFor(null);
      openSubmissions(submissionsModal);
    } catch (err) {
      setError(err.message);
    } finally {
      setGradeSaving(false);
    }
  }

  const selectStyle = { padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', fontSize: 14 };

  const columns = [
    { key: 'title', header: 'Title' },
    { key: 'courseName', header: 'Course', render: (r) => r.courseName || '—' },
    { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    { key: 'questionCount', header: 'Questions' },
    { key: 'ai', header: 'AI', render: (r) => (r.generatedByAI ? 'Yes' : '—') },
    { key: 'submissions', header: 'Submissions', render: (r) => `${r.gradedSubmissions}/${r.totalSubmissions} graded` },
    {
      key: 'actions',
      header: '',
      render: (r) => (
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {r.status !== 'PUBLISHED' && r.status !== 'CLOSED' && (
            <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handleAction(r, 'publish')}>
              Publish
            </button>
          )}
          {r.status === 'DRAFT' && (
            <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handleSchedule(r)}>
              Schedule
            </button>
          )}
          {r.status === 'PUBLISHED' && (
            <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handleAction(r, 'close')}>
              Close
            </button>
          )}
          <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} onClick={() => openSubmissions(r)}>
            Submissions
          </button>
          <button
            className="btn btn-ghost"
            style={{ padding: '5px 10px', fontSize: 12, color: 'var(--color-danger)' }}
            disabled={busyId === r.id}
            onClick={() => handleAction(r, 'delete')}
          >
            Delete
          </button>
        </div>
      ),
    },
  ];

  return (
    <AppShell roleLabel="Trainer" sidebar={<TrainerSidebar />}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
        <h1 style={{ fontSize: 24 }}>Assignments</h1>
        <button className="btn btn-primary" onClick={openCreate}>
          + New assignment
        </button>
      </div>

      <div style={{ marginBottom: 16, maxWidth: 320 }}>
        <input
          type="text"
          placeholder="Search title, topic…"
          value={search}
          onChange={(e) => {
            setPage(0);
            setSearch(e.target.value);
          }}
          style={{ width: '100%', padding: '10px 14px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', fontSize: 14, background: 'var(--color-surface)' }}
        />
      </div>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      <DataTable columns={columns} rows={rows} loading={loading} emptyLabel="No assignments yet." page={page} totalPages={totalPages} onPageChange={setPage} />

      <Modal open={createModalOpen} title="New assignment" onClose={() => setCreateModalOpen(false)}>
        <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
          <button onClick={() => setMode('manual')} className={mode === 'manual' ? 'btn btn-primary' : 'btn btn-ghost'} style={{ padding: '7px 16px', fontSize: 13 }}>
            Manual
          </button>
          <button onClick={() => setMode('ai')} className={mode === 'ai' ? 'btn btn-primary' : 'btn btn-ghost'} style={{ padding: '7px 16px', fontSize: 13 }}>
            Generate with AI
          </button>
        </div>

        {mode === 'manual' ? (
          <form onSubmit={handleManualSave} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div className="field">
              <label htmlFor="mtitle">Title</label>
              <input id="mtitle" required value={manualForm.title} onChange={(e) => setManualForm((f) => ({ ...f, title: e.target.value }))} />
            </div>
            <div className="field">
              <label htmlFor="mcourse">Course</label>
              <select id="mcourse" required value={manualForm.courseId} onChange={(e) => setManualForm((f) => ({ ...f, courseId: e.target.value }))} style={selectStyle}>
                <option value="">Select…</option>
                {courses.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <div className="field" style={{ flex: 1 }}>
                <label htmlFor="mskill">Skill type</label>
                <select id="mskill" value={manualForm.skillType} onChange={(e) => setManualForm((f) => ({ ...f, skillType: e.target.value }))} style={selectStyle}>
                  {SKILL_TYPES.map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
                </select>
              </div>
              <div className="field" style={{ flex: 1 }}>
                <label htmlFor="mdiff">Difficulty</label>
                <select id="mdiff" value={manualForm.difficultyLevel} onChange={(e) => setManualForm((f) => ({ ...f, difficultyLevel: e.target.value }))} style={selectStyle}>
                  {DIFFICULTIES.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
            </div>

            <div className="field">
              <label>Questions</label>
              {manualForm.questions.map((q, i) => (
                <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
                  <input value={q} onChange={(e) => updateQuestion(i, e.target.value)} placeholder={`Question ${i + 1}`} style={{ flex: 1 }} />
                  {manualForm.questions.length > 1 && (
                    <button type="button" onClick={() => removeQuestion(i)} style={{ background: 'none', border: 'none', color: 'var(--color-danger)', cursor: 'pointer' }}>
                      ×
                    </button>
                  )}
                </div>
              ))}
              <button type="button" className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12, marginTop: 4 }} onClick={addQuestion}>
                + Add question
              </button>
            </div>

            <div className="field">
              <label htmlFor="mfiles">Reference file(s) (optional)</label>
              <input id="mfiles" type="file" multiple onChange={(e) => setFiles(Array.from(e.target.files || []))} />
            </div>

            <div className="field">
              <label>Batches</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
                {batches.map((b) => (
                  <label key={b.id} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                    <input type="checkbox" checked={manualForm.batchIds.includes(b.id)} onChange={() => toggleBatch(manualForm, setManualForm, b.id)} />
                    {b.name}
                  </label>
                ))}
              </div>
            </div>

            <div className="field">
              <label htmlFor="mdue">Due date</label>
              <input id="mdue" type="datetime-local" value={manualForm.dueDate} onChange={(e) => setManualForm((f) => ({ ...f, dueDate: e.target.value }))} />
            </div>

            <div className="field">
              <label htmlFor="mpub">Publish option</label>
              <select id="mpub" value={manualForm.publishOption} onChange={(e) => setManualForm((f) => ({ ...f, publishOption: e.target.value }))} style={selectStyle}>
                <option value="SAVE_AS_DRAFT">Save as draft</option>
                <option value="PUBLISH_NOW">Publish now</option>
                <option value="SCHEDULE_PUBLISH">Schedule publish</option>
              </select>
            </div>
            {manualForm.publishOption === 'SCHEDULE_PUBLISH' && (
              <div className="field">
                <label htmlFor="msched">Schedule for</label>
                <input id="msched" type="datetime-local" value={manualForm.scheduledAt} onChange={(e) => setManualForm((f) => ({ ...f, scheduledAt: e.target.value }))} />
              </div>
            )}

            {formError && <p className="error-text">{formError}</p>}
            <button className="btn btn-primary" type="submit" disabled={saving}>
              {saving ? 'Saving…' : 'Save assignment'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleAiGenerate} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>
              Generates a draft for you to review and publish — nothing goes live automatically.
            </p>
            <div className="field">
              <label htmlFor="atitle">Title</label>
              <input id="atitle" required value={aiForm.title} onChange={(e) => setAiForm((f) => ({ ...f, title: e.target.value }))} />
            </div>
            <div className="field">
              <label htmlFor="acourse">Course</label>
              <select id="acourse" required value={aiForm.courseId} onChange={(e) => setAiForm((f) => ({ ...f, courseId: e.target.value }))} style={selectStyle}>
                <option value="">Select…</option>
                {courses.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="atopic">Topic (drives the AI prompt)</label>
              <input id="atopic" required value={aiForm.topic} onChange={(e) => setAiForm((f) => ({ ...f, topic: e.target.value }))} placeholder="e.g. Java Streams API" />
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <div className="field" style={{ flex: 1 }}>
                <label htmlFor="askill">Skill type</label>
                <select id="askill" value={aiForm.skillType} onChange={(e) => setAiForm((f) => ({ ...f, skillType: e.target.value }))} style={selectStyle}>
                  {SKILL_TYPES.map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
                </select>
              </div>
              <div className="field" style={{ flex: 1 }}>
                <label htmlFor="adiff">Difficulty</label>
                <select id="adiff" value={aiForm.difficultyLevel} onChange={(e) => setAiForm((f) => ({ ...f, difficultyLevel: e.target.value }))} style={selectStyle}>
                  {DIFFICULTIES.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div className="field" style={{ width: 120 }}>
                <label htmlFor="anum">Questions</label>
                <input id="anum" type="number" min={1} max={20} value={aiForm.numberOfQuestions} onChange={(e) => setAiForm((f) => ({ ...f, numberOfQuestions: e.target.value }))} />
              </div>
            </div>
            <div className="field">
              <label htmlFor="ainstr">Additional instructions</label>
              <input id="ainstr" value={aiForm.additionalInstructions} onChange={(e) => setAiForm((f) => ({ ...f, additionalInstructions: e.target.value }))} placeholder="Optional guidance for the AI" />
            </div>
            <div className="field">
              <label>Batches</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
                {batches.map((b) => (
                  <label key={b.id} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                    <input type="checkbox" checked={aiForm.batchIds.includes(b.id)} onChange={() => toggleBatch(aiForm, setAiForm, b.id)} />
                    {b.name}
                  </label>
                ))}
              </div>
            </div>
            <div className="field">
              <label htmlFor="adue">Due date</label>
              <input id="adue" type="datetime-local" value={aiForm.dueDate} onChange={(e) => setAiForm((f) => ({ ...f, dueDate: e.target.value }))} />
            </div>

            {formError && <p className="error-text">{formError}</p>}
            <button className="btn btn-primary" type="submit" disabled={saving}>
              {saving ? 'Generating…' : 'Generate draft'}
            </button>
          </form>
        )}
      </Modal>

      <Modal open={Boolean(submissionsModal)} title={`Submissions — ${submissionsModal?.title || ''}`} onClose={() => setSubmissionsModal(null)}>
        {submissionsLoading ? (
          <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
        ) : submissions.length === 0 ? (
          <p style={{ color: 'var(--color-text-muted)' }}>No submissions yet.</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {submissions.map((s) => (
              <div key={s.studentId} style={{ padding: '12px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                  <span style={{ fontWeight: 600, fontSize: 14 }}>{s.studentName}</span>
                  <span style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>{s.status}</span>
                </div>
                {s.rating ? (
                  <p style={{ fontSize: 13, color: 'var(--color-success)', marginBottom: 6 }}>Rated {s.rating}/5</p>
                ) : (
                  <p style={{ fontSize: 13, color: 'var(--color-text-muted)', marginBottom: 6 }}>Not graded yet</p>
                )}
                <button className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} onClick={() => openGrade(s)}>
                  {s.rating ? 'Update feedback' : 'Give feedback'}
                </button>
              </div>
            ))}
          </div>
        )}
      </Modal>

      <Modal open={Boolean(gradingFor)} title={`Feedback for ${gradingFor?.studentName || ''}`} onClose={() => setGradingFor(null)}>
        <form onSubmit={handleGrade} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="field">
            <label htmlFor="rating">Rating (1-5)</label>
            <input id="rating" type="number" min={1} max={5} required value={rating} onChange={(e) => setRating(e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="feedback">Feedback</label>
            <textarea
              id="feedback"
              rows={4}
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              style={{ fontFamily: 'var(--font-body)', fontSize: 14, padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', resize: 'vertical' }}
            />
          </div>
          <button className="btn btn-primary" type="submit" disabled={gradeSaving}>
            {gradeSaving ? 'Saving…' : 'Share feedback'}
          </button>
        </form>
      </Modal>
    </AppShell>
  );
}
