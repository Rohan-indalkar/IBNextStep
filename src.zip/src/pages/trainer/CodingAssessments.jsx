import { useEffect, useState, useCallback } from 'react';
import AppShell from '../../components/AppShell';
import TrainerSidebar from '../../components/TrainerSidebar';
import DataTable from '../../components/DataTable';
import Modal from '../../components/Modal';
import useMyBatches from '../../hooks/useMyBatches';
import {
  listAssessments,
  createAssessment,
  deleteAssessment,
  publishAssessment,
  archiveAssessment,
  duplicateAssessment,
  listQuestions,
  addQuestion,
  deleteQuestion,
  generateQuestionsPreview,
  saveAiQuestions,
  getAnalytics,
} from '../../api/codingAssessment';

const LANGUAGES = ['JAVA', 'PYTHON3', 'CPP', 'C', 'JAVASCRIPT'];
const DIFFICULTIES = ['EASY', 'MEDIUM', 'HARD'];

const EMPTY_ASSESSMENT = {
  title: '', description: '', batchId: '', durationMinutes: 60,
  startTime: '', endTime: '', passingMarks: 50, maxAttempts: 1, allowedLanguages: ['JAVA'],
};

const EMPTY_QUESTION = {
  title: '', problemStatement: '', inputFormat: '', outputFormat: '', constraints: '',
  difficulty: 'MEDIUM', marks: 10, timeLimitSeconds: 2, memoryLimitMb: 256,
  allowedLanguages: ['JAVA'], publicTestCases: [{ input: '', expectedOutput: '' }], hiddenTestCases: [],
};

function StatusBadge({ status }) {
  const colors = { DRAFT: '#888', PUBLISHED: 'var(--color-success)', COMPLETED: 'var(--color-text-muted)', ARCHIVED: '#888' };
  return <span style={{ fontSize: 12, fontWeight: 700, padding: '3px 10px', borderRadius: 999, color: '#fff', background: colors[status] || '#888' }}>{status}</span>;
}

export default function CodingAssessments() {
  const { batches } = useMyBatches();
  const [rows, setRows] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState(null);

  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [form, setForm] = useState(EMPTY_ASSESSMENT);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  const [questionsModal, setQuestionsModal] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [qLoading, setQLoading] = useState(false);
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [qForm, setQForm] = useState(EMPTY_QUESTION);
  const [qSaving, setQSaving] = useState(false);

  const [aiModalOpen, setAiModalOpen] = useState(false);
  const [aiForm, setAiForm] = useState({ topic: '', language: 'JAVA', difficulty: '', questionCount: 3 });
  const [aiPreview, setAiPreview] = useState(null);
  const [aiSaving, setAiSaving] = useState(false);

  const [analyticsModal, setAnalyticsModal] = useState(null);
  const [analytics, setAnalytics] = useState(null);

  const load = useCallback(() => {
    setLoading(true);
    setError('');
    listAssessments({ page, size: 10 })
      .then((res) => {
        const paged = res.data.data;
        setRows(paged.content);
        setTotalPages(paged.totalPages);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [page]);

  useEffect(() => {
    load();
  }, [load]);

  function toggleLang(form, setForm, lang) {
    setForm((f) => ({ ...f, allowedLanguages: f.allowedLanguages.includes(lang) ? f.allowedLanguages.filter((l) => l !== lang) : [...f.allowedLanguages, lang] }));
  }

  function openCreate() {
    setForm(EMPTY_ASSESSMENT);
    setFormError('');
    setCreateModalOpen(true);
  }

  async function handleCreate(e) {
    e.preventDefault();
    setFormError('');
    setSaving(true);
    try {
      await createAssessment({
        title: form.title,
        description: form.description || null,
        batchId: form.batchId,
        durationMinutes: Number(form.durationMinutes),
        startTime: new Date(form.startTime).toISOString(),
        endTime: new Date(form.endTime).toISOString(),
        passingMarks: Number(form.passingMarks),
        maxAttempts: Number(form.maxAttempts),
        allowedLanguages: form.allowedLanguages,
      });
      setCreateModalOpen(false);
      load();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleAction(assessment, action) {
    setBusyId(assessment.id);
    setError('');
    try {
      if (action === 'publish') await publishAssessment(assessment.id);
      else if (action === 'archive') await archiveAssessment(assessment.id);
      else if (action === 'duplicate') await duplicateAssessment(assessment.id);
      else if (action === 'delete') {
        if (!window.confirm(`Delete "${assessment.title}"?`)) return;
        await deleteAssessment(assessment.id);
      }
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  function openQuestions(assessment) {
    setQuestionsModal(assessment);
    setQLoading(true);
    listQuestions(assessment.id)
      .then((res) => setQuestions(res.data.data))
      .catch((err) => setError(err.message))
      .finally(() => setQLoading(false));
  }

  function refreshQuestions() {
    listQuestions(questionsModal.id).then((res) => setQuestions(res.data.data));
  }

  function openAddQuestion() {
    setQForm(EMPTY_QUESTION);
    setAddModalOpen(true);
  }

  function updateTestCase(list, setter, field, idx, key, value) {
    setter((f) => ({ ...f, [field]: f[field].map((tc, i) => (i === idx ? { ...tc, [key]: value } : tc)) }));
  }

  async function handleAddQuestion(e) {
    e.preventDefault();
    setQSaving(true);
    setError('');
    try {
      await addQuestion(questionsModal.id, {
        title: qForm.title,
        problemStatement: qForm.problemStatement,
        inputFormat: qForm.inputFormat || null,
        outputFormat: qForm.outputFormat || null,
        constraints: qForm.constraints || null,
        examples: [],
        difficulty: qForm.difficulty,
        marks: Number(qForm.marks),
        timeLimitSeconds: Number(qForm.timeLimitSeconds),
        memoryLimitMb: Number(qForm.memoryLimitMb),
        allowedLanguages: qForm.allowedLanguages,
        publicTestCases: qForm.publicTestCases.filter((tc) => tc.input && tc.expectedOutput),
        hiddenTestCases: qForm.hiddenTestCases.filter((tc) => tc.input && tc.expectedOutput),
      });
      setAddModalOpen(false);
      refreshQuestions();
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setQSaving(false);
    }
  }

  async function handleDeleteQuestion(questionId) {
    if (!window.confirm('Delete this question?')) return;
    try {
      await deleteQuestion(questionsModal.id, questionId);
      refreshQuestions();
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  function openAiModal() {
    setAiForm({ topic: '', language: 'JAVA', difficulty: '', questionCount: 3 });
    setAiPreview(null);
    setAiModalOpen(true);
  }

  async function handleAiPreview(e) {
    e.preventDefault();
    setError('');
    setAiSaving(true);
    try {
      const res = await generateQuestionsPreview({
        topic: aiForm.topic,
        language: aiForm.language,
        difficulty: aiForm.difficulty || null,
        questionCount: Number(aiForm.questionCount),
      });
      setAiPreview(res.data.data);
    } catch (err) {
      setError(err.message);
    } finally {
      setAiSaving(false);
    }
  }

  async function handleAiSave() {
    setAiSaving(true);
    setError('');
    try {
      await saveAiQuestions(questionsModal.id, aiPreview);
      setAiModalOpen(false);
      setAiPreview(null);
      refreshQuestions();
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setAiSaving(false);
    }
  }

  function openAnalytics(assessment) {
    setAnalyticsModal(assessment);
    setAnalytics(null);
    getAnalytics(assessment.id)
      .then((res) => setAnalytics(res.data.data))
      .catch((err) => setError(err.message));
  }

  const selectStyle = { padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', fontSize: 14 };
  const batchNameById = Object.fromEntries(batches.map((b) => [b.id, b.name]));

  const columns = [
    { key: 'title', header: 'Title' },
    { key: 'batch', header: 'Batch', render: (r) => batchNameById[r.batchId] || r.batchId },
    { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    { key: 'questions', header: 'Questions', render: (r) => r.questionIds?.length ?? 0 },
    {
      key: 'actions',
      header: '',
      render: (r) => (
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {r.status === 'DRAFT' && (
            <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handleAction(r, 'publish')}>
              Publish
            </button>
          )}
          <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} onClick={() => openQuestions(r)}>
            Questions
          </button>
          <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} onClick={() => openAnalytics(r)}>
            Analytics
          </button>
          <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handleAction(r, 'duplicate')}>
            Duplicate
          </button>
          {r.status === 'PUBLISHED' && (
            <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handleAction(r, 'archive')}>
              Archive
            </button>
          )}
          <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12, color: 'var(--color-danger)' }} disabled={busyId === r.id} onClick={() => handleAction(r, 'delete')}>
            Delete
          </button>
        </div>
      ),
    },
  ];

  return (
    <AppShell roleLabel="Trainer" sidebar={<TrainerSidebar />}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
        <h1 style={{ fontSize: 24 }}>Coding assessments</h1>
        <button className="btn btn-primary" onClick={openCreate}>
          + New assessment
        </button>
      </div>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      <DataTable columns={columns} rows={rows} loading={loading} emptyLabel="No assessments yet." page={page} totalPages={totalPages} onPageChange={setPage} />

      <Modal open={createModalOpen} title="New coding assessment" onClose={() => setCreateModalOpen(false)}>
        <form onSubmit={handleCreate} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="field">
            <label htmlFor="atitle">Title</label>
            <input id="atitle" required value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="adesc">Description</label>
            <input id="adesc" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="abatch">Batch</label>
            <select id="abatch" required value={form.batchId} onChange={(e) => setForm((f) => ({ ...f, batchId: e.target.value }))} style={selectStyle}>
              <option value="">Select…</option>
              {batches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
            </select>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="astart">Start</label>
              <input id="astart" type="datetime-local" required value={form.startTime} onChange={(e) => setForm((f) => ({ ...f, startTime: e.target.value }))} />
            </div>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="aend">End</label>
              <input id="aend" type="datetime-local" required value={form.endTime} onChange={(e) => setForm((f) => ({ ...f, endTime: e.target.value }))} />
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="adur">Duration (min)</label>
              <input id="adur" type="number" min={1} value={form.durationMinutes} onChange={(e) => setForm((f) => ({ ...f, durationMinutes: e.target.value }))} />
            </div>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="apass">Passing marks</label>
              <input id="apass" type="number" min={0} value={form.passingMarks} onChange={(e) => setForm((f) => ({ ...f, passingMarks: e.target.value }))} />
            </div>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="aattempts">Max attempts</label>
              <input id="aattempts" type="number" min={1} value={form.maxAttempts} onChange={(e) => setForm((f) => ({ ...f, maxAttempts: e.target.value }))} />
            </div>
          </div>
          <div className="field">
            <label>Allowed languages</label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
              {LANGUAGES.map((l) => (
                <label key={l} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                  <input type="checkbox" checked={form.allowedLanguages.includes(l)} onChange={() => toggleLang(form, setForm, l)} />
                  {l}
                </label>
              ))}
            </div>
          </div>
          {formError && <p className="error-text">{formError}</p>}
          <button className="btn btn-primary" type="submit" disabled={saving}>
            {saving ? 'Creating…' : 'Create assessment (draft)'}
          </button>
        </form>
      </Modal>

      <Modal open={Boolean(questionsModal)} title={`Questions — ${questionsModal?.title || ''}`} onClose={() => setQuestionsModal(null)}>
        <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
          <button className="btn btn-ghost" style={{ padding: '6px 14px', fontSize: 12 }} onClick={openAddQuestion}>
            + Add question
          </button>
          <button className="btn btn-ghost" style={{ padding: '6px 14px', fontSize: 12 }} onClick={openAiModal}>
            Generate with AI
          </button>
        </div>
        {qLoading ? (
          <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
        ) : questions.length === 0 ? (
          <p style={{ color: 'var(--color-text-muted)' }}>No questions yet.</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {questions.map((q) => (
              <div key={q.id} style={{ padding: '12px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)' }}>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4 }}>{q.title}</div>
                <div style={{ fontSize: 12, color: 'var(--color-text-muted)', marginBottom: 8 }}>
                  {q.difficulty} · {q.marks} marks {q.aiGenerated && '· AI generated'}
                </div>
                <button className="btn btn-ghost" style={{ padding: '4px 10px', fontSize: 11, color: 'var(--color-danger)' }} onClick={() => handleDeleteQuestion(q.id)}>
                  Delete
                </button>
              </div>
            ))}
          </div>
        )}
      </Modal>

      <Modal open={addModalOpen} title="Add question" onClose={() => setAddModalOpen(false)}>
        <form onSubmit={handleAddQuestion} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="field">
            <label htmlFor="qtitle2">Title</label>
            <input id="qtitle2" required value={qForm.title} onChange={(e) => setQForm((f) => ({ ...f, title: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="qstatement">Problem statement</label>
            <textarea id="qstatement" required rows={4} value={qForm.problemStatement} onChange={(e) => setQForm((f) => ({ ...f, problemStatement: e.target.value }))} style={{ fontFamily: 'var(--font-body)', fontSize: 14, padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', resize: 'vertical' }} />
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="qdiff3">Difficulty</label>
              <select id="qdiff3" value={qForm.difficulty} onChange={(e) => setQForm((f) => ({ ...f, difficulty: e.target.value }))} style={selectStyle}>
                {DIFFICULTIES.map((d) => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div className="field" style={{ width: 90 }}>
              <label htmlFor="qmarks2">Marks</label>
              <input id="qmarks2" type="number" min={1} value={qForm.marks} onChange={(e) => setQForm((f) => ({ ...f, marks: e.target.value }))} />
            </div>
          </div>
          <div className="field">
            <label>Allowed languages</label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
              {LANGUAGES.map((l) => (
                <label key={l} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                  <input type="checkbox" checked={qForm.allowedLanguages.includes(l)} onChange={() => toggleLang(qForm, setQForm, l)} />
                  {l}
                </label>
              ))}
            </div>
          </div>
          <div className="field">
            <label>Public test case</label>
            <input placeholder="Input" value={qForm.publicTestCases[0].input} onChange={(e) => updateTestCase(qForm.publicTestCases, setQForm, 'publicTestCases', 0, 'input', e.target.value)} style={{ marginBottom: 6 }} />
            <input placeholder="Expected output" value={qForm.publicTestCases[0].expectedOutput} onChange={(e) => updateTestCase(qForm.publicTestCases, setQForm, 'publicTestCases', 0, 'expectedOutput', e.target.value)} />
          </div>
          <button className="btn btn-primary" type="submit" disabled={qSaving}>
            {qSaving ? 'Saving…' : 'Add question'}
          </button>
        </form>
      </Modal>

      <Modal open={aiModalOpen} title="Generate questions with AI" onClose={() => setAiModalOpen(false)}>
        {!aiPreview ? (
          <form onSubmit={handleAiPreview} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div className="field">
              <label htmlFor="aitopic">Topic</label>
              <input id="aitopic" required value={aiForm.topic} onChange={(e) => setAiForm((f) => ({ ...f, topic: e.target.value }))} />
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <div className="field" style={{ flex: 1 }}>
                <label htmlFor="ailang">Language</label>
                <select id="ailang" value={aiForm.language} onChange={(e) => setAiForm((f) => ({ ...f, language: e.target.value }))} style={selectStyle}>
                  {LANGUAGES.map((l) => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>
              <div className="field" style={{ flex: 1 }}>
                <label htmlFor="aidiff">Difficulty (blank = mixed)</label>
                <select id="aidiff" value={aiForm.difficulty} onChange={(e) => setAiForm((f) => ({ ...f, difficulty: e.target.value }))} style={selectStyle}>
                  <option value="">Mixed</option>
                  {DIFFICULTIES.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div className="field" style={{ width: 110 }}>
                <label htmlFor="aicount">Count</label>
                <input id="aicount" type="number" min={1} max={20} value={aiForm.questionCount} onChange={(e) => setAiForm((f) => ({ ...f, questionCount: e.target.value }))} />
              </div>
            </div>
            <button className="btn btn-primary" type="submit" disabled={aiSaving}>
              {aiSaving ? 'Generating…' : 'Preview questions'}
            </button>
          </form>
        ) : (
          <div>
            <p style={{ fontSize: 13, color: 'var(--color-text-muted)', marginBottom: 14 }}>Review before saving — nothing is stored yet.</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 16, maxHeight: 300, overflowY: 'auto' }}>
              {aiPreview.map((q, i) => (
                <div key={i} style={{ padding: '10px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 13 }}>
                  <strong>{q.title}</strong> — {q.difficulty}, {q.marks} marks
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="btn btn-primary" onClick={handleAiSave} disabled={aiSaving}>
                {aiSaving ? 'Saving…' : `Save all ${aiPreview.length} questions`}
              </button>
              <button className="btn btn-ghost" onClick={() => setAiPreview(null)}>
                Discard & retry
              </button>
            </div>
          </div>
        )}
      </Modal>

      <Modal open={Boolean(analyticsModal)} title={`Analytics — ${analyticsModal?.title || ''}`} onClose={() => setAnalyticsModal(null)}>
        {!analytics ? (
          <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, fontSize: 14 }}>
            <p>Students: {analytics.totalStudents} · Submitted: {analytics.submittedCount} · Pending: {analytics.pendingCount}</p>
            <p>Highest: {analytics.highestScore} · Lowest: {analytics.lowestScore} · Average: {analytics.averageScore}</p>
            <p>Pass rate: {analytics.passPercentage}% · Fail rate: {analytics.failPercentage}%</p>
            {analytics.leaderboard?.length > 0 && (
              <div>
                <strong>Leaderboard</strong>
                {analytics.leaderboard.map((l, i) => (
                  <div key={i} style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>
                    #{i + 1} {l.studentId} — {l.totalMarks} marks
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </Modal>
    </AppShell>
  );
}
