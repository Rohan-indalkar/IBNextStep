import { useEffect, useState, useCallback } from 'react';
import AppShell from '../../components/AppShell';
import TrainerSidebar from '../../components/TrainerSidebar';
import DataTable from '../../components/DataTable';
import Modal from '../../components/Modal';
import useMyBatches from '../../hooks/useMyBatches';
import {
  listQuizzes,
  generateQuiz,
  deleteQuiz,
  publishQuiz,
  regenerateEntireQuiz,
  addQuestion,
  editQuestion,
  deleteQuestion,
  regenerateQuestion,
  getQuizAnalytics,
} from '../../api/quiz';

const DIFFICULTIES = ['EASY', 'MEDIUM', 'HARD'];
const QUESTION_TYPES = ['MCQ', 'TRUE_FALSE', 'MULTIPLE_SELECT', 'FILL_BLANK', 'SHORT_ANSWER'];

const EMPTY_GEN = {
  title: '', prompt: '', topic: '', subTopics: '', difficulty: 'MEDIUM',
  questionCount: 10, durationMinutes: 20, passingPercentage: 60, batchId: '',
  language: 'English', questionTypes: ['MCQ'],
};

function StatusBadge({ status }) {
  const colors = { DRAFT: '#888', SCHEDULED: 'var(--color-warning)', PUBLISHED: 'var(--color-success)', ACTIVE: 'var(--color-success)', COMPLETED: 'var(--color-text-muted)', EXPIRED: 'var(--color-danger)', ARCHIVED: '#888' };
  return <span style={{ fontSize: 12, fontWeight: 700, padding: '3px 10px', borderRadius: 999, color: '#fff', background: colors[status] || '#888' }}>{status}</span>;
}

export default function Quizzes() {
  const { batches } = useMyBatches();
  const [rows, setRows] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState(null);

  const [genModalOpen, setGenModalOpen] = useState(false);
  const [genForm, setGenForm] = useState(EMPTY_GEN);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  const [questionsModal, setQuestionsModal] = useState(null);
  const [questionModalIdx, setQuestionModalIdx] = useState(null);
  const [questionForm, setQuestionForm] = useState(null);
  const [qSaving, setQSaving] = useState(false);

  const [analyticsModal, setAnalyticsModal] = useState(null);
  const [analytics, setAnalytics] = useState(null);

  const load = useCallback(() => {
    setLoading(true);
    setError('');
    listQuizzes({ page, size: 10 })
      .then((res) => {
        const paged = res.data.data;
        setRows(paged.content);
        setTotalPages(paged.totalPages);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [page]);

  useEffect(() => {
    load();
  }, [load]);

  function toggleType(t) {
    setGenForm((f) => ({
      ...f,
      questionTypes: f.questionTypes.includes(t) ? f.questionTypes.filter((x) => x !== t) : [...f.questionTypes, t],
    }));
  }

  async function handleGenerate(e) {
    e.preventDefault();
    setFormError('');
    setSaving(true);
    try {
      await generateQuiz({
        title: genForm.title || null,
        prompt: genForm.prompt,
        topic: genForm.topic,
        subTopics: genForm.subTopics ? genForm.subTopics.split(',').map((s) => s.trim()).filter(Boolean) : [],
        difficulty: genForm.difficulty,
        questionCount: Number(genForm.questionCount),
        durationMinutes: Number(genForm.durationMinutes),
        passingPercentage: Number(genForm.passingPercentage),
        batchId: genForm.batchId,
        language: genForm.language,
        questionTypes: genForm.questionTypes,
      });
      setGenModalOpen(false);
      setGenForm(EMPTY_GEN);
      load();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleAction(quiz, action) {
    setBusyId(quiz.id);
    setError('');
    try {
      if (action === 'publish') await publishQuiz(quiz.id);
      else if (action === 'regenerate') {
        if (!window.confirm('Regenerate the entire quiz? This replaces all questions.')) return;
        await regenerateEntireQuiz(quiz.id);
      } else if (action === 'delete') {
        if (!window.confirm(`Delete "${quiz.title}"?`)) return;
        await deleteQuiz(quiz.id);
      }
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  function openQuestions(quiz) {
    setQuestionsModal(quiz);
  }

  function openEditQuestion(idx) {
    const q = questionsModal.questions[idx].question;
    setQuestionModalIdx(idx);
    setQuestionForm({ ...q, options: (q.options || []).join(', '), correctAnswers: (q.correctAnswers || []).join(', ') });
  }

  function openAddQuestion() {
    setQuestionModalIdx('new');
    setQuestionForm({ questionText: '', options: '', correctAnswer: '', correctAnswers: '', explanation: '', type: 'MCQ', difficulty: 'MEDIUM', marks: 1 });
  }

  async function handleSaveQuestion(e) {
    e.preventDefault();
    setQSaving(true);
    setError('');
    try {
      const payload = {
        questionText: questionForm.questionText,
        options: questionForm.options ? questionForm.options.split(',').map((s) => s.trim()).filter(Boolean) : [],
        correctAnswer: questionForm.correctAnswer || null,
        correctAnswers: questionForm.correctAnswers ? questionForm.correctAnswers.split(',').map((s) => s.trim()).filter(Boolean) : [],
        explanation: questionForm.explanation || null,
        type: questionForm.type,
        difficulty: questionForm.difficulty,
        marks: Number(questionForm.marks),
      };
      let res;
      if (questionModalIdx === 'new') {
        res = await addQuestion(questionsModal.id, payload);
      } else {
        const order = questionsModal.questions[questionModalIdx].order;
        res = await editQuestion(questionsModal.id, order, payload);
      }
      setQuestionsModal(res.data.data);
      setQuestionModalIdx(null);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setQSaving(false);
    }
  }

  async function handleDeleteQuestion(idx) {
    if (!window.confirm('Delete this question?')) return;
    const order = questionsModal.questions[idx].order;
    try {
      const res = await deleteQuestion(questionsModal.id, order);
      setQuestionsModal(res.data.data);
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleRegenerateQuestion(idx) {
    const order = questionsModal.questions[idx].order;
    const instruction = window.prompt('Additional instruction (optional):') || '';
    try {
      const res = await regenerateQuestion(questionsModal.id, order, instruction ? { additionalInstruction: instruction } : null);
      setQuestionsModal(res.data.data);
    } catch (err) {
      setError(err.message);
    }
  }

  function openAnalytics(quiz) {
    setAnalyticsModal(quiz);
    setAnalytics(null);
    getQuizAnalytics(quiz.id)
      .then((res) => setAnalytics(res.data.data))
      .catch((err) => setError(err.message));
  }

  const selectStyle = { padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', fontSize: 14 };
  const batchNameById = Object.fromEntries(batches.map((b) => [b.id, b.name]));

  const columns = [
    { key: 'title', header: 'Title' },
    { key: 'topic', header: 'Topic' },
    { key: 'batch', header: 'Batch', render: (r) => batchNameById[r.batchId] || r.batchId },
    { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    { key: 'questionCount', header: 'Questions' },
    {
      key: 'actions',
      header: '',
      render: (r) => (
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {r.status === 'DRAFT' && (
            <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handleAction(r, 'publish')}>
              Publish
            </button>
          )}
          <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} onClick={() => openQuestions(r)}>
            Questions
          </button>
          <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} onClick={() => openAnalytics(r)}>
            Analytics
          </button>
          {r.status === 'DRAFT' && (
            <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handleAction(r, 'regenerate')}>
              Regenerate all
            </button>
          )}
          <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12, color: 'var(--color-danger)' }} disabled={busyId === r.id} onClick={() => handleAction(r, 'delete')}>
            Delete
          </button>
        </div>
      ),
    },
  ];

  return (
    <AppShell roleLabel="Trainer" sidebar={<TrainerSidebar />}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
        <h1 style={{ fontSize: 24 }}>Quizzes</h1>
        <button className="btn btn-primary" onClick={() => setGenModalOpen(true)}>
          + Generate quiz with AI
        </button>
      </div>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      <DataTable columns={columns} rows={rows} loading={loading} emptyLabel="No quizzes yet." page={page} totalPages={totalPages} onPageChange={setPage} />

      <Modal open={genModalOpen} title="Generate quiz with AI" onClose={() => setGenModalOpen(false)}>
        <form onSubmit={handleGenerate} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="field">
            <label htmlFor="qtitle">Title (optional)</label>
            <input id="qtitle" value={genForm.title} onChange={(e) => setGenForm((f) => ({ ...f, title: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="qprompt">Prompt</label>
            <input id="qprompt" required value={genForm.prompt} onChange={(e) => setGenForm((f) => ({ ...f, prompt: e.target.value }))} placeholder="Instructions for the AI" />
          </div>
          <div className="field">
            <label htmlFor="qtopic">Topic</label>
            <input id="qtopic" required value={genForm.topic} onChange={(e) => setGenForm((f) => ({ ...f, topic: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="qsub">Sub-topics (comma-separated)</label>
            <input id="qsub" value={genForm.subTopics} onChange={(e) => setGenForm((f) => ({ ...f, subTopics: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="qbatch">Batch</label>
            <select id="qbatch" required value={genForm.batchId} onChange={(e) => setGenForm((f) => ({ ...f, batchId: e.target.value }))} style={selectStyle}>
              <option value="">Select…</option>
              {batches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
            </select>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="qdiff">Difficulty</label>
              <select id="qdiff" value={genForm.difficulty} onChange={(e) => setGenForm((f) => ({ ...f, difficulty: e.target.value }))} style={selectStyle}>
                {DIFFICULTIES.map((d) => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div className="field" style={{ width: 110 }}>
              <label htmlFor="qcount">Questions</label>
              <input id="qcount" type="number" min={1} max={100} value={genForm.questionCount} onChange={(e) => setGenForm((f) => ({ ...f, questionCount: e.target.value }))} />
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="qdur">Duration (min)</label>
              <input id="qdur" type="number" min={1} value={genForm.durationMinutes} onChange={(e) => setGenForm((f) => ({ ...f, durationMinutes: e.target.value }))} />
            </div>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="qpass">Passing %</label>
              <input id="qpass" type="number" min={0} max={100} value={genForm.passingPercentage} onChange={(e) => setGenForm((f) => ({ ...f, passingPercentage: e.target.value }))} />
            </div>
          </div>
          <div className="field">
            <label>Question types</label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
              {QUESTION_TYPES.map((t) => (
                <label key={t} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                  <input type="checkbox" checked={genForm.questionTypes.includes(t)} onChange={() => toggleType(t)} />
                  {t.replace('_', ' ')}
                </label>
              ))}
            </div>
          </div>
          {formError && <p className="error-text">{formError}</p>}
          <button className="btn btn-primary" type="submit" disabled={saving}>
            {saving ? 'Generating…' : 'Generate quiz'}
          </button>
        </form>
      </Modal>

      <Modal open={Boolean(questionsModal)} title={`Questions — ${questionsModal?.title || ''}`} onClose={() => setQuestionsModal(null)}>
        <button className="btn btn-ghost" style={{ padding: '6px 14px', fontSize: 12, marginBottom: 14 }} onClick={openAddQuestion}>
          + Add question
        </button>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {(questionsModal?.questions || []).map((entry, idx) => (
            <div key={idx} style={{ padding: '12px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)' }}>
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 6 }}>
                {entry.order}. {entry.question.questionText}
              </div>
              <div style={{ fontSize: 12, color: 'var(--color-text-muted)', marginBottom: 8 }}>
                {entry.question.type} · {entry.question.marks} marks
              </div>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                <button className="btn btn-ghost" style={{ padding: '4px 10px', fontSize: 11 }} onClick={() => openEditQuestion(idx)}>Edit</button>
                <button className="btn btn-ghost" style={{ padding: '4px 10px', fontSize: 11 }} onClick={() => handleRegenerateQuestion(idx)}>Regenerate</button>
                <button className="btn btn-ghost" style={{ padding: '4px 10px', fontSize: 11, color: 'var(--color-danger)' }} onClick={() => handleDeleteQuestion(idx)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      </Modal>

      <Modal open={questionModalIdx !== null} title={questionModalIdx === 'new' ? 'Add question' : 'Edit question'} onClose={() => setQuestionModalIdx(null)}>
        {questionForm && (
          <form onSubmit={handleSaveQuestion} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div className="field">
              <label htmlFor="qtext">Question text</label>
              <input id="qtext" required value={questionForm.questionText} onChange={(e) => setQuestionForm((f) => ({ ...f, questionText: e.target.value }))} />
            </div>
            <div className="field">
              <label htmlFor="qtype">Type</label>
              <select id="qtype" value={questionForm.type} onChange={(e) => setQuestionForm((f) => ({ ...f, type: e.target.value }))} style={selectStyle}>
                {QUESTION_TYPES.map((t) => <option key={t} value={t}>{t.replace('_', ' ')}</option>)}
              </select>
            </div>
            <div className="field">
              <label htmlFor="qoptions">Options (comma-separated)</label>
              <input id="qoptions" value={questionForm.options} onChange={(e) => setQuestionForm((f) => ({ ...f, options: e.target.value }))} />
            </div>
            <div className="field">
              <label htmlFor="qcanswer">Correct answer</label>
              <input id="qcanswer" value={questionForm.correctAnswer} onChange={(e) => setQuestionForm((f) => ({ ...f, correctAnswer: e.target.value }))} />
            </div>
            <div className="field">
              <label htmlFor="qcanswers">Correct answers (MULTIPLE_SELECT only, comma-separated)</label>
              <input id="qcanswers" value={questionForm.correctAnswers} onChange={(e) => setQuestionForm((f) => ({ ...f, correctAnswers: e.target.value }))} />
            </div>
            <div className="field">
              <label htmlFor="qexpl">Explanation</label>
              <input id="qexpl" value={questionForm.explanation} onChange={(e) => setQuestionForm((f) => ({ ...f, explanation: e.target.value }))} />
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <div className="field" style={{ flex: 1 }}>
                <label htmlFor="qdiff2">Difficulty</label>
                <select id="qdiff2" value={questionForm.difficulty} onChange={(e) => setQuestionForm((f) => ({ ...f, difficulty: e.target.value }))} style={selectStyle}>
                  {DIFFICULTIES.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div className="field" style={{ width: 100 }}>
                <label htmlFor="qmarks">Marks</label>
                <input id="qmarks" type="number" min={1} value={questionForm.marks} onChange={(e) => setQuestionForm((f) => ({ ...f, marks: e.target.value }))} />
              </div>
            </div>
            <button className="btn btn-primary" type="submit" disabled={qSaving}>
              {qSaving ? 'Saving…' : 'Save question'}
            </button>
          </form>
        )}
      </Modal>

      <Modal open={Boolean(analyticsModal)} title={`Analytics — ${analyticsModal?.title || ''}`} onClose={() => setAnalyticsModal(null)}>
        {!analytics ? (
          <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, fontSize: 14 }}>
            <p>Assigned: {analytics.totalAssigned} · Attempted: {analytics.attemptedCount} · Pending: {analytics.pendingCount}</p>
            <p>Highest: {analytics.highestScore} · Lowest: {analytics.lowestScore} · Average: {analytics.averageScore}</p>
            <p>Pass rate: {analytics.passPercentage}% · Fail rate: {analytics.failPercentage}%</p>
            {analytics.leaderboard?.length > 0 && (
              <div>
                <strong>Leaderboard</strong>
                {analytics.leaderboard.map((l, i) => (
                  <div key={i} style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>
                    #{i + 1} {l.studentId} — {l.percentage}%
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </Modal>
    </AppShell>
  );
}
