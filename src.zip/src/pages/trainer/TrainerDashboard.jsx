import { Link } from 'react-router-dom';
import AppShell from '../../components/AppShell';
import TrainerSidebar from '../../components/TrainerSidebar';
import StatCard from '../../components/StatCard';
import useMyBatches from '../../hooks/useMyBatches';

export default function TrainerDashboard() {
  const { batches, stats, loading, error } = useMyBatches();

  return (
    <AppShell roleLabel="Trainer" sidebar={<TrainerSidebar />}>
      <h1 style={{ fontSize: 24, marginBottom: 24 }}>Overview</h1>

      {error && <p className="error-text" style={{ marginBottom: 16 }}>{error}</p>}

      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 32 }}>
        <StatCard label="My batches" value={loading ? '—' : stats.myBatches} />
        <StatCard label="Active batches" value={loading ? '—' : stats.activeBatches} accent />
        <StatCard label="Total students" value={loading ? '—' : stats.totalStudents} />
      </div>

      <div className="card" style={{ padding: 28, marginBottom: 24 }}>
        <h2 style={{ fontSize: 17, marginBottom: 16 }}>My batches</h2>
        {loading ? (
          <p style={{ color: 'var(--color-text-muted)', fontSize: 14 }}>Loading…</p>
        ) : batches.length === 0 ? (
          <p style={{ color: 'var(--color-text-muted)', fontSize: 14 }}>
            You're not assigned to any batches yet — an admin needs to assign you first.
          </p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {batches.map((b) => (
              <div
                key={b.id}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  padding: '12px 16px',
                  background: 'var(--color-surface-alt)',
                  borderRadius: 'var(--radius-sm)',
                  fontSize: 14,
                }}
              >
                <span style={{ fontWeight: 600 }}>{b.name}</span>
                <span style={{ color: 'var(--color-text-muted)' }}>{b.studentCount || 0} students</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        <Link to="/app/trainer/study-materials" className="btn btn-primary">
          Study materials
        </Link>
        <Link to="/app/trainer/attendance" className="btn btn-ghost">
          Mark attendance
        </Link>
        <Link to="/app/trainer/assignments" className="btn btn-ghost">
          Assignments
        </Link>
      </div>
    </AppShell>
  );
}
