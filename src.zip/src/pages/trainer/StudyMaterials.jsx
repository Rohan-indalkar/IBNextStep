import { useEffect, useState, useCallback } from 'react';
import AppShell from '../../components/AppShell';
import TrainerSidebar from '../../components/TrainerSidebar';
import DataTable from '../../components/DataTable';
import Modal from '../../components/Modal';
import useMyBatches from '../../hooks/useMyBatches';
import { searchCourses } from '../../api/course';
import {
  searchMaterials,
  uploadMaterial,
  deleteMaterial,
  publishMaterialNow,
  scheduleMaterial,
  unpublishMaterial,
} from '../../api/studyMaterial';

const SKILL_TYPES = ['TECHNICAL', 'SOFT_SKILL'];
const DIFFICULTIES = ['BEGINNER', 'INTERMEDIATE', 'ADVANCED'];
const CONTENT_TYPES = ['PDF', 'PPT', 'DOCX', 'ZIP', 'RECORDED_SESSION', 'VIDEO_LINK', 'EXTERNAL_RESOURCE_LINK'];
const FILE_BASED = new Set(['PDF', 'PPT', 'DOCX', 'ZIP', 'RECORDED_SESSION']);
const STATUSES = ['DRAFT', 'SCHEDULED', 'PUBLISHED'];

const EMPTY_FORM = {
  title: '',
  description: '',
  courseId: '',
  module: '',
  topic: '',
  skillType: 'TECHNICAL',
  difficultyLevel: 'BEGINNER',
  contentType: 'PDF',
  externalUrl: '',
  batchIds: [],
  visibleFrom: '',
  expiryDate: '',
  publishOption: 'SAVE_AS_DRAFT',
  scheduledAt: '',
};

export default function StudyMaterials() {
  const { batches } = useMyBatches();
  const [courses, setCourses] = useState([]);
  const [rows, setRows] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [files, setFiles] = useState([]);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    setError('');
    searchMaterials({ search: search || undefined, status: statusFilter || undefined, page, size: 10 })
      .then((res) => {
        const paged = res.data.data;
        setRows(paged.content);
        setTotalPages(paged.totalPages);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [search, statusFilter, page]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    searchCourses({ page: 0, size: 100 })
      .then((res) => setCourses(res.data.data.content))
      .catch(() => {});
  }, []);

  function openCreate() {
    setForm(EMPTY_FORM);
    setFiles([]);
    setFormError('');
    setModalOpen(true);
  }

  function toggleBatch(id) {
    setForm((f) => ({
      ...f,
      batchIds: f.batchIds.includes(id) ? f.batchIds.filter((b) => b !== id) : [...f.batchIds, id],
    }));
  }

  async function handleSave(e) {
    e.preventDefault();
    setFormError('');
    if (form.publishOption === 'SCHEDULE_PUBLISH' && !form.scheduledAt) {
      setFormError('Pick a schedule date/time.');
      return;
    }
    if (!FILE_BASED.has(form.contentType) && !form.externalUrl) {
      setFormError('A URL is required for this content type.');
      return;
    }
    setSaving(true);
    try {
      const payload = {
        title: form.title,
        description: form.description || null,
        courseId: form.courseId,
        module: form.module || null,
        topic: form.topic || null,
        skillType: form.skillType,
        difficultyLevel: form.difficultyLevel,
        contentType: form.contentType,
        externalUrl: FILE_BASED.has(form.contentType) ? null : form.externalUrl,
        batchIds: form.batchIds,
        visibleFrom: form.visibleFrom || null,
        expiryDate: form.expiryDate || null,
        publishOption: form.publishOption,
        scheduledAt: form.publishOption === 'SCHEDULE_PUBLISH' ? new Date(form.scheduledAt).toISOString() : null,
      };
      await uploadMaterial(payload, FILE_BASED.has(form.contentType) ? files : []);
      setModalOpen(false);
      load();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleAction(material, action) {
    setBusyId(material.id);
    setError('');
    try {
      if (action === 'publish') await publishMaterialNow(material.id);
      else if (action === 'unpublish') await unpublishMaterial(material.id);
      else if (action === 'delete') {
        if (!window.confirm(`Delete "${material.title}"?`)) return;
        await deleteMaterial(material.id);
      }
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  async function handleSchedule(material) {
    const input = window.prompt('Schedule publish for (YYYY-MM-DDTHH:mm), e.g. 2026-08-15T09:00');
    if (!input) return;
    setBusyId(material.id);
    try {
      await scheduleMaterial(material.id, new Date(input).toISOString());
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  const courseNameById = Object.fromEntries(courses.map((c) => [c.id, c.name]));
  const selectStyle = { padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', fontSize: 14 };

  const columns = [
    { key: 'title', header: 'Title' },
    { key: 'course', header: 'Course', render: (r) => courseNameById[r.courseId] || r.courseName || '—' },
    { key: 'contentType', header: 'Type' },
    {
      key: 'status',
      header: 'Status',
      render: (r) => (
        <span
          style={{
            fontSize: 12,
            fontWeight: 700,
            padding: '3px 10px',
            borderRadius: 999,
            color: r.status === 'PUBLISHED' ? 'var(--color-success)' : 'var(--color-text-muted)',
            background: r.status === 'PUBLISHED' ? 'rgba(47,158,99,0.12)' : 'var(--color-surface-alt)',
          }}
        >
          {r.effectiveStatus || r.status}
        </span>
      ),
    },
    { key: 'downloads', header: 'Downloads', render: (r) => r.downloadCount ?? 0 },
    {
      key: 'actions',
      header: '',
      render: (r) => (
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {r.status !== 'PUBLISHED' && (
            <button className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handleAction(r, 'publish')}>
              Publish now
            </button>
          )}
          {r.status === 'DRAFT' && (
            <button className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handleSchedule(r)}>
              Schedule
            </button>
          )}
          {r.status === 'PUBLISHED' && (
            <button className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handleAction(r, 'unpublish')}>
              Unpublish
            </button>
          )}
          <button
            className="btn btn-ghost"
            style={{ padding: '5px 12px', fontSize: 12, color: 'var(--color-danger)' }}
            disabled={busyId === r.id}
            onClick={() => handleAction(r, 'delete')}
          >
            Delete
          </button>
        </div>
      ),
    },
  ];

  return (
    <AppShell roleLabel="Trainer" sidebar={<TrainerSidebar />}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
        <h1 style={{ fontSize: 24 }}>Study materials</h1>
        <button className="btn btn-primary" onClick={openCreate}>
          + Upload material
        </button>
      </div>

      <div style={{ display: 'flex', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
        <input
          type="text"
          placeholder="Search title, topic…"
          value={search}
          onChange={(e) => {
            setPage(0);
            setSearch(e.target.value);
          }}
          style={{ flex: 1, minWidth: 220, padding: '10px 14px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', fontSize: 14, background: 'var(--color-surface)' }}
        />
        <select
          value={statusFilter}
          onChange={(e) => {
            setPage(0);
            setStatusFilter(e.target.value);
          }}
          style={selectStyle}
        >
          <option value="">All statuses</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      <DataTable
        columns={columns}
        rows={rows}
        loading={loading}
        emptyLabel="No study materials yet — upload one to get started."
        page={page}
        totalPages={totalPages}
        onPageChange={setPage}
      />

      <Modal open={modalOpen} title="Upload study material" onClose={() => setModalOpen(false)}>
        <form onSubmit={handleSave} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="field">
            <label htmlFor="title">Title</label>
            <input id="title" required value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="description">Description</label>
            <input id="description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="course">Course</label>
            <select id="course" required value={form.courseId} onChange={(e) => setForm((f) => ({ ...f, courseId: e.target.value }))} style={selectStyle}>
              <option value="">Select a course…</option>
              {courses.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="module">Module</label>
              <input id="module" value={form.module} onChange={(e) => setForm((f) => ({ ...f, module: e.target.value }))} />
            </div>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="topic">Topic</label>
              <input id="topic" value={form.topic} onChange={(e) => setForm((f) => ({ ...f, topic: e.target.value }))} />
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="skillType">Skill type</label>
              <select id="skillType" value={form.skillType} onChange={(e) => setForm((f) => ({ ...f, skillType: e.target.value }))} style={selectStyle}>
                {SKILL_TYPES.map((s) => (
                  <option key={s} value={s}>
                    {s.replace('_', ' ')}
                  </option>
                ))}
              </select>
            </div>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="difficulty">Difficulty</label>
              <select id="difficulty" value={form.difficultyLevel} onChange={(e) => setForm((f) => ({ ...f, difficultyLevel: e.target.value }))} style={selectStyle}>
                {DIFFICULTIES.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="field">
            <label htmlFor="contentType">Content type</label>
            <select id="contentType" value={form.contentType} onChange={(e) => setForm((f) => ({ ...f, contentType: e.target.value }))} style={selectStyle}>
              {CONTENT_TYPES.map((c) => (
                <option key={c} value={c}>
                  {c.replace('_', ' ')}
                </option>
              ))}
            </select>
          </div>

          {FILE_BASED.has(form.contentType) ? (
            <div className="field">
              <label htmlFor="files">File(s)</label>
              <input id="files" type="file" multiple onChange={(e) => setFiles(Array.from(e.target.files || []))} />
            </div>
          ) : (
            <div className="field">
              <label htmlFor="externalUrl">URL</label>
              <input id="externalUrl" required value={form.externalUrl} onChange={(e) => setForm((f) => ({ ...f, externalUrl: e.target.value }))} placeholder="https://…" />
            </div>
          )}

          <div className="field">
            <label>Batches (leave empty to save as unassigned draft)</label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginTop: 4 }}>
              {batches.map((b) => (
                <label key={b.id} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                  <input type="checkbox" checked={form.batchIds.includes(b.id)} onChange={() => toggleBatch(b.id)} />
                  {b.name}
                </label>
              ))}
              {batches.length === 0 && <span style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>No batches assigned to you yet.</span>}
            </div>
          </div>

          <div style={{ display: 'flex', gap: 10 }}>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="visibleFrom">Visible from</label>
              <input id="visibleFrom" type="date" value={form.visibleFrom} onChange={(e) => setForm((f) => ({ ...f, visibleFrom: e.target.value }))} />
            </div>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="expiryDate">Expiry date</label>
              <input id="expiryDate" type="date" value={form.expiryDate} onChange={(e) => setForm((f) => ({ ...f, expiryDate: e.target.value }))} />
            </div>
          </div>

          <div className="field">
            <label htmlFor="publishOption">Publish option</label>
            <select id="publishOption" value={form.publishOption} onChange={(e) => setForm((f) => ({ ...f, publishOption: e.target.value }))} style={selectStyle}>
              <option value="SAVE_AS_DRAFT">Save as draft</option>
              <option value="PUBLISH_NOW">Publish now</option>
              <option value="SCHEDULE_PUBLISH">Schedule publish</option>
            </select>
          </div>
          {form.publishOption === 'SCHEDULE_PUBLISH' && (
            <div className="field">
              <label htmlFor="scheduledAt">Schedule for</label>
              <input id="scheduledAt" type="datetime-local" value={form.scheduledAt} onChange={(e) => setForm((f) => ({ ...f, scheduledAt: e.target.value }))} />
            </div>
          )}

          {formError && <p className="error-text">{formError}</p>}
          <button className="btn btn-primary" type="submit" disabled={saving}>
            {saving ? 'Saving…' : 'Save material'}
          </button>
        </form>
      </Modal>
    </AppShell>
  );
}
