import { useEffect, useState, useCallback } from 'react';
import AppShell from '../../components/AppShell';
import TrainerSidebar from '../../components/TrainerSidebar';
import DataTable from '../../components/DataTable';
import Modal from '../../components/Modal';
import useMyBatches from '../../hooks/useMyBatches';
import { getBatchRoster } from '../../api/trainerBatch';
import {
  createMockInterviews,
  rescheduleMockInterview,
  cancelMockInterview,
  markConducted,
  submitEvaluation,
  publishEvaluation,
  searchMockInterviews,
  getMockInterviewAnalytics,
} from '../../api/mockInterview';

const INTERVIEW_TYPES = ['TECHNICAL', 'HR', 'SOFT_SKILLS'];

const EMPTY_CREATE = { batchId: '', studentIds: [], interviewType: 'TECHNICAL', scheduledAt: '', durationMinutes: 30, meetingLink: '', notes: '' };
const EMPTY_EVAL = { scores: { 'Problem Solving': 5, Communication: 5 }, strengths: '', weaknesses: '', improvementSuggestions: '', additionalComments: '' };

function StatusBadge({ status }) {
  const colors = { SCHEDULED: 'var(--color-warning)', CONDUCTED: 'var(--color-info)', EVALUATED: 'var(--color-primary)', PUBLISHED: 'var(--color-success)', CANCELLED: 'var(--color-danger)' };
  return <span style={{ fontSize: 12, fontWeight: 700, padding: '3px 10px', borderRadius: 999, color: '#fff', background: colors[status] || '#888' }}>{status}</span>;
}

export default function MockInterviews() {
  const { batches } = useMyBatches();
  const [batchStudents, setBatchStudents] = useState([]);
  const [rosterLoading, setRosterLoading] = useState(false);
  const [rows, setRows] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState(null);

  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [form, setForm] = useState(EMPTY_CREATE);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  const [evalModal, setEvalModal] = useState(null);
  const [evalForm, setEvalForm] = useState(EMPTY_EVAL);
  const [evalSaving, setEvalSaving] = useState(false);

  const [analyticsOpen, setAnalyticsOpen] = useState(false);
  const [analytics, setAnalytics] = useState(null);

  const load = useCallback(() => {
    setLoading(true);
    setError('');
    searchMockInterviews({ page, size: 10 })
      .then((res) => {
        const paged = res.data.data;
        setRows(paged.content);
        setTotalPages(paged.totalPages);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [page]);

  useEffect(() => {
    load();
  }, [load]);

  // Load the roster fresh whenever the selected batch changes — trainers can't
  // list students generally, only within a batch they're assigned to.
  useEffect(() => {
    if (!form.batchId) {
      setBatchStudents([]);
      return;
    }
    let cancelled = false;
    setRosterLoading(true);
    getBatchRoster(form.batchId)
      .then((res) => {
        if (!cancelled) setBatchStudents(res.data.data);
      })
      .catch(() => {
        if (!cancelled) setBatchStudents([]);
      })
      .finally(() => {
        if (!cancelled) setRosterLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [form.batchId]);

  const batchNameById = Object.fromEntries(batches.map((b) => [b.id, b.name]));

  function toggleStudent(id) {
    setForm((f) => ({ ...f, studentIds: f.studentIds.includes(id) ? f.studentIds.filter((s) => s !== id) : [...f.studentIds, id] }));
  }

  function openCreate() {
    setForm(EMPTY_CREATE);
    setFormError('');
    setCreateModalOpen(true);
  }

  async function handleCreate(e) {
    e.preventDefault();
    setFormError('');
    if (form.studentIds.length === 0) {
      setFormError('Select at least one student.');
      return;
    }
    setSaving(true);
    try {
      await createMockInterviews({
        batchId: form.batchId,
        studentIds: form.studentIds,
        interviewType: form.interviewType,
        scheduledAt: new Date(form.scheduledAt).toISOString(),
        durationMinutes: form.durationMinutes ? Number(form.durationMinutes) : null,
        meetingLink: form.meetingLink || null,
        notes: form.notes || null,
      });
      setCreateModalOpen(false);
      load();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleCancel(interview) {
    const reason = window.prompt('Cancellation reason:');
    if (!reason) return;
    setBusyId(interview.id);
    try {
      await cancelMockInterview(interview.id, reason);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  async function handleReschedule(interview) {
    const input = window.prompt('New date/time (YYYY-MM-DDTHH:mm):');
    if (!input) return;
    setBusyId(interview.id);
    try {
      await rescheduleMockInterview(interview.id, { scheduledAt: new Date(input).toISOString() });
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  async function handleMarkConducted(interview) {
    setBusyId(interview.id);
    try {
      await markConducted(interview.id);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  async function handlePublish(interview) {
    setBusyId(interview.id);
    try {
      await publishEvaluation(interview.id);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  function openEval(interview) {
    setEvalModal(interview);
    setEvalForm(EMPTY_EVAL);
  }

  function updateScore(key, value) {
    setEvalForm((f) => ({ ...f, scores: { ...f.scores, [key]: Number(value) } }));
  }

  async function handleSubmitEval(e) {
    e.preventDefault();
    setEvalSaving(true);
    setError('');
    try {
      await submitEvaluation(evalModal.id, {
        scores: evalForm.scores,
        strengths: evalForm.strengths ? evalForm.strengths.split(',').map((s) => s.trim()).filter(Boolean) : [],
        weaknesses: evalForm.weaknesses ? evalForm.weaknesses.split(',').map((s) => s.trim()).filter(Boolean) : [],
        improvementSuggestions: evalForm.improvementSuggestions ? evalForm.improvementSuggestions.split(',').map((s) => s.trim()).filter(Boolean) : [],
        additionalComments: evalForm.additionalComments || null,
      });
      setEvalModal(null);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setEvalSaving(false);
    }
  }

  function openAnalytics() {
    setAnalyticsOpen(true);
    setAnalytics(null);
    getMockInterviewAnalytics({})
      .then((res) => setAnalytics(res.data.data))
      .catch((err) => setError(err.message));
  }

  const selectStyle = { padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', fontSize: 14 };

  const columns = [
    { key: 'student', header: 'Student', render: (r) => r.studentName || r.studentId },
    { key: 'batch', header: 'Batch', render: (r) => batchNameById[r.batchId] || r.batchId },
    { key: 'type', header: 'Type', render: (r) => r.interviewType },
    { key: 'scheduledAt', header: 'When', render: (r) => (r.scheduledAt ? new Date(r.scheduledAt).toLocaleString() : '—') },
    { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    {
      key: 'actions',
      header: '',
      render: (r) => (
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {r.status === 'SCHEDULED' && (
            <>
              <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handleMarkConducted(r)}>
                Mark conducted
              </button>
              <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handleReschedule(r)}>
                Reschedule
              </button>
              <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12, color: 'var(--color-danger)' }} disabled={busyId === r.id} onClick={() => handleCancel(r)}>
                Cancel
              </button>
            </>
          )}
          {r.status === 'CONDUCTED' && (
            <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} onClick={() => openEval(r)}>
              Evaluate
            </button>
          )}
          {r.status === 'EVALUATED' && (
            <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handlePublish(r)}>
              Publish report
            </button>
          )}
        </div>
      ),
    },
  ];

  return (
    <AppShell roleLabel="Trainer" sidebar={<TrainerSidebar />}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
        <h1 style={{ fontSize: 24 }}>Mock interviews</h1>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="btn btn-ghost" onClick={openAnalytics}>
            Analytics
          </button>
          <button className="btn btn-primary" onClick={openCreate}>
            + Schedule interview
          </button>
        </div>
      </div>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      <DataTable columns={columns} rows={rows} loading={loading} emptyLabel="No mock interviews yet." page={page} totalPages={totalPages} onPageChange={setPage} />

      <Modal open={createModalOpen} title="Schedule mock interview" onClose={() => setCreateModalOpen(false)}>
        <form onSubmit={handleCreate} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="field">
            <label htmlFor="mibatch">Batch</label>
            <select id="mibatch" required value={form.batchId} onChange={(e) => setForm((f) => ({ ...f, batchId: e.target.value, studentIds: [] }))} style={selectStyle}>
              <option value="">Select…</option>
              {batches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
            </select>
          </div>
          {form.batchId && (
            <div className="field">
              <label>Students</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, maxHeight: 140, overflowY: 'auto' }}>
                {batchStudents.map((s) => (
                  <label key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                    <input type="checkbox" checked={form.studentIds.includes(s.id)} onChange={() => toggleStudent(s.id)} />
                    {s.firstName} {s.lastName}
                  </label>
                ))}
                {rosterLoading && <span style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Loading students…</span>}
                {!rosterLoading && batchStudents.length === 0 && <span style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>No students in this batch.</span>}
              </div>
            </div>
          )}
          <div className="field">
            <label htmlFor="mitype">Interview type</label>
            <select id="mitype" value={form.interviewType} onChange={(e) => setForm((f) => ({ ...f, interviewType: e.target.value }))} style={selectStyle}>
              {INTERVIEW_TYPES.map((t) => <option key={t} value={t}>{t.replace('_', ' ')}</option>)}
            </select>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="miwhen">Scheduled for</label>
              <input id="miwhen" type="datetime-local" required value={form.scheduledAt} onChange={(e) => setForm((f) => ({ ...f, scheduledAt: e.target.value }))} />
            </div>
            <div className="field" style={{ width: 120 }}>
              <label htmlFor="midur">Duration (min)</label>
              <input id="midur" type="number" min={1} value={form.durationMinutes} onChange={(e) => setForm((f) => ({ ...f, durationMinutes: e.target.value }))} />
            </div>
          </div>
          <div className="field">
            <label htmlFor="milink">Meeting link (optional)</label>
            <input id="milink" value={form.meetingLink} onChange={(e) => setForm((f) => ({ ...f, meetingLink: e.target.value }))} placeholder="Leave blank to auto-generate" />
          </div>
          <div className="field">
            <label htmlFor="minotes">Notes (included in invite)</label>
            <input id="minotes" value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} />
          </div>
          {formError && <p className="error-text">{formError}</p>}
          <button className="btn btn-primary" type="submit" disabled={saving}>
            {saving ? 'Scheduling…' : 'Schedule'}
          </button>
        </form>
      </Modal>

      <Modal open={Boolean(evalModal)} title={`Evaluate — ${evalModal?.studentName || ''}`} onClose={() => setEvalModal(null)}>
        <form onSubmit={handleSubmitEval} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="field">
            <label>Scores (out of 10)</label>
            {Object.entries(evalForm.scores).map(([key, val]) => (
              <div key={key} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
                <span style={{ fontSize: 13, flex: 1 }}>{key}</span>
                <input type="number" min={0} max={10} value={val} onChange={(e) => updateScore(key, e.target.value)} style={{ width: 70 }} />
              </div>
            ))}
          </div>
          <div className="field">
            <label htmlFor="strengths">Strengths (comma-separated)</label>
            <input id="strengths" value={evalForm.strengths} onChange={(e) => setEvalForm((f) => ({ ...f, strengths: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="weaknesses">Weaknesses (comma-separated)</label>
            <input id="weaknesses" value={evalForm.weaknesses} onChange={(e) => setEvalForm((f) => ({ ...f, weaknesses: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="suggestions">Improvement suggestions (comma-separated)</label>
            <input id="suggestions" value={evalForm.improvementSuggestions} onChange={(e) => setEvalForm((f) => ({ ...f, improvementSuggestions: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="comments">Additional comments</label>
            <textarea id="comments" rows={3} value={evalForm.additionalComments} onChange={(e) => setEvalForm((f) => ({ ...f, additionalComments: e.target.value }))} style={{ fontFamily: 'var(--font-body)', fontSize: 14, padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', resize: 'vertical' }} />
          </div>
          <button className="btn btn-primary" type="submit" disabled={evalSaving}>
            {evalSaving ? 'Saving…' : 'Save evaluation'}
          </button>
        </form>
      </Modal>

      <Modal open={analyticsOpen} title="Mock interview analytics" onClose={() => setAnalyticsOpen(false)}>
        {!analytics ? (
          <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, fontSize: 14 }}>
            <p>
              Scheduled: {analytics.totalScheduled} · Conducted: {analytics.totalConducted} · Evaluated: {analytics.totalEvaluated} · Published:{' '}
              {analytics.totalPublished} · Cancelled: {analytics.totalCancelled}
            </p>
            {analytics.averageOverallRating != null && <p>Average overall rating: {analytics.averageOverallRating}/10</p>}
            {analytics.averageRatingByInterviewType && Object.keys(analytics.averageRatingByInterviewType).length > 0 && (
              <div>
                <strong>By interview type</strong>
                {Object.entries(analytics.averageRatingByInterviewType).map(([k, v]) => (
                  <div key={k} style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>{k}: {v}/10</div>
                ))}
              </div>
            )}
            {analytics.averageScoreByParameter && Object.keys(analytics.averageScoreByParameter).length > 0 && (
              <div>
                <strong>By parameter</strong>
                {Object.entries(analytics.averageScoreByParameter).map(([k, v]) => (
                  <div key={k} style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>{k}: {v}/10</div>
                ))}
              </div>
            )}
          </div>
        )}
      </Modal>
    </AppShell>
  );
}
