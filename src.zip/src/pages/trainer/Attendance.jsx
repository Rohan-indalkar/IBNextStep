import { useEffect, useState, useCallback } from 'react';
import AppShell from '../../components/AppShell';
import TrainerSidebar from '../../components/TrainerSidebar';
import useMyBatches from '../../hooks/useMyBatches';
import {
  getStudentListForMarking,
  markAttendance,
  getDailySummary,
  getMonthlySummary,
} from '../../api/attendance';

const STATUSES = ['PRESENT', 'ABSENT', 'LATE'];
const STATUS_COLOR = { PRESENT: 'var(--color-success)', ABSENT: 'var(--color-danger)', LATE: 'var(--color-warning)' };

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

export default function Attendance() {
  const { batches } = useMyBatches();
  const [batchId, setBatchId] = useState('');
  const [date, setDate] = useState(todayIso());
  const [students, setStudents] = useState([]);
  const [marks, setMarks] = useState({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [dailySummary, setDailySummary] = useState(null);

  const [monthYear, setMonthYear] = useState(new Date().getFullYear());
  const [monthNum, setMonthNum] = useState(new Date().getMonth() + 1);
  const [monthlySummary, setMonthlySummary] = useState(null);
  const [monthlyLoading, setMonthlyLoading] = useState(false);

  const loadRoster = useCallback(() => {
    if (!batchId || !date) return;
    setLoading(true);
    setError('');
    getStudentListForMarking(batchId, date)
      .then((res) => {
        const list = res.data.data;
        setStudents(list);
        const initial = {};
        list.forEach((s) => {
          initial[s.studentId] = { status: s.status || '', remarks: s.remarks || '' };
        });
        setMarks(initial);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));

    getDailySummary(batchId, date)
      .then((res) => setDailySummary(res.data.data))
      .catch(() => {});
  }, [batchId, date]);

  useEffect(() => {
    loadRoster();
  }, [loadRoster]);

  useEffect(() => {
    if (batches.length && !batchId) setBatchId(batches[0].id);
  }, [batches, batchId]);

  function setMark(studentId, field, value) {
    setMarks((m) => ({ ...m, [studentId]: { ...m[studentId], [field]: value } }));
  }

  async function handleSave() {
    setError('');
    setNotice('');
    const entries = Object.entries(marks)
      .filter(([, v]) => v.status)
      .map(([studentId, v]) => ({ studentId, status: v.status, remarks: v.remarks || null }));
    if (entries.length === 0) {
      setError('Mark at least one student before saving.');
      return;
    }
    setSaving(true);
    try {
      await markAttendance({ batchId, date, entries });
      setNotice('Attendance saved.');
      loadRoster();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  function loadMonthly() {
    if (!batchId) return;
    setMonthlyLoading(true);
    getMonthlySummary(batchId, monthYear, monthNum)
      .then((res) => setMonthlySummary(res.data.data))
      .catch((err) => setError(err.message))
      .finally(() => setMonthlyLoading(false));
  }

  const selectStyle = { padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', fontSize: 14 };

  return (
    <AppShell roleLabel="Trainer" sidebar={<TrainerSidebar />}>
      <h1 style={{ fontSize: 24, marginBottom: 20 }}>Attendance</h1>

      <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
        <select value={batchId} onChange={(e) => setBatchId(e.target.value)} style={selectStyle}>
          <option value="">Select a batch…</option>
          {batches.map((b) => (
            <option key={b.id} value={b.id}>
              {b.name}
            </option>
          ))}
        </select>
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} style={selectStyle} />
      </div>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}
      {notice && <p style={{ color: 'var(--color-success)', fontSize: 13, fontWeight: 600, marginBottom: 12 }}>{notice}</p>}

      {dailySummary && (
        <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
          <span style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>
            {dailySummary.presentCount} present · {dailySummary.absentCount} absent · {dailySummary.lateCount} late ·{' '}
            {dailySummary.notMarkedCount} not marked
          </span>
        </div>
      )}

      {!batchId ? (
        <p style={{ color: 'var(--color-text-muted)' }}>Select a batch to mark attendance.</p>
      ) : loading ? (
        <p style={{ color: 'var(--color-text-muted)' }}>Loading roster…</p>
      ) : students.length === 0 ? (
        <p style={{ color: 'var(--color-text-muted)' }}>No students in this batch.</p>
      ) : (
        <div className="card" style={{ overflow: 'hidden', marginBottom: 32 }}>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 14 }}>
              <thead>
                <tr style={{ background: 'var(--color-surface-alt)' }}>
                  <th style={{ textAlign: 'left', padding: '12px 16px', fontSize: 12, fontWeight: 700, color: 'var(--color-text-muted)' }}>Student</th>
                  <th style={{ textAlign: 'left', padding: '12px 16px', fontSize: 12, fontWeight: 700, color: 'var(--color-text-muted)' }}>Status</th>
                  <th style={{ textAlign: 'left', padding: '12px 16px', fontSize: 12, fontWeight: 700, color: 'var(--color-text-muted)' }}>Remarks</th>
                </tr>
              </thead>
              <tbody>
                {students.map((s) => (
                  <tr key={s.studentId} style={{ borderTop: '1px solid var(--color-border)' }}>
                    <td style={{ padding: '10px 16px' }}>
                      {s.firstName} {s.lastName}
                    </td>
                    <td style={{ padding: '10px 16px' }}>
                      <div style={{ display: 'flex', gap: 6 }}>
                        {STATUSES.map((st) => (
                          <button
                            key={st}
                            type="button"
                            onClick={() => setMark(s.studentId, 'status', st)}
                            style={{
                              padding: '5px 12px',
                              borderRadius: 999,
                              fontSize: 12,
                              fontWeight: 700,
                              border: '1.5px solid ' + (marks[s.studentId]?.status === st ? STATUS_COLOR[st] : 'var(--color-border)'),
                              background: marks[s.studentId]?.status === st ? STATUS_COLOR[st] : 'transparent',
                              color: marks[s.studentId]?.status === st ? '#fff' : 'var(--color-text-muted)',
                              cursor: 'pointer',
                            }}
                          >
                            {st}
                          </button>
                        ))}
                      </div>
                    </td>
                    <td style={{ padding: '10px 16px' }}>
                      <input
                        value={marks[s.studentId]?.remarks || ''}
                        onChange={(e) => setMark(s.studentId, 'remarks', e.target.value)}
                        placeholder="Optional"
                        style={{ width: '100%', padding: '6px 10px', border: '1px solid var(--color-border)', borderRadius: 6, fontSize: 13 }}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div style={{ padding: '12px 16px', borderTop: '1px solid var(--color-border)' }}>
            <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
              {saving ? 'Saving…' : 'Save attendance'}
            </button>
          </div>
        </div>
      )}

      <div className="card" style={{ padding: 24 }}>
        <h2 style={{ fontSize: 16, marginBottom: 16 }}>Monthly summary</h2>
        <div style={{ display: 'flex', gap: 10, marginBottom: 16, flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <div className="field">
            <label htmlFor="myear">Year</label>
            <input id="myear" type="number" value={monthYear} onChange={(e) => setMonthYear(Number(e.target.value))} style={{ width: 100, padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)' }} />
          </div>
          <div className="field">
            <label htmlFor="mmonth">Month</label>
            <input id="mmonth" type="number" min="1" max="12" value={monthNum} onChange={(e) => setMonthNum(Number(e.target.value))} style={{ width: 80, padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)' }} />
          </div>
          <button className="btn btn-ghost" onClick={loadMonthly} disabled={!batchId || monthlyLoading} style={{ height: 44 }}>
            {monthlyLoading ? 'Loading…' : 'View summary'}
          </button>
        </div>

        {monthlySummary && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {monthlySummary.students.map((s) => (
              <div
                key={s.studentId}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  padding: '10px 14px',
                  background: 'var(--color-surface-alt)',
                  borderRadius: 'var(--radius-sm)',
                  fontSize: 14,
                }}
              >
                <span>{s.firstName} {s.lastName}</span>
                <span style={{ color: 'var(--color-text-muted)' }}>
                  {s.presentCount}/{s.totalDays} present — {s.attendancePercentage}%
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}
