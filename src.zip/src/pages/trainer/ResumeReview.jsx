import { useEffect, useState } from 'react';
import AppShell from '../../components/AppShell';
import TrainerSidebar from '../../components/TrainerSidebar';
import Modal from '../../components/Modal';
import { searchUsers } from '../../api/user';
import {
  listResumes,
  getStudentResume,
  analyzeResume,
  autoReview,
  autoReviewAll,
  reviewResume,
  downloadResumeFile,
} from '../../api/resume';

const STATUSES = ['', 'PENDING_REVIEW', 'NEEDS_CHANGES', 'APPROVED'];

function StatusBadge({ status }) {
  const colors = { PENDING_REVIEW: 'var(--color-warning)', NEEDS_CHANGES: 'var(--color-danger)', APPROVED: 'var(--color-success)' };
  return <span style={{ fontSize: 12, fontWeight: 700, padding: '3px 10px', borderRadius: 999, color: '#fff', background: colors[status] || '#888' }}>{status}</span>;
}

export default function ResumeReview() {
  const [students, setStudents] = useState([]);
  const [resumes, setResumes] = useState([]);
  const [statusFilter, setStatusFilter] = useState('PENDING_REVIEW');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [bulkRunning, setBulkRunning] = useState(false);
  const [bulkResult, setBulkResult] = useState(null);

  const [detailModal, setDetailModal] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [busy, setBusy] = useState(false);

  const [suggestions, setSuggestions] = useState('');
  const [score, setScore] = useState(70);
  const [reviewStatus, setReviewStatus] = useState('APPROVED');

  function load() {
    setLoading(true);
    setError('');
    listResumes(statusFilter || undefined)
      .then((res) => setResumes(res.data.data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, [statusFilter]);

  useEffect(() => {
    searchUsers({ role: 'STUDENT', page: 0, size: 200 })
      .then((res) => setStudents(res.data.data.content))
      .catch(() => {});
  }, []);

  const studentNameById = Object.fromEntries(students.map((s) => [s.id, `${s.firstName} ${s.lastName}`]));

  function openDetail(resume) {
    setDetailModal(resume);
    setAnalysis(null);
    const latest = resume.versions[resume.versions.length - 1];
    setSuggestions(latest?.suggestions || '');
    setScore(latest?.score ?? 70);
    setReviewStatus('APPROVED');
  }

  async function handleAnalyze(refresh = false) {
    setAnalyzing(true);
    setError('');
    try {
      const res = await analyzeResume(detailModal.studentId, refresh);
      setAnalysis(res.data.data);
      if (res.data.data.suggestedReviewText) setSuggestions(res.data.data.suggestedReviewText);
      if (res.data.data.overallScore != null) setScore(res.data.data.overallScore);
    } catch (err) {
      setError(err.message);
    } finally {
      setAnalyzing(false);
    }
  }

  async function handleAutoReview() {
    setBusy(true);
    setError('');
    try {
      await autoReview(detailModal.studentId, false);
      setDetailModal(null);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleManualReview(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await reviewResume(detailModal.studentId, { suggestions, score: Number(score), status: reviewStatus });
      setDetailModal(null);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleDownload() {
    try {
      const latest = detailModal.versions[detailModal.versions.length - 1];
      await downloadResumeFile(detailModal.studentId, latest.fileName);
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleAutoReviewAll() {
    if (!window.confirm('Auto-review every pending resume in your batches? Each student will be notified.')) return;
    setBulkRunning(true);
    setBulkResult(null);
    setError('');
    try {
      const res = await autoReviewAll(false);
      setBulkResult(res.data.data);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBulkRunning(false);
    }
  }

  const selectStyle = { padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', fontSize: 14 };

  return (
    <AppShell roleLabel="Trainer" sidebar={<TrainerSidebar />}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
        <h1 style={{ fontSize: 24 }}>Resume review</h1>
        <button className="btn btn-primary" onClick={handleAutoReviewAll} disabled={bulkRunning}>
          {bulkRunning ? 'Running…' : 'Auto-review all pending'}
        </button>
      </div>

      {bulkResult && (
        <p style={{ fontSize: 13, color: 'var(--color-text-muted)', marginBottom: 16 }}>
          Processed {bulkResult.length} resumes — {bulkResult.filter((r) => r.success).length} succeeded.
        </p>
      )}

      <div style={{ marginBottom: 20 }}>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} style={selectStyle}>
          {STATUSES.map((s) => (
            <option key={s} value={s}>{s || 'All statuses'}</option>
          ))}
        </select>
      </div>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      {loading ? (
        <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
      ) : resumes.length === 0 ? (
        <p style={{ color: 'var(--color-text-muted)' }}>No resumes found for this filter.</p>
      ) : (
        <div className="card" style={{ overflow: 'hidden' }}>
          {resumes.map((r) => {
            const latest = r.versions[r.versions.length - 1];
            return (
              <div key={r.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 18px', borderBottom: '1px solid var(--color-border)' }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{studentNameById[r.studentId] || r.studentId}</div>
                  <div style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>Version {latest?.versionNumber} · {latest?.fileName}</div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <StatusBadge status={r.currentStatus} />
                  <button className="btn btn-ghost" style={{ padding: '6px 14px', fontSize: 12 }} onClick={() => openDetail(r)}>
                    Review
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal open={Boolean(detailModal)} title={`Resume — ${studentNameById[detailModal?.studentId] || ''}`} onClose={() => setDetailModal(null)}>
        {detailModal && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <button className="btn btn-ghost" style={{ padding: '6px 14px', fontSize: 12, alignSelf: 'flex-start' }} onClick={handleDownload}>
              Download resume file
            </button>

            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn btn-ghost" style={{ padding: '6px 14px', fontSize: 12 }} onClick={() => handleAnalyze(false)} disabled={analyzing}>
                {analyzing ? 'Analyzing…' : 'Analyze with AI'}
              </button>
              {analysis && (
                <button className="btn btn-ghost" style={{ padding: '6px 14px', fontSize: 12 }} onClick={() => handleAnalyze(true)} disabled={analyzing}>
                  Refresh analysis
                </button>
              )}
              <button className="btn btn-ghost" style={{ padding: '6px 14px', fontSize: 12 }} onClick={handleAutoReview} disabled={busy}>
                Auto-review with AI
              </button>
            </div>

            {analysis && (
              <div style={{ padding: '12px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 13 }}>
                <p style={{ fontWeight: 700, marginBottom: 6 }}>AI score: {analysis.overallScore ?? 'N/A'}/100</p>
                <p style={{ marginBottom: 8 }}>{analysis.summary}</p>
                {analysis.strengths?.length > 0 && <p><strong>Strengths:</strong> {analysis.strengths.join(', ')}</p>}
                {analysis.weaknesses?.length > 0 && <p><strong>Weaknesses:</strong> {analysis.weaknesses.join(', ')}</p>}
                {analysis.missingSections?.length > 0 && <p><strong>Missing:</strong> {analysis.missingSections.join(', ')}</p>}
                {analysis.atsIssues?.length > 0 && <p><strong>ATS issues:</strong> {analysis.atsIssues.join(', ')}</p>}
              </div>
            )}

            <form onSubmit={handleManualReview} style={{ display: 'flex', flexDirection: 'column', gap: 14, borderTop: '1px solid var(--color-border)', paddingTop: 16 }}>
              <p style={{ fontSize: 13, fontWeight: 700 }}>Manual review</p>
              <div className="field">
                <label htmlFor="suggestions">Suggestions</label>
                <textarea id="suggestions" required rows={4} value={suggestions} onChange={(e) => setSuggestions(e.target.value)} style={{ fontFamily: 'var(--font-body)', fontSize: 14, padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', resize: 'vertical' }} />
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <div className="field" style={{ flex: 1 }}>
                  <label htmlFor="score">Score (0-100)</label>
                  <input id="score" type="number" min={0} max={100} required value={score} onChange={(e) => setScore(e.target.value)} />
                </div>
                <div className="field" style={{ flex: 1 }}>
                  <label htmlFor="reviewStatus">Status</label>
                  <select id="reviewStatus" value={reviewStatus} onChange={(e) => setReviewStatus(e.target.value)} style={selectStyle}>
                    <option value="APPROVED">Approved</option>
                    <option value="NEEDS_CHANGES">Needs changes</option>
                  </select>
                </div>
              </div>
              <button className="btn btn-primary" type="submit" disabled={busy}>
                {busy ? 'Submitting…' : 'Submit review'}
              </button>
            </form>
          </div>
        )}
      </Modal>
    </AppShell>
  );
}
