import { useEffect, useState, useCallback, useRef, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import AppShell from '../../components/AppShell';
import AdminSidebar from '../../components/AdminSidebar';
import { LoadingState, ErrorState, EmptyState } from '../../components/States';
import { useConfirm } from '../../components/ConfirmDialog';
import { useToast } from '../../context/ToastContext';
import {
  getBatch,
  assignTechnicalTrainer,
  changeTechnicalTrainer,
  assignSoftSkillTrainer,
  changeSoftSkillTrainer,
  addTimetableEntry,
  assignStudents,
  removeStudent,
  bulkImportStudents,
} from '../../api/batch';
import { searchUsers } from '../../api/user';

export default function BatchDetail() {
  const { id } = useParams();
  const fileInputRef = useRef(null);
  const confirm = useConfirm();
  const toast = useToast();

  const [batch, setBatch] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [technicalTrainers, setTechnicalTrainers] = useState([]);
  const [softSkillTrainers, setSoftSkillTrainers] = useState([]);
  const [students, setStudents] = useState([]);

  const [techTrainerId, setTechTrainerId] = useState('');
  const [softTrainerId, setSoftTrainerId] = useState('');
  const [savingTrainer, setSavingTrainer] = useState(false);

  const [entryDate, setEntryDate] = useState('');
  const [entryTopic, setEntryTopic] = useState('');
  const [entryTrainerId, setEntryTrainerId] = useState('');
  const [savingEntry, setSavingEntry] = useState(false);

  const [studentSearch, setStudentSearch] = useState('');
  const [selectedToAdd, setSelectedToAdd] = useState(new Set());
  const [savingStudents, setSavingStudents] = useState(false);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState(null);
  const [removingId, setRemovingId] = useState(null);

  const load = useCallback(() => {
    setLoading(true);
    setError('');
    getBatch(id)
      .then((res) => {
        const b = res.data.data;
        setBatch(b);
        setTechTrainerId(b.technicalTrainerId || '');
        setSoftTrainerId(b.softSkillTrainerId || '');
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    searchUsers({ role: 'TRAINER', page: 0, size: 100 })
      .then((res) => {
        const all = res.data.data.content;
        setTechnicalTrainers(all.filter((u) => u.trainerType === 'TECHNICAL'));
        setSoftSkillTrainers(all.filter((u) => u.trainerType === 'SOFT_SKILL'));
      })
      .catch(() => {});
    searchUsers({ role: 'STUDENT', page: 0, size: 200 })
      .then((res) => setStudents(res.data.data.content))
      .catch(() => {});
  }, []);

  const trainerNameById = Object.fromEntries(
    [...technicalTrainers, ...softSkillTrainers].map((t) => [t.id, `${t.firstName} ${t.lastName}`])
  );
  const studentById = Object.fromEntries(students.map((s) => [s.id, s]));
  const assignedStudentIds = new Set(batch?.studentIds || []);

  const availableStudents = useMemo(() => {
    const term = studentSearch.trim().toLowerCase();
    return students
      .filter((s) => !assignedStudentIds.has(s.id))
      .filter((s) => !term || `${s.firstName} ${s.lastName} ${s.email}`.toLowerCase().includes(term));
  }, [students, studentSearch, assignedStudentIds]);

  async function handleSaveTechTrainer() {
    if (!techTrainerId) return;
    setSavingTrainer(true);
    setError('');
    try {
      if (batch.technicalTrainerId) await changeTechnicalTrainer(id, techTrainerId);
      else await assignTechnicalTrainer(id, techTrainerId);
      toast.success('Technical trainer updated.');
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSavingTrainer(false);
    }
  }

  async function handleSaveSoftTrainer() {
    if (!softTrainerId) return;
    setSavingTrainer(true);
    setError('');
    try {
      if (batch.softSkillTrainerId) await changeSoftSkillTrainer(id, softTrainerId);
      else await assignSoftSkillTrainer(id, softTrainerId);
      toast.success('Soft skill trainer updated.');
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSavingTrainer(false);
    }
  }

  async function handleAddEntry(e) {
    e.preventDefault();
    setError('');
    setSavingEntry(true);
    try {
      await addTimetableEntry(id, { date: entryDate, topic: entryTopic, trainerId: entryTrainerId });
      setEntryDate('');
      setEntryTopic('');
      setEntryTrainerId('');
      toast.success('Timetable entry added.');
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSavingEntry(false);
    }
  }

  function toggleSelect(studentId) {
    setSelectedToAdd((prev) => {
      const next = new Set(prev);
      if (next.has(studentId)) next.delete(studentId);
      else next.add(studentId);
      return next;
    });
  }

  function selectAllVisible() {
    setSelectedToAdd((prev) => new Set([...prev, ...availableStudents.map((s) => s.id)]));
  }

  function clearSelection() {
    setSelectedToAdd(new Set());
  }

  // One real bulk call: PUT /admin/batches/{id}/students takes the full
  // student list, so N selections become a single request, not N requests.
  async function handleBulkAssign() {
    if (selectedToAdd.size === 0) return;
    setSavingStudents(true);
    setError('');
    try {
      await assignStudents(id, [...(batch.studentIds || []), ...selectedToAdd]);
      toast.success(`${selectedToAdd.size} student${selectedToAdd.size === 1 ? '' : 's'} assigned.`);
      setSelectedToAdd(new Set());
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSavingStudents(false);
    }
  }

  async function handleRemoveStudent(studentId, name) {
    const ok = await confirm(`Remove ${name} from this batch?`, { title: 'Remove student?', tone: 'danger' });
    if (!ok) return;
    setRemovingId(studentId);
    try {
      await removeStudent(id, studentId);
      toast.success('Student removed.');
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setRemovingId(null);
    }
  }

  async function handleBulkImport(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setImporting(true);
    setError('');
    setImportResult(null);
    try {
      const res = await bulkImportStudents(id, file);
      setImportResult(res.data.data);
      toast.success(`Imported ${res.data.data.successCount} of ${res.data.data.totalRows} rows.`);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setImporting(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  }

  if (loading) {
    return (
      <AppShell roleLabel="Administrator" sidebar={<AdminSidebar />}>
        <LoadingState rows={4} />
      </AppShell>
    );
  }

  if (!batch) {
    return (
      <AppShell roleLabel="Administrator" sidebar={<AdminSidebar />}>
        <ErrorState message={error || 'Batch not found.'} />
      </AppShell>
    );
  }

  return (
    <AppShell roleLabel="Administrator" sidebar={<AdminSidebar />}>
      <Link to="/app/admin/batches" style={{ fontSize: 13, color: 'var(--color-primary)', fontWeight: 600 }}>
        ← Back to batches
      </Link>
      <h1 style={{ fontSize: 24, margin: '10px 0 24px', fontFamily: 'var(--font-display)' }}>{batch.name}</h1>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 20, marginBottom: 24 }}>
        <div className="card" style={{ padding: 24 }}>
          <h2 style={{ fontSize: 16, marginBottom: 16 }}>Technical trainer</h2>
          <p style={{ fontSize: 14, color: 'var(--color-text-muted)', marginBottom: 12 }}>
            Currently: {batch.technicalTrainerId ? trainerNameById[batch.technicalTrainerId] || batch.technicalTrainerId : 'Unassigned'}
          </p>
          <div style={{ display: 'flex', gap: 8 }}>
            <select value={techTrainerId} onChange={(e) => setTechTrainerId(e.target.value)} style={{ flex: 1 }}>
              <option value="">Select trainer…</option>
              {technicalTrainers.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.firstName} {t.lastName}
                </option>
              ))}
            </select>
            <button className="btn btn-primary" style={{ padding: '8px 16px', fontSize: 13 }} disabled={savingTrainer || !techTrainerId} onClick={handleSaveTechTrainer}>
              {batch.technicalTrainerId ? 'Change' : 'Assign'}
            </button>
          </div>
        </div>

        <div className="card" style={{ padding: 24 }}>
          <h2 style={{ fontSize: 16, marginBottom: 16 }}>Soft skill trainer</h2>
          <p style={{ fontSize: 14, color: 'var(--color-text-muted)', marginBottom: 12 }}>
            Currently: {batch.softSkillTrainerId ? trainerNameById[batch.softSkillTrainerId] || batch.softSkillTrainerId : 'Unassigned'}
          </p>
          <div style={{ display: 'flex', gap: 8 }}>
            <select value={softTrainerId} onChange={(e) => setSoftTrainerId(e.target.value)} style={{ flex: 1 }}>
              <option value="">Select trainer…</option>
              {softSkillTrainers.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.firstName} {t.lastName}
                </option>
              ))}
            </select>
            <button className="btn btn-primary" style={{ padding: '8px 16px', fontSize: 13 }} disabled={savingTrainer || !softTrainerId} onClick={handleSaveSoftTrainer}>
              {batch.softSkillTrainerId ? 'Change' : 'Assign'}
            </button>
          </div>
        </div>
      </div>

      <div className="card" style={{ padding: 24, marginBottom: 24 }}>
        <h2 style={{ fontSize: 16, marginBottom: 16 }}>Timetable</h2>
        <form onSubmit={handleAddEntry} style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 18, alignItems: 'flex-end' }}>
          <div className="field">
            <label htmlFor="edate">Date</label>
            <input id="edate" type="date" required value={entryDate} onChange={(e) => setEntryDate(e.target.value)} />
          </div>
          <div className="field" style={{ flex: 1, minWidth: 180 }}>
            <label htmlFor="etopic">Topic</label>
            <input id="etopic" required value={entryTopic} onChange={(e) => setEntryTopic(e.target.value)} placeholder="e.g. Spring Boot basics" />
          </div>
          <div className="field">
            <label htmlFor="etrainer">Trainer</label>
            <select id="etrainer" required value={entryTrainerId} onChange={(e) => setEntryTrainerId(e.target.value)}>
              <option value="">Select…</option>
              {[...technicalTrainers, ...softSkillTrainers].map((t) => (
                <option key={t.id} value={t.id}>
                  {t.firstName} {t.lastName}
                </option>
              ))}
            </select>
          </div>
          <button className="btn btn-primary" type="submit" disabled={savingEntry} style={{ height: 44 }}>
            {savingEntry ? 'Adding…' : '+ Add entry'}
          </button>
        </form>

        {batch.timetable?.length ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {batch.timetable.map((entry, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 6, padding: '10px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 14 }}>
                <span style={{ fontWeight: 600 }}>{entry.date}</span>
                <span>{entry.topic}</span>
                <span style={{ color: 'var(--color-text-muted)' }}>{trainerNameById[entry.trainerId] || entry.trainerId}</span>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState title="No timetable entries yet" />
        )}
      </div>

      <div className="card" style={{ padding: 24 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, flexWrap: 'wrap', gap: 10 }}>
          <h2 style={{ fontSize: 16 }}>Enrolled students ({batch.studentIds?.length || 0})</h2>
          <div>
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.xlsx,.xls"
              onChange={handleBulkImport}
              style={{ display: 'none' }}
              id="bulk-import-input"
            />
            <label htmlFor="bulk-import-input" className="btn btn-ghost" style={{ padding: '8px 16px', fontSize: 13, cursor: 'pointer' }}>
              {importing ? 'Importing…' : 'Bulk import (CSV/Excel)'}
            </label>
          </div>
        </div>

        {importResult && (
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)', marginBottom: 14 }}>
            Imported {importResult.successCount} of {importResult.totalRows} rows
            {importResult.failureCount > 0 && ` — ${importResult.failureCount} failed`}.
          </p>
        )}

        {batch.studentIds?.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 24 }}>
            {batch.studentIds.map((sid) => {
              const s = studentById[sid];
              const name = s ? `${s.firstName} ${s.lastName}` : sid;
              return (
                <div key={sid} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 14px', borderBottom: '1px solid var(--color-border)', fontSize: 14 }}>
                  <span>{s ? `${name} (${s.email})` : sid}</span>
                  <button
                    onClick={() => handleRemoveStudent(sid, name)}
                    disabled={removingId === sid}
                    style={{ background: 'none', border: 'none', color: 'var(--color-danger)', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}
                  >
                    {removingId === sid ? 'Removing…' : 'Remove'}
                  </button>
                </div>
              );
            })}
          </div>
        )}

        <div style={{ borderTop: '1px solid var(--color-border)', paddingTop: 20 }}>
          <h3 style={{ fontSize: 14, marginBottom: 12 }}>Add students</h3>

          <div style={{ display: 'flex', gap: 10, marginBottom: 12, alignItems: 'center', flexWrap: 'wrap' }}>
            <input
              type="text"
              placeholder="Search students…"
              value={studentSearch}
              onChange={(e) => setStudentSearch(e.target.value)}
              aria-label="Search students to add"
              style={{ flex: 1, minWidth: 200 }}
            />
            <button className="btn btn-ghost" style={{ padding: '7px 14px', fontSize: 12 }} onClick={selectAllVisible} disabled={availableStudents.length === 0}>
              Select all {availableStudents.length} visible
            </button>
            <button className="btn btn-ghost" style={{ padding: '7px 14px', fontSize: 12 }} onClick={clearSelection} disabled={selectedToAdd.size === 0}>
              Clear selection
            </button>
          </div>

          {availableStudents.length === 0 ? (
            <EmptyState title={studentSearch ? 'No matching students' : 'All students are already in this batch'} />
          ) : (
            <div style={{ maxHeight: 260, overflowY: 'auto', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-sm)', marginBottom: 14 }}>
              {availableStudents.map((s) => (
                <label
                  key={s.id}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                    padding: '10px 14px',
                    fontSize: 14,
                    borderBottom: '1px solid var(--color-border)',
                    cursor: 'pointer',
                    background: selectedToAdd.has(s.id) ? 'var(--color-surface-alt)' : 'transparent',
                  }}
                >
                  <input type="checkbox" checked={selectedToAdd.has(s.id)} onChange={() => toggleSelect(s.id)} />
                  {s.firstName} {s.lastName} <span style={{ color: 'var(--color-text-muted)' }}>({s.email})</span>
                </label>
              ))}
            </div>
          )}

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
            <span style={{ fontSize: 13, color: 'var(--color-text-muted)', fontWeight: 600 }}>
              {selectedToAdd.size} selected
            </span>
            <button className="btn btn-primary" onClick={handleBulkAssign} disabled={selectedToAdd.size === 0 || savingStudents}>
              {savingStudents ? 'Assigning…' : `Assign ${selectedToAdd.size || ''} student${selectedToAdd.size === 1 ? '' : 's'}`}
            </button>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
