import { useEffect, useState, useCallback } from 'react';
import AppShell from '../../components/AppShell';
import AdminSidebar from '../../components/AdminSidebar';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import Modal from '../../components/Modal';
import StatusBadge from '../../components/StatusBadge';
import { ErrorState, EmptyState } from '../../components/States';
import { useConfirm } from '../../components/ConfirmDialog';
import { useToast } from '../../context/ToastContext';
import useDebouncedValue from '../../hooks/useDebouncedValue';
import {
  searchCourses,
  createCourse,
  updateCourse,
  assignCourseSkills,
  deactivateCourse,
  listSkills,
  createSkill,
} from '../../api/course';

const EMPTY_COURSE = { name: '', description: '' };
const EMPTY_SKILL = { name: '', description: '' };

// Skill has no createdAt field, but MongoDB ObjectIds are chronologically
// prefixed — sorting by id descending genuinely reflects creation order
// without inventing data the backend doesn't provide.
function newestFirst(skills) {
  return [...skills].sort((a, b) => (a.id < b.id ? 1 : a.id > b.id ? -1 : 0));
}

export default function Courses() {
  const confirm = useConfirm();
  const toast = useToast();

  const [tab, setTab] = useState('courses');
  const [rows, setRows] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [nameFilter, setNameFilter] = useState('');
  const debouncedFilter = useDebouncedValue(nameFilter, 350);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [skills, setSkills] = useState([]);

  const [courseModalOpen, setCourseModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_COURSE);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  const [skillsModalCourse, setSkillsModalCourse] = useState(null);
  const [selectedSkillIds, setSelectedSkillIds] = useState([]);
  const [savingSkills, setSavingSkills] = useState(false);

  const [skillModalOpen, setSkillModalOpen] = useState(false);
  const [skillForm, setSkillForm] = useState(EMPTY_SKILL);
  const [skillFormError, setSkillFormError] = useState('');
  const [savingSkill, setSavingSkill] = useState(false);

  const loadCourses = useCallback(() => {
    setLoading(true);
    setError('');
    searchCourses({ name: debouncedFilter || undefined, page, size: 10 })
      .then((res) => {
        const paged = res.data.data;
        setRows(paged.content);
        setTotalPages(paged.totalPages);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [debouncedFilter, page]);

  const loadSkills = useCallback(() => {
    listSkills()
      .then((res) => setSkills(newestFirst(res.data.data)))
      .catch((err) => setError(err.message));
  }, []);

  useEffect(() => {
    loadCourses();
  }, [loadCourses]);

  useEffect(() => {
    loadSkills();
  }, [loadSkills]);

  useEffect(() => {
    setPage(0);
  }, [debouncedFilter]);

  function openCreateCourse() {
    setEditingId(null);
    setForm(EMPTY_COURSE);
    setFormError('');
    setCourseModalOpen(true);
  }

  function openEditCourse(course) {
    setEditingId(course.id);
    setForm({ name: course.name, description: course.description || '' });
    setFormError('');
    setCourseModalOpen(true);
  }

  async function handleSaveCourse(e) {
    e.preventDefault();
    setFormError('');
    setSaving(true);
    try {
      if (editingId) {
        await updateCourse(editingId, form);
        toast.success('Course updated.');
      } else {
        await createCourse(form);
        toast.success('Course created.');
      }
      setCourseModalOpen(false);
      loadCourses();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleDeactivate(course) {
    const ok = await confirm(`Deactivate "${course.name}"? Trainers and students will no longer see it as active.`, {
      title: 'Deactivate course?',
      tone: 'danger',
    });
    if (!ok) return;
    try {
      await deactivateCourse(course.id);
      toast.success('Course deactivated.');
      loadCourses();
    } catch (err) {
      setError(err.message);
    }
  }

  function openSkillsModal(course) {
    setSkillsModalCourse(course);
    setSelectedSkillIds(course.skillIds || []);
  }

  async function handleSaveSkills() {
    setSavingSkills(true);
    try {
      await assignCourseSkills(skillsModalCourse.id, selectedSkillIds);
      toast.success('Skills updated.');
      setSkillsModalCourse(null);
      loadCourses();
    } catch (err) {
      setError(err.message);
    } finally {
      setSavingSkills(false);
    }
  }

  function toggleSkill(id) {
    setSelectedSkillIds((prev) => (prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]));
  }

  async function handleCreateSkill(e) {
    e.preventDefault();
    setSkillFormError('');
    setSavingSkill(true);
    try {
      const res = await createSkill(skillForm);
      // Optimistic: put the new skill at the top immediately rather than
      // waiting on a refetch, then reconcile with the server on next load.
      setSkills((prev) => [res.data.data, ...prev]);
      setSkillModalOpen(false);
      setSkillForm(EMPTY_SKILL);
      toast.success('Skill added.');
    } catch (err) {
      setSkillFormError(err.message);
    } finally {
      setSavingSkill(false);
    }
  }

  const skillNameById = Object.fromEntries(skills.map((s) => [s.id, s.name]));

  const columns = [
    { key: 'name', header: 'Name' },
    { key: 'description', header: 'Description', render: (r) => r.description || '—' },
    {
      key: 'skills',
      header: 'Skills',
      render: (r) => (r.skillIds?.length ? r.skillIds.map((id) => skillNameById[id] || id).join(', ') : '—'),
    },
    { key: 'active', header: 'Status', render: (r) => <StatusBadge status={r.active ? 'ACTIVE' : 'INACTIVE'} /> },
    {
      key: 'actions',
      header: '',
      render: (r) => (
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          <button className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} onClick={() => openEditCourse(r)}>
            Edit
          </button>
          <button className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} onClick={() => openSkillsModal(r)}>
            Skills
          </button>
          {r.active && (
            <button
              className="btn btn-ghost"
              style={{ padding: '5px 12px', fontSize: 12, color: 'var(--color-danger)' }}
              onClick={() => handleDeactivate(r)}
            >
              Deactivate
            </button>
          )}
        </div>
      ),
    },
  ];

  return (
    <AppShell roleLabel="Administrator" sidebar={<AdminSidebar />}>
      <PageHeader
        title="Courses & Skills"
        subtitle="What batches are built around, and the skill tags trainers score against."
        actions={
          tab === 'courses' ? (
            <button className="btn btn-primary" onClick={openCreateCourse}>
              + New course
            </button>
          ) : (
            <button className="btn btn-primary" onClick={() => setSkillModalOpen(true)}>
              + New skill
            </button>
          )
        }
      />

      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        {['courses', 'skills'].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={tab === t ? 'btn btn-primary' : 'btn btn-ghost'}
            style={{ padding: '8px 18px', fontSize: 13, textTransform: 'capitalize' }}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === 'courses' ? (
        <>
          <div style={{ marginBottom: 16, maxWidth: 320 }}>
            <input
              type="text"
              placeholder="Search by name…"
              value={nameFilter}
              onChange={(e) => setNameFilter(e.target.value)}
              aria-label="Search courses by name"
              style={{
                width: '100%',
                padding: '10px 14px',
                borderRadius: 'var(--radius-sm)',
                border: '1.5px solid var(--color-border)',
                fontSize: 14,
                background: 'var(--color-surface)',
              }}
            />
          </div>
          {error ? (
            <ErrorState message={error} onRetry={loadCourses} />
          ) : (
            <DataTable
              columns={columns}
              rows={rows}
              loading={loading}
              emptyLabel="No courses yet — create one to get started."
              page={page}
              totalPages={totalPages}
              onPageChange={setPage}
            />
          )}
        </>
      ) : (
        <div className="card" style={{ padding: 20 }}>
          {skills.length === 0 ? (
            <EmptyState title="No skills in the catalog yet" description="Add one to start scoring trainees against it." />
          ) : (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
              {skills.map((s) => (
                <span
                  key={s.id}
                  title={s.description}
                  style={{ padding: '8px 14px', borderRadius: 999, background: 'var(--color-surface-alt)', fontSize: 13, fontWeight: 600 }}
                >
                  {s.name}
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      <Modal open={courseModalOpen} title={editingId ? 'Edit course' : 'New course'} onClose={() => setCourseModalOpen(false)}>
        <form onSubmit={handleSaveCourse} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className="field">
            <label htmlFor="cname">Name</label>
            <input id="cname" required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="cdesc">Description</label>
            <input id="cdesc" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
          </div>
          {formError && <p className="error-text">{formError}</p>}
          <button className="btn btn-primary" type="submit" disabled={saving}>
            {saving ? 'Saving…' : editingId ? 'Save changes' : 'Create course'}
          </button>
        </form>
      </Modal>

      <Modal open={Boolean(skillsModalCourse)} title={`Skills for ${skillsModalCourse?.name || ''}`} onClose={() => setSkillsModalCourse(null)}>
        {skills.length === 0 ? (
          <EmptyState title="No skills yet" description="Add some from the Skills tab first." />
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
            {skills.map((s) => (
              <label key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 14 }}>
                <input type="checkbox" checked={selectedSkillIds.includes(s.id)} onChange={() => toggleSkill(s.id)} />
                {s.name}
              </label>
            ))}
          </div>
        )}
        <button className="btn btn-primary" onClick={handleSaveSkills} disabled={savingSkills || skills.length === 0}>
          {savingSkills ? 'Saving…' : 'Save skills'}
        </button>
      </Modal>

      <Modal open={skillModalOpen} title="New skill" onClose={() => setSkillModalOpen(false)}>
        <form onSubmit={handleCreateSkill} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className="field">
            <label htmlFor="sname">Name</label>
            <input id="sname" required value={skillForm.name} onChange={(e) => setSkillForm((f) => ({ ...f, name: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="sdesc">Description</label>
            <input id="sdesc" value={skillForm.description} onChange={(e) => setSkillForm((f) => ({ ...f, description: e.target.value }))} />
          </div>
          {skillFormError && <p className="error-text">{skillFormError}</p>}
          <button className="btn btn-primary" type="submit" disabled={savingSkill}>
            {savingSkill ? 'Saving…' : 'Create skill'}
          </button>
        </form>
      </Modal>
    </AppShell>
  );
}
