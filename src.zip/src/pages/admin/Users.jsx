import { useEffect, useState, useCallback } from 'react';
import AppShell from '../../components/AppShell';
import AdminSidebar from '../../components/AdminSidebar';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import Modal from '../../components/Modal';
import StatusBadge from '../../components/StatusBadge';
import { ErrorState } from '../../components/States';
import { useConfirm } from '../../components/ConfirmDialog';
import { useToast } from '../../context/ToastContext';
import useDebouncedValue from '../../hooks/useDebouncedValue';
import {
  searchUsers,
  createUser,
  updateUser,
  activateUser,
  deactivateUser,
  resetUserPassword,
} from '../../api/user';
import { searchDepartments } from '../../api/department';

const ROLES = ['ADMIN', 'HR', 'TRAINER', 'STUDENT'];
const TRAINER_TYPES = ['TECHNICAL', 'SOFT_SKILL'];

const EMPTY_FORM = { firstName: '', lastName: '', email: '', role: 'STUDENT', trainerType: '', departmentId: '' };

export default function Users() {
  const confirm = useConfirm();
  const toast = useToast();

  const [rows, setRows] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [query, setQuery] = useState('');
  const debouncedQuery = useDebouncedValue(query, 350);
  const [roleFilter, setRoleFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [departments, setDepartments] = useState([]);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);
  const [busyId, setBusyId] = useState(null);

  const load = useCallback(() => {
    setLoading(true);
    setError('');
    searchUsers({ query: debouncedQuery || undefined, role: roleFilter || undefined, page, size: 10 })
      .then((res) => {
        const paged = res.data.data;
        setRows(paged.content);
        setTotalPages(paged.totalPages);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [debouncedQuery, roleFilter, page]);

  useEffect(() => {
    load();
  }, [load]);

  // Reset to page 1 whenever a filter actually changes, so we never land on
  // a page index that's out of range for the new result set.
  useEffect(() => {
    setPage(0);
  }, [debouncedQuery, roleFilter]);

  useEffect(() => {
    searchDepartments({ page: 0, size: 100 })
      .then((res) => setDepartments(res.data.data.content))
      .catch(() => {});
  }, []);

  function openCreate() {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setFormError('');
    setModalOpen(true);
  }

  function openEdit(u) {
    setEditingId(u.id);
    setForm({
      firstName: u.firstName,
      lastName: u.lastName,
      email: u.email,
      role: u.role,
      trainerType: u.trainerType || '',
      departmentId: u.departmentId || '',
    });
    setFormError('');
    setModalOpen(true);
  }

  async function handleSave(e) {
    e.preventDefault();
    setFormError('');
    if (form.role === 'TRAINER' && !form.trainerType) {
      setFormError('Trainer type is required for trainers.');
      return;
    }
    setSaving(true);
    try {
      if (editingId) {
        await updateUser(editingId, {
          firstName: form.firstName,
          lastName: form.lastName,
          trainerType: form.trainerType || null,
          departmentId: form.departmentId || null,
        });
        toast.success('User updated.');
      } else {
        await createUser({
          firstName: form.firstName,
          lastName: form.lastName,
          email: form.email,
          role: form.role,
          trainerType: form.role === 'TRAINER' ? form.trainerType : null,
          departmentId: form.departmentId || null,
        });
        toast.success('User created — credentials emailed.');
      }
      setModalOpen(false);
      load();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleToggleStatus(u) {
    const activating = u.status !== 'ACTIVE';
    const ok = await confirm(
      activating ? `Reactivate ${u.firstName} ${u.lastName}? They'll be able to log in again.` : `Deactivate ${u.firstName} ${u.lastName}? They won't be able to log in.`,
      { title: activating ? 'Activate user?' : 'Deactivate user?', tone: activating ? 'default' : 'danger' }
    );
    if (!ok) return;
    setBusyId(u.id);
    try {
      if (activating) await activateUser(u.id);
      else await deactivateUser(u.id);
      toast.success(activating ? 'User activated.' : 'User deactivated.');
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  async function handleResetPassword(u) {
    const ok = await confirm(`Send a new temporary password to ${u.email}?`, { title: 'Reset password?' });
    if (!ok) return;
    setBusyId(u.id);
    try {
      await resetUserPassword(u.id);
      toast.success(`Temporary password emailed to ${u.email}.`);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  const columns = [
    { key: 'name', header: 'Name', render: (r) => `${r.firstName} ${r.lastName}` },
    { key: 'email', header: 'Email' },
    { key: 'role', header: 'Role' },
    { key: 'trainerType', header: 'Trainer type', render: (r) => r.trainerType || '—' },
    { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    {
      key: 'actions',
      header: '',
      render: (r) => (
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          <button className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} onClick={() => openEdit(r)}>
            Edit
          </button>
          <button
            className="btn btn-ghost"
            style={{ padding: '5px 12px', fontSize: 12 }}
            disabled={busyId === r.id}
            onClick={() => handleToggleStatus(r)}
          >
            {r.status === 'ACTIVE' ? 'Deactivate' : 'Activate'}
          </button>
          <button
            className="btn btn-ghost"
            style={{ padding: '5px 12px', fontSize: 12 }}
            disabled={busyId === r.id}
            onClick={() => handleResetPassword(r)}
          >
            Reset password
          </button>
        </div>
      ),
    },
  ];

  return (
    <AppShell roleLabel="Administrator" sidebar={<AdminSidebar />}>
      <PageHeader
        title="Users"
        subtitle="Everyone with access to IBNextStep, across all roles."
        actions={
          <button className="btn btn-primary" onClick={openCreate}>
            + New user
          </button>
        }
      />

      <div style={{ display: 'flex', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
        <input
          type="text"
          placeholder="Search name or email…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          aria-label="Search users by name or email"
          style={{
            flex: 1,
            minWidth: 220,
            padding: '10px 14px',
            borderRadius: 'var(--radius-sm)',
            border: '1.5px solid var(--color-border)',
            fontSize: 14,
            background: 'var(--color-surface)',
          }}
        />
        <select
          value={roleFilter}
          onChange={(e) => setRoleFilter(e.target.value)}
          aria-label="Filter by role"
          style={{
            padding: '10px 14px',
            borderRadius: 'var(--radius-sm)',
            border: '1.5px solid var(--color-border)',
            fontSize: 14,
            background: 'var(--color-surface)',
          }}
        >
          <option value="">All roles</option>
          {ROLES.map((r) => (
            <option key={r} value={r}>
              {r}
            </option>
          ))}
        </select>
      </div>

      {error ? (
        <ErrorState message={error} onRetry={load} />
      ) : (
        <DataTable
          columns={columns}
          rows={rows}
          loading={loading}
          emptyLabel="No users found."
          page={page}
          totalPages={totalPages}
          onPageChange={setPage}
        />
      )}

      <Modal open={modalOpen} title={editingId ? 'Edit user' : 'New user'} onClose={() => setModalOpen(false)}>
        <form onSubmit={handleSave} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ display: 'flex', gap: 12 }}>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="firstName">First name</label>
              <input
                id="firstName"
                required
                value={form.firstName}
                onChange={(e) => setForm((f) => ({ ...f, firstName: e.target.value }))}
              />
            </div>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="lastName">Last name</label>
              <input
                id="lastName"
                required
                value={form.lastName}
                onChange={(e) => setForm((f) => ({ ...f, lastName: e.target.value }))}
              />
            </div>
          </div>

          <div className="field">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              required
              disabled={Boolean(editingId)}
              value={form.email}
              onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
              placeholder="name@infobeans.com"
            />
          </div>

          {!editingId && (
            <div className="field">
              <label htmlFor="role">Role</label>
              <select
                id="role"
                value={form.role}
                onChange={(e) => setForm((f) => ({ ...f, role: e.target.value, trainerType: '' }))}
              >
                {ROLES.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>
          )}

          {form.role === 'TRAINER' && (
            <div className="field">
              <label htmlFor="trainerType">Trainer type</label>
              <select
                id="trainerType"
                required
                value={form.trainerType}
                onChange={(e) => setForm((f) => ({ ...f, trainerType: e.target.value }))}
              >
                <option value="">Select…</option>
                {TRAINER_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t.replace('_', ' ')}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="field">
            <label htmlFor="departmentId">Department</label>
            <select
              id="departmentId"
              value={form.departmentId}
              onChange={(e) => setForm((f) => ({ ...f, departmentId: e.target.value }))}
            >
              <option value="">None</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>

          {formError && <p className="error-text">{formError}</p>}
          <button className="btn btn-primary" type="submit" disabled={saving}>
            {saving ? 'Saving…' : editingId ? 'Save changes' : 'Create user'}
          </button>
        </form>
      </Modal>
    </AppShell>
  );
}
