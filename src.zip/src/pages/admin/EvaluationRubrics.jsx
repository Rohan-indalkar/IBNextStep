import { useEffect, useState } from 'react';
import AppShell from '../../components/AppShell';
import AdminSidebar from '../../components/AdminSidebar';
import PageHeader from '../../components/PageHeader';
import { LoadingState, ErrorState } from '../../components/States';
import { useToast } from '../../context/ToastContext';
import { getAllRubricConfigs, updateRubricConfig } from '../../api/evaluationRubric';

function RubricCard({ label, config, onSaved }) {
  const toast = useToast();
  const [skills, setSkills] = useState(config.skills);
  const [newSkill, setNewSkill] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  function addSkill() {
    const trimmed = newSkill.trim();
    if (!trimmed || skills.includes(trimmed)) return;
    setSkills((s) => [...s, trimmed]);
    setNewSkill('');
  }

  function removeSkill(skill) {
    setSkills((s) => s.filter((x) => x !== skill));
  }

  async function handleSave() {
    setError('');
    if (skills.length < 3) {
      setError('A rubric needs at least 3 distinct skills.');
      return;
    }
    setSaving(true);
    try {
      await updateRubricConfig(config.trainerType, skills);
      toast.success(`${label} saved.`);
      onSaved();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="card" style={{ padding: 24 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
        <h2 style={{ fontSize: 17 }}>{label}</h2>
        <span style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>
          {config.customized ? `Customised${config.updatedByAdminName ? ` by ${config.updatedByAdminName}` : ''}` : 'Using default'}
        </span>
      </div>
      <p style={{ fontSize: 13, color: 'var(--color-text-muted)', marginBottom: 16 }}>
        Skills scored (0–10) each time a trainer submits an evaluation. Already-submitted evaluations keep the
        skill names they were scored against.
      </p>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
        {skills.map((s) => (
          <span
            key={s}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '6px 8px 6px 14px',
              borderRadius: 999,
              background: 'var(--color-surface-alt)',
              fontSize: 13,
              fontWeight: 600,
            }}
          >
            {s}
            <button
              onClick={() => removeSkill(s)}
              aria-label={`Remove ${s}`}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--color-text-muted)', fontSize: 15, lineHeight: 1 }}
            >
              ×
            </button>
          </span>
        ))}
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        <input
          value={newSkill}
          onChange={(e) => setNewSkill(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill())}
          placeholder="Add a skill…"
          style={{
            flex: 1,
            padding: '10px 14px',
            borderRadius: 'var(--radius-sm)',
            border: '1.5px solid var(--color-border)',
            fontSize: 14,
          }}
        />
        <button className="btn btn-ghost" style={{ padding: '8px 16px', fontSize: 13 }} onClick={addSkill}>
          Add
        </button>
      </div>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}
      <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
        {saving ? 'Saving…' : 'Save rubric'}
      </button>
    </div>
  );
}

export default function EvaluationRubrics() {
  const [configs, setConfigs] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  function load() {
    setLoading(true);
    getAllRubricConfigs()
      .then((res) => setConfigs(res.data.data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  return (
    <AppShell roleLabel="Administrator" sidebar={<AdminSidebar />}>
      <PageHeader title="Evaluation rubrics" subtitle="The skill sets trainers score students against, per trainer type." />
      {loading ? (
        <LoadingState rows={2} />
      ) : error ? (
        <ErrorState message={error} onRetry={load} />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: 20 }}>
          {configs.map((c) => (
            <RubricCard key={c.trainerType} label={c.trainerType === 'SOFT_SKILL' ? 'Soft Skill rubric' : 'Technical rubric'} config={c} onSaved={load} />
          ))}
        </div>
      )}
    </AppShell>
  );
}
