import { useEffect, useState, useCallback } from 'react';
import AppShell from '../../components/AppShell';
import AdminSidebar from '../../components/AdminSidebar';
import PageHeader from '../../components/PageHeader';
import StatCard from '../../components/StatCard';
import { LoadingState, EmptyState, ErrorState } from '../../components/States';
import { useToast } from '../../context/ToastContext';
import useDebouncedValue from '../../hooks/useDebouncedValue';
import { getReportsSummary, searchReports, exportUsersExcel, exportUsersPdf } from '../../api/report';

export default function Reports() {
  const toast = useToast();
  const [summary, setSummary] = useState(null);
  const [reports, setReports] = useState([]);
  const [query, setQuery] = useState('');
  const debouncedQuery = useDebouncedValue(query, 300);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState('');

  const load = useCallback(() => {
    setLoading(true);
    setError('');
    Promise.all([getReportsSummary(), searchReports(debouncedQuery || undefined)])
      .then(([summaryRes, reportsRes]) => {
        setSummary(summaryRes.data.data);
        setReports(reportsRes.data.data);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [debouncedQuery]);

  useEffect(() => {
    load();
  }, [load]);

  async function handleExport(kind) {
    setExporting(kind);
    setError('');
    try {
      if (kind === 'excel') await exportUsersExcel();
      else await exportUsersPdf();
      toast.success(`${kind === 'excel' ? 'Excel' : 'PDF'} export downloaded.`);
    } catch (err) {
      setError(err.message);
    } finally {
      setExporting('');
    }
  }

  return (
    <AppShell roleLabel="Administrator" sidebar={<AdminSidebar />}>
      <PageHeader title="Reports" subtitle="Organisation snapshot and exportable data, straight from the platform." />

      {error && <ErrorState message={error} onRetry={load} />}

      {summary && (
        <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 32 }}>
          <StatCard label="Students" value={summary.totalStudents} />
          <StatCard label="Trainers" value={summary.totalTrainers} />
          <StatCard label="HR" value={summary.totalHr} />
          <StatCard label="Active batches" value={summary.activeBatches} accent />
          <StatCard label="Courses" value={summary.totalCourses} />
          <StatCard label="Active placement drives" value={summary.activePlacementDrives} accent />
        </div>
      )}

      <div className="card" style={{ padding: 24, marginBottom: 24 }}>
        <h2 style={{ fontSize: 16, marginBottom: 14 }}>Users report</h2>
        <p style={{ fontSize: 13, color: 'var(--color-text-muted)', marginBottom: 16 }}>
          Full export of every user in the system.
        </p>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          <button className="btn btn-primary" onClick={() => handleExport('excel')} disabled={exporting === 'excel'}>
            {exporting === 'excel' ? 'Exporting…' : 'Export Excel'}
          </button>
          <button className="btn btn-ghost" onClick={() => handleExport('pdf')} disabled={exporting === 'pdf'}>
            {exporting === 'pdf' ? 'Exporting…' : 'Export PDF'}
          </button>
        </div>
      </div>

      <div className="card" style={{ padding: 24 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, flexWrap: 'wrap', gap: 10 }}>
          <h2 style={{ fontSize: 16 }}>Available reports</h2>
          <input
            type="text"
            placeholder="Search reports…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            aria-label="Search available reports"
            style={{ padding: '8px 14px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', fontSize: 13, minWidth: 220 }}
          />
        </div>
        {loading ? (
          <LoadingState rows={3} />
        ) : reports.length === 0 ? (
          <EmptyState title="No reports match your search" />
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {reports.map((r) => (
              <div key={r.id} style={{ padding: '12px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 6, marginBottom: 4 }}>
                  <span style={{ fontWeight: 600, fontSize: 14 }}>{r.name}</span>
                  <span style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>{r.category}</span>
                </div>
                <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>{r.description}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}
