import { useState } from 'react';
import AppShell from '../../components/AppShell';
import AdminSidebar from '../../components/AdminSidebar';
import PageHeader from '../../components/PageHeader';
import { useToast } from '../../context/ToastContext';
import { composeNotification } from '../../api/notification';

const AUDIENCES = [
  { value: '', label: 'Everyone' },
  { value: 'ADMIN', label: 'Admins' },
  { value: 'HR', label: 'HR / Recruiters' },
  { value: 'TRAINER', label: 'Trainers' },
  { value: 'STUDENT', label: 'Students' },
];

export default function Notifications() {
  const toast = useToast();
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [audience, setAudience] = useState('');
  const [error, setError] = useState('');
  const [sending, setSending] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setSending(true);
    try {
      await composeNotification({ title, message, audience: audience || null });
      setTitle('');
      setMessage('');
      setAudience('');
      toast.success('Notification sent.');
    } catch (err) {
      setError(err.message);
    } finally {
      setSending(false);
    }
  }

  return (
    <AppShell roleLabel="Administrator" sidebar={<AdminSidebar />}>
      <PageHeader title="Broadcast notification" subtitle="Send a message to everyone, or a specific role." />

      <div className="card" style={{ padding: 28, maxWidth: 560 }}>
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className="field">
            <label htmlFor="ntitle">Title</label>
            <input id="ntitle" required value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Platform maintenance tonight" />
          </div>
          <div className="field">
            <label htmlFor="naudience">Audience</label>
            <select
              id="naudience"
              value={audience}
              onChange={(e) => setAudience(e.target.value)}
              style={{ padding: '12px 14px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)' }}
            >
              {AUDIENCES.map((a) => (
                <option key={a.value} value={a.value}>
                  {a.label}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label htmlFor="nmessage">Message</label>
            <textarea
              id="nmessage"
              required
              rows={5}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="What do they need to know?"
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: 15,
                padding: '12px 14px',
                borderRadius: 'var(--radius-sm)',
                border: '1.5px solid var(--color-border)',
                resize: 'vertical',
              }}
            />
          </div>

          {error && <p className="error-text">{error}</p>}

          <button className="btn btn-primary" type="submit" disabled={sending}>
            {sending ? 'Sending…' : 'Send notification'}
          </button>
        </form>
      </div>
    </AppShell>
  );
}
