import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import AppShell from '../../components/AppShell';
import AdminSidebar from '../../components/AdminSidebar';
import PageHeader from '../../components/PageHeader';
import StatCard from '../../components/StatCard';
import ChartCard from '../../components/ChartCard';
import { LoadingState, ErrorState } from '../../components/States';
import { getAdminDashboardStats } from '../../api/adminDashboard';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  function load() {
    setLoading(true);
    setError('');
    getAdminDashboardStats()
      .then((res) => setStats(res.data.data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError('');
    getAdminDashboardStats()
      .then((res) => {
        if (!cancelled) setStats(res.data.data);
      })
      .catch((err) => {
        if (!cancelled) setError(err.message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <AppShell roleLabel="Administrator" sidebar={<AdminSidebar />}>
      <PageHeader title="Overview" subtitle="A snapshot of the organisation, pulled live from the platform." />

      {loading ? (
        <LoadingState rows={2} />
      ) : error ? (
        <ErrorState message={error} onRetry={load} />
      ) : (
        <>
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 28 }}>
            <StatCard label="Students" value={stats?.totalStudents ?? 0} />
            <StatCard label="Trainers" value={stats?.totalTrainers ?? 0} />
            <StatCard label="HR / Recruiters" value={stats?.totalHr ?? 0} />
            <StatCard label="Active batches" value={stats?.activeBatches ?? 0} accent />
            <StatCard label="Courses" value={stats?.totalCourses ?? 0} />
            <StatCard label="Active placement drives" value={stats?.activePlacementDrives ?? 0} accent />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 20, marginBottom: 28 }}>
            <ChartCard
              title="People by role"
              data={[
                { label: 'Students', value: stats?.totalStudents ?? 0 },
                { label: 'Trainers', value: stats?.totalTrainers ?? 0 },
                { label: 'HR / Recruiters', value: stats?.totalHr ?? 0 },
              ]}
            />
            <ChartCard
              title="Program footprint"
              colorVar="--color-primary"
              data={[
                { label: 'Active batches', value: stats?.activeBatches ?? 0 },
                { label: 'Courses', value: stats?.totalCourses ?? 0 },
                { label: 'Active placement drives', value: stats?.activePlacementDrives ?? 0 },
              ]}
            />
          </div>

          <div className="card" style={{ padding: 28 }}>
            <h2 style={{ fontSize: 17, marginBottom: 14 }}>Set up your organisation</h2>
            <p style={{ color: 'var(--color-text-muted)', fontSize: 14, marginBottom: 18 }}>
              Departments and users are the foundation everything else builds on — batches, courses and
              placements all reference them.
            </p>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
              <Link to="/app/admin/departments" className="btn btn-primary">
                Manage departments
              </Link>
              <Link to="/app/admin/users" className="btn btn-ghost">
                Manage users
              </Link>
            </div>
          </div>
        </>
      )}
    </AppShell>
  );
}
