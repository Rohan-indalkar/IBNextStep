import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import AppShell from '../../components/AppShell';
import AdminSidebar from '../../components/AdminSidebar';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import Modal from '../../components/Modal';
import StatusBadge from '../../components/StatusBadge';
import { ErrorState } from '../../components/States';
import { useConfirm } from '../../components/ConfirmDialog';
import { useToast } from '../../context/ToastContext';
import useDebouncedValue from '../../hooks/useDebouncedValue';
import { searchBatches, createBatch, deactivateBatch } from '../../api/batch';
import { searchCourses } from '../../api/course';

const EMPTY_FORM = { name: '', courseId: '', startDate: '', endDate: '' };

export default function Batches() {
  const navigate = useNavigate();
  const confirm = useConfirm();
  const toast = useToast();

  const [rows, setRows] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [nameFilter, setNameFilter] = useState('');
  const debouncedFilter = useDebouncedValue(nameFilter, 350);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [courses, setCourses] = useState([]);

  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    setError('');
    searchBatches({ name: debouncedFilter || undefined, page, size: 10 })
      .then((res) => {
        const paged = res.data.data;
        setRows(paged.content);
        setTotalPages(paged.totalPages);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [debouncedFilter, page]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    setPage(0);
  }, [debouncedFilter]);

  useEffect(() => {
    searchCourses({ page: 0, size: 100 })
      .then((res) => setCourses(res.data.data.content))
      .catch(() => {});
  }, []);

  const courseNameById = Object.fromEntries(courses.map((c) => [c.id, c.name]));

  function openCreate() {
    setForm(EMPTY_FORM);
    setFormError('');
    setModalOpen(true);
  }

  async function handleSave(e) {
    e.preventDefault();
    setFormError('');
    setSaving(true);
    try {
      const res = await createBatch({
        name: form.name,
        courseId: form.courseId,
        startDate: form.startDate || null,
        endDate: form.endDate || null,
      });
      setModalOpen(false);
      toast.success('Batch created.');
      load();
      navigate(`/app/admin/batches/${res.data.data.id}`);
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleDeactivate(batch) {
    const ok = await confirm(`Deactivate "${batch.name}"? Trainers and students lose access to it.`, {
      title: 'Deactivate batch?',
      tone: 'danger',
    });
    if (!ok) return;
    try {
      await deactivateBatch(batch.id);
      toast.success('Batch deactivated.');
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  const columns = [
    { key: 'name', header: 'Name' },
    { key: 'course', header: 'Course', render: (r) => courseNameById[r.courseId] || '—' },
    { key: 'students', header: 'Students', render: (r) => r.studentIds?.length ?? 0 },
    { key: 'dates', header: 'Dates', render: (r) => (r.startDate ? `${r.startDate} → ${r.endDate || '—'}` : '—') },
    { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    {
      key: 'actions',
      header: '',
      render: (r) => (
        <div style={{ display: 'flex', gap: 6 }}>
          <button className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} onClick={() => navigate(`/app/admin/batches/${r.id}`)}>
            Manage
          </button>
          {r.status === 'ACTIVE' && (
            <button
              className="btn btn-ghost"
              style={{ padding: '5px 12px', fontSize: 12, color: 'var(--color-danger)' }}
              onClick={() => handleDeactivate(r)}
            >
              Deactivate
            </button>
          )}
        </div>
      ),
    },
  ];

  return (
    <AppShell roleLabel="Administrator" sidebar={<AdminSidebar />}>
      <PageHeader
        title="Batches"
        subtitle="Trainer assignments, timetables and student rosters for each cohort."
        actions={
          <button className="btn btn-primary" onClick={openCreate}>
            + New batch
          </button>
        }
      />

      <div style={{ marginBottom: 16, maxWidth: 320 }}>
        <input
          type="text"
          placeholder="Search by name…"
          value={nameFilter}
          onChange={(e) => setNameFilter(e.target.value)}
          aria-label="Search batches by name"
          style={{
            width: '100%',
            padding: '10px 14px',
            borderRadius: 'var(--radius-sm)',
            border: '1.5px solid var(--color-border)',
            fontSize: 14,
            background: 'var(--color-surface)',
          }}
        />
      </div>

      {error ? (
        <ErrorState message={error} onRetry={load} />
      ) : (
        <DataTable
          columns={columns}
          rows={rows}
          loading={loading}
          emptyLabel="No batches yet — create one to get started."
          page={page}
          totalPages={totalPages}
          onPageChange={setPage}
        />
      )}

      <Modal open={modalOpen} title="New batch" onClose={() => setModalOpen(false)}>
        <form onSubmit={handleSave} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className="field">
            <label htmlFor="bname">Name</label>
            <input id="bname" required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="bcourse">Course</label>
            <select id="bcourse" required value={form.courseId} onChange={(e) => setForm((f) => ({ ...f, courseId: e.target.value }))}>
              <option value="">Select a course…</option>
              {courses.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div style={{ display: 'flex', gap: 12 }}>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="bstart">Start date</label>
              <input id="bstart" type="date" value={form.startDate} onChange={(e) => setForm((f) => ({ ...f, startDate: e.target.value }))} />
            </div>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="bend">End date</label>
              <input id="bend" type="date" value={form.endDate} onChange={(e) => setForm((f) => ({ ...f, endDate: e.target.value }))} />
            </div>
          </div>
          {formError && <p className="error-text">{formError}</p>}
          <button className="btn btn-primary" type="submit" disabled={saving}>
            {saving ? 'Creating…' : 'Create batch'}
          </button>
        </form>
      </Modal>
    </AppShell>
  );
}
