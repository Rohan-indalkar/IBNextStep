import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import AuthLayout from '../../components/AuthLayout';
import { verifyLoginOtp, login } from '../../api/auth';
import { useAuth } from '../../context/AuthContext';

const ROLE_HOME = {
  ADMIN: '/app/admin',
  HR: '/app/hr',
  TRAINER: '/app/trainer',
  STUDENT: '/app/student',
};

export default function VerifyOtp() {
  const navigate = useNavigate();
  const location = useLocation();
  const { applySession } = useAuth();
  const email = location.state?.email || '';
  const password = location.state?.password || '';
  const [otp, setOtp] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    if (!email) {
      setError('Session expired — please log in again.');
      return;
    }
    if (!/^\d{6}$/.test(otp)) {
      setError('Enter the full 6-digit code.');
      return;
    }
    setLoading(true);
    try {
      const res = await verifyLoginOtp({ email, otp });
      const auth = res.data.data; // ApiResponse<AuthResponse>
      applySession(auth);
      if (auth.mustChangePassword) {
        navigate('/auth/change-password', { replace: true });
        return;
      }
      navigate(ROLE_HOME[auth.role] || '/app', { replace: true });
    } catch (err) {
      setError(err.message || 'That code is incorrect. Please try again.');
      setOtp('');
    } finally {
      setLoading(false);
    }
  }

  function handleOtpChange(e) {
    const digitsOnly = e.target.value.replace(/\D/g, '').slice(0, 6);
    setOtp(digitsOnly);
    if (error) setError('');
  }

  async function handleResend() {
    setError('');
    if (!password) {
      setError('Please go back and log in again to resend a code.');
      return;
    }
    setResending(true);
    try {
      // AuthController has no dedicated resend endpoint — re-calling
      // /login (with the credentials already validated once) is what
      // re-triggers the OTP email.
      await login({ email, password });
    } catch (err) {
      setError('Could not resend — please go back and log in again.');
    } finally {
      setResending(false);
    }
  }

  if (!email) {
    return (
      <AuthLayout title="Session expired" subtitle="We couldn't find an email to verify.">
        <button className="btn btn-primary" onClick={() => navigate('/auth/login')}>
          Back to login
        </button>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout title="Check your email" subtitle={`Enter the OTP sent to ${email}.`}>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div className="field">
          <label htmlFor="otp">One-time code</label>
          <input
            id="otp"
            type="text"
            inputMode="numeric"
            pattern="\d{6}"
            maxLength={6}
            autoComplete="one-time-code"
            required
            value={otp}
            onChange={handleOtpChange}
            placeholder="6-digit code"
            aria-invalid={Boolean(error)}
            style={{ letterSpacing: '0.3em', textAlign: 'center', fontSize: 20 }}
          />
        </div>

        {error && (
          <div role="alert" className="error-text" style={{ background: 'var(--color-danger-bg)', padding: '10px 12px', borderRadius: 'var(--radius-sm)' }}>
            {error}
          </div>
        )}

        <button className="btn btn-primary" type="submit" disabled={loading || otp.length !== 6}>
          {loading ? 'Verifying…' : 'Verify & continue'}
        </button>

        <button
          type="button"
          onClick={handleResend}
          disabled={resending}
          style={{ background: 'none', border: 'none', color: 'var(--color-primary)', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}
        >
          {resending ? 'Resending…' : "Didn't get a code? Resend"}
        </button>
      </form>
    </AuthLayout>
  );
}
