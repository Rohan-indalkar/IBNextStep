import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import AuthLayout from '../../components/AuthLayout';
import PasswordInput from '../../components/PasswordInput';
import { resetPassword } from '../../api/auth';

export default function ResetPassword() {
  const navigate = useNavigate();
  const location = useLocation();
  const email = location.state?.email || '';

  const [otp, setOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  function handleOtpChange(e) {
    setOtp(e.target.value.replace(/\D/g, '').slice(0, 6));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    if (!/^\d{6}$/.test(otp)) {
      setError('Enter the full 6-digit code.');
      return;
    }
    if (newPassword !== confirm) {
      setError('Passwords do not match.');
      return;
    }
    if (newPassword.length < 8) {
      setError('Password must be at least 8 characters.');
      return;
    }
    setLoading(true);
    try {
      await resetPassword({ email, otp, newPassword });
      navigate('/auth/login', { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  if (!email) {
    return (
      <AuthLayout title="Session expired" subtitle="We couldn't find an email to reset.">
        <button className="btn btn-primary" onClick={() => navigate('/auth/forgot-password')}>
          Start over
        </button>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout title="Enter your new password" subtitle={`Enter the code sent to ${email} and choose a new password.`}>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div className="field">
          <label htmlFor="otp">One-time code</label>
          <input
            id="otp"
            type="text"
            inputMode="numeric"
            pattern="\d{6}"
            maxLength={6}
            required
            value={otp}
            onChange={handleOtpChange}
            placeholder="6-digit code"
            style={{ letterSpacing: '0.3em', textAlign: 'center', fontSize: 18 }}
          />
        </div>
        <div className="field">
          <label htmlFor="newPassword">New password</label>
          <PasswordInput
            id="newPassword"
            autoComplete="new-password"
            required
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            placeholder="At least 8 characters"
          />
        </div>
        <div className="field">
          <label htmlFor="confirm">Confirm password</label>
          <PasswordInput
            id="confirm"
            autoComplete="new-password"
            required
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            placeholder="Re-enter password"
          />
        </div>

        {error && <div role="alert" className="error-text" style={{ background: 'var(--color-danger-bg)', padding: '10px 12px', borderRadius: 'var(--radius-sm)' }}>{error}</div>}

        <button className="btn btn-primary" type="submit" disabled={loading || otp.length !== 6}>
          {loading ? 'Saving…' : 'Set new password'}
        </button>
      </form>
    </AuthLayout>
  );
}
