import { useEffect, useState, useCallback } from 'react';
import AppShell from '../../components/AppShell';
import HrSidebar from '../../components/HrSidebar';
import DataTable from '../../components/DataTable';
import Modal from '../../components/Modal';
import { searchPlacements } from '../../api/placement';
import {
  searchApplications,
  getApplication,
  shortlistApplication,
  rejectApplication,
  selectApplication,
  notSelectApplication,
  scheduleRound,
  rescheduleRound,
  cancelRound,
  updateRoundResult,
} from '../../api/application';

const STATUSES = ['', 'APPLIED', 'SHORTLISTED', 'REJECTED', 'INTERVIEW_SCHEDULED', 'SELECTED', 'NOT_SELECTED'];
const RESULTS = ['PENDING', 'QUALIFIED', 'REJECTED'];

function StatusBadge({ status }) {
  const colors = { APPLIED: '#888', SHORTLISTED: 'var(--color-warning)', REJECTED: 'var(--color-danger)', INTERVIEW_SCHEDULED: 'var(--color-info)', SELECTED: 'var(--color-success)', NOT_SELECTED: 'var(--color-danger)' };
  return <span style={{ fontSize: 12, fontWeight: 700, padding: '3px 10px', borderRadius: 999, color: '#fff', background: colors[status] || '#888' }}>{status.replace('_', ' ')}</span>;
}

export default function Applications() {
  const [placements, setPlacements] = useState([]);
  const [placementFilter, setPlacementFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [rows, setRows] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState(null);

  const [detailModal, setDetailModal] = useState(null);
  const [scheduleForm, setScheduleForm] = useState(null);
  const [scheduleSaving, setScheduleSaving] = useState(false);
  const [resultRound, setResultRound] = useState(null);
  const [resultForm, setResultForm] = useState({ result: 'QUALIFIED', resultRemarks: '' });

  const load = useCallback(() => {
    setLoading(true);
    setError('');
    searchApplications({ placementId: placementFilter || undefined, status: statusFilter || undefined, page, size: 10 })
      .then((res) => {
        const paged = res.data.data;
        setRows(paged.content);
        setTotalPages(paged.totalPages);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [placementFilter, statusFilter, page]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    searchPlacements({ page: 0, size: 100 })
      .then((res) => setPlacements(res.data.data.content))
      .catch(() => {});
  }, []);

  async function reloadDetail(id) {
    const res = await getApplication(id);
    setDetailModal(res.data.data);
  }

  async function handlePipelineAction(app, action) {
    setBusyId(app.id);
    setError('');
    try {
      if (action === 'shortlist') await shortlistApplication(app.id);
      else if (action === 'select') await selectApplication(app.id);
      else if (action === 'reject') {
        const reason = window.prompt('Rejection reason:');
        if (!reason) return;
        await rejectApplication(app.id, reason);
      } else if (action === 'not-select') {
        const reason = window.prompt('Reason for not selecting:');
        if (!reason) return;
        await notSelectApplication(app.id, reason);
      }
      load();
      if (detailModal?.id === app.id) reloadDetail(app.id);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  function openSchedule(app) {
    setScheduleForm({ roundType: '', scheduledAt: '', durationMinutes: 30, venue: '', meetingLink: '', remarks: '' });
  }

  async function handleScheduleSubmit(e) {
    e.preventDefault();
    setScheduleSaving(true);
    setError('');
    try {
      await scheduleRound(detailModal.id, {
        roundType: scheduleForm.roundType,
        scheduledAt: new Date(scheduleForm.scheduledAt).toISOString(),
        durationMinutes: scheduleForm.durationMinutes ? Number(scheduleForm.durationMinutes) : null,
        venue: scheduleForm.venue || null,
        meetingLink: scheduleForm.meetingLink || null,
        remarks: scheduleForm.remarks || null,
      });
      setScheduleForm(null);
      reloadDetail(detailModal.id);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setScheduleSaving(false);
    }
  }

  async function handleCancelRound(roundNumber) {
    const reason = window.prompt('Cancellation reason:');
    if (!reason) return;
    try {
      await cancelRound(detailModal.id, roundNumber, reason);
      reloadDetail(detailModal.id);
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  function openResult(round) {
    setResultRound(round);
    setResultForm({ result: 'QUALIFIED', resultRemarks: '' });
  }

  async function handleResultSubmit(e) {
    e.preventDefault();
    setError('');
    try {
      await updateRoundResult(detailModal.id, resultRound.roundNumber, resultForm);
      setResultRound(null);
      reloadDetail(detailModal.id);
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  const selectStyle = { padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', fontSize: 14 };

  const columns = [
    { key: 'student', header: 'Student', render: (r) => r.studentName },
    { key: 'placement', header: 'Drive', render: (r) => r.placementTitle },
    { key: 'company', header: 'Company', render: (r) => r.companyName },
    { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    {
      key: 'actions',
      header: '',
      render: (r) => (
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} onClick={() => setDetailModal(r)}>
            Details
          </button>
          {r.status === 'APPLIED' && (
            <>
              <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handlePipelineAction(r, 'shortlist')}>Shortlist</button>
              <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12, color: 'var(--color-danger)' }} disabled={busyId === r.id} onClick={() => handlePipelineAction(r, 'reject')}>Reject</button>
            </>
          )}
          {(r.status === 'SHORTLISTED' || r.status === 'INTERVIEW_SCHEDULED') && (
            <>
              <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handlePipelineAction(r, 'select')}>Select</button>
              <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12, color: 'var(--color-danger)' }} disabled={busyId === r.id} onClick={() => handlePipelineAction(r, 'not-select')}>Not select</button>
            </>
          )}
        </div>
      ),
    },
  ];

  return (
    <AppShell roleLabel="HR / Recruiter" sidebar={<HrSidebar />}>
      <h1 style={{ fontSize: 24, marginBottom: 20 }}>Applications</h1>

      <div style={{ display: 'flex', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
        <select value={placementFilter} onChange={(e) => { setPage(0); setPlacementFilter(e.target.value); }} style={selectStyle}>
          <option value="">All drives</option>
          {placements.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
        </select>
        <select value={statusFilter} onChange={(e) => { setPage(0); setStatusFilter(e.target.value); }} style={selectStyle}>
          {STATUSES.map((s) => <option key={s} value={s}>{s ? s.replace('_', ' ') : 'All statuses'}</option>)}
        </select>
      </div>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      <DataTable columns={columns} rows={rows} loading={loading} emptyLabel="No applications found." page={page} totalPages={totalPages} onPageChange={setPage} />

      <Modal open={Boolean(detailModal)} title={`${detailModal?.studentName || ''} — ${detailModal?.placementTitle || ''}`} onClose={() => setDetailModal(null)}>
        {detailModal && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>
              <p>{detailModal.studentEmail} · {detailModal.departmentName}</p>
              <p>Applied {detailModal.appliedAt ? new Date(detailModal.appliedAt).toLocaleDateString() : '—'}</p>
              {detailModal.rejectionReason && <p style={{ color: 'var(--color-danger)' }}>Reason: {detailModal.rejectionReason}</p>}
            </div>

            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                <strong style={{ fontSize: 14 }}>Interview rounds</strong>
                <button className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} onClick={() => openSchedule(detailModal)}>
                  + Schedule round
                </button>
              </div>
              {(detailModal.rounds || []).length === 0 ? (
                <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>No rounds scheduled yet.</p>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {detailModal.rounds.map((r) => (
                    <div key={r.roundNumber} style={{ padding: '10px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 13 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                        <span style={{ fontWeight: 600 }}>Round {r.roundNumber}: {r.roundType}</span>
                        <span>{r.status}</span>
                      </div>
                      <p style={{ color: 'var(--color-text-muted)' }}>{r.scheduledAt ? new Date(r.scheduledAt).toLocaleString() : '—'} {r.venue && `· ${r.venue}`}</p>
                      {r.result && r.result !== 'PENDING' && <p>Result: {r.result} {r.resultRemarks && `— ${r.resultRemarks}`}</p>}
                      <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
                        <button className="btn btn-ghost" style={{ padding: '4px 10px', fontSize: 11 }} onClick={() => openResult(r)}>Set result</button>
                        <button className="btn btn-ghost" style={{ padding: '4px 10px', fontSize: 11, color: 'var(--color-danger)' }} onClick={() => handleCancelRound(r.roundNumber)}>Cancel</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>

      <Modal open={Boolean(scheduleForm)} title="Schedule interview round" onClose={() => setScheduleForm(null)}>
        {scheduleForm && (
          <form onSubmit={handleScheduleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div className="field">
              <label htmlFor="roundType">Round type</label>
              <input id="roundType" required value={scheduleForm.roundType} onChange={(e) => setScheduleForm((f) => ({ ...f, roundType: e.target.value }))} placeholder="e.g. Technical Interview" />
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <div className="field" style={{ flex: 1 }}>
                <label htmlFor="rwhen">Scheduled for</label>
                <input id="rwhen" type="datetime-local" required value={scheduleForm.scheduledAt} onChange={(e) => setScheduleForm((f) => ({ ...f, scheduledAt: e.target.value }))} />
              </div>
              <div className="field" style={{ width: 120 }}>
                <label htmlFor="rdur">Duration (min)</label>
                <input id="rdur" type="number" value={scheduleForm.durationMinutes} onChange={(e) => setScheduleForm((f) => ({ ...f, durationMinutes: e.target.value }))} />
              </div>
            </div>
            <div className="field">
              <label htmlFor="rvenue">Venue</label>
              <input id="rvenue" value={scheduleForm.venue} onChange={(e) => setScheduleForm((f) => ({ ...f, venue: e.target.value }))} />
            </div>
            <div className="field">
              <label htmlFor="rlink">Meeting link</label>
              <input id="rlink" value={scheduleForm.meetingLink} onChange={(e) => setScheduleForm((f) => ({ ...f, meetingLink: e.target.value }))} />
            </div>
            <div className="field">
              <label htmlFor="rremarks">Remarks</label>
              <input id="rremarks" value={scheduleForm.remarks} onChange={(e) => setScheduleForm((f) => ({ ...f, remarks: e.target.value }))} />
            </div>
            <button className="btn btn-primary" type="submit" disabled={scheduleSaving}>
              {scheduleSaving ? 'Scheduling…' : 'Schedule'}
            </button>
          </form>
        )}
      </Modal>

      <Modal open={Boolean(resultRound)} title={`Result — Round ${resultRound?.roundNumber || ''}`} onClose={() => setResultRound(null)}>
        <form onSubmit={handleResultSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="field">
            <label htmlFor="rresult">Result</label>
            <select id="rresult" value={resultForm.result} onChange={(e) => setResultForm((f) => ({ ...f, result: e.target.value }))} style={selectStyle}>
              {RESULTS.map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="rresultremarks">Remarks</label>
            <input id="rresultremarks" value={resultForm.resultRemarks} onChange={(e) => setResultForm((f) => ({ ...f, resultRemarks: e.target.value }))} />
          </div>
          <button className="btn btn-primary" type="submit">Save result</button>
        </form>
      </Modal>
    </AppShell>
  );
}
