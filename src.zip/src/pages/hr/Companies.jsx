import { useEffect, useState, useCallback } from 'react';
import AppShell from '../../components/AppShell';
import HrSidebar from '../../components/HrSidebar';
import DataTable from '../../components/DataTable';
import Modal from '../../components/Modal';
import { searchCompanies, createCompany, updateCompany, uploadCompanyLogo, activateCompany, deactivateCompany } from '../../api/company';

const EMPTY_FORM = { name: '', description: '', industry: '', location: '', websiteUrl: '' };

export default function Companies() {
  const [rows, setRows] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);
  const [logoFile, setLogoFile] = useState(null);

  const load = useCallback(() => {
    setLoading(true);
    setError('');
    searchCompanies({ query: query || undefined, page, size: 10 })
      .then((res) => {
        const paged = res.data.data;
        setRows(paged.content);
        setTotalPages(paged.totalPages);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [query, page]);

  useEffect(() => {
    load();
  }, [load]);

  function openCreate() {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setLogoFile(null);
    setFormError('');
    setModalOpen(true);
  }

  function openEdit(c) {
    setEditingId(c.id);
    setForm({ name: c.name, description: c.description || '', industry: c.industry || '', location: c.location || '', websiteUrl: c.websiteUrl || '' });
    setLogoFile(null);
    setFormError('');
    setModalOpen(true);
  }

  async function handleSave(e) {
    e.preventDefault();
    setFormError('');
    setSaving(true);
    try {
      let id = editingId;
      if (editingId) {
        await updateCompany(editingId, form);
      } else {
        const res = await createCompany(form);
        id = res.data.data.id;
      }
      if (logoFile) await uploadCompanyLogo(id, logoFile);
      setModalOpen(false);
      load();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleToggle(c) {
    setBusyId(c.id);
    try {
      if (c.active) await deactivateCompany(c.id);
      else await activateCompany(c.id);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  const columns = [
    { key: 'name', header: 'Name' },
    { key: 'industry', header: 'Industry', render: (r) => r.industry || '—' },
    { key: 'location', header: 'Location', render: (r) => r.location || '—' },
    {
      key: 'active',
      header: 'Status',
      render: (r) => (
        <span style={{ fontSize: 12, fontWeight: 700, padding: '3px 10px', borderRadius: 999, color: r.active ? 'var(--color-success)' : 'var(--color-text-muted)', background: r.active ? 'rgba(47,158,99,0.12)' : 'var(--color-surface-alt)' }}>
          {r.active ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      key: 'actions',
      header: '',
      render: (r) => (
        <div style={{ display: 'flex', gap: 6 }}>
          <button className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} onClick={() => openEdit(r)}>Edit</button>
          <button className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handleToggle(r)}>
            {r.active ? 'Deactivate' : 'Activate'}
          </button>
        </div>
      ),
    },
  ];

  return (
    <AppShell roleLabel="HR / Recruiter" sidebar={<HrSidebar />}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
        <h1 style={{ fontSize: 24 }}>Companies</h1>
        <button className="btn btn-primary" onClick={openCreate}>+ New company</button>
      </div>

      <div style={{ marginBottom: 16, maxWidth: 320 }}>
        <input
          type="text"
          placeholder="Search companies…"
          value={query}
          onChange={(e) => { setPage(0); setQuery(e.target.value); }}
          style={{ width: '100%', padding: '10px 14px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', fontSize: 14, background: 'var(--color-surface)' }}
        />
      </div>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      <DataTable columns={columns} rows={rows} loading={loading} emptyLabel="No companies yet." page={page} totalPages={totalPages} onPageChange={setPage} />

      <Modal open={modalOpen} title={editingId ? 'Edit company' : 'New company'} onClose={() => setModalOpen(false)}>
        <form onSubmit={handleSave} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="field">
            <label htmlFor="cname">Name</label>
            <input id="cname" required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="cdesc">Description</label>
            <input id="cdesc" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="cindustry">Industry</label>
              <input id="cindustry" value={form.industry} onChange={(e) => setForm((f) => ({ ...f, industry: e.target.value }))} />
            </div>
            <div className="field" style={{ flex: 1 }}>
              <label htmlFor="clocation">Location</label>
              <input id="clocation" value={form.location} onChange={(e) => setForm((f) => ({ ...f, location: e.target.value }))} />
            </div>
          </div>
          <div className="field">
            <label htmlFor="cwebsite">Website</label>
            <input id="cwebsite" value={form.websiteUrl} onChange={(e) => setForm((f) => ({ ...f, websiteUrl: e.target.value }))} placeholder="https://…" />
          </div>
          <div className="field">
            <label htmlFor="clogo">Logo (optional)</label>
            <input id="clogo" type="file" accept="image/*" onChange={(e) => setLogoFile(e.target.files?.[0] || null)} />
          </div>
          {formError && <p className="error-text">{formError}</p>}
          <button className="btn btn-primary" type="submit" disabled={saving}>
            {saving ? 'Saving…' : editingId ? 'Save changes' : 'Create company'}
          </button>
        </form>
      </Modal>
    </AppShell>
  );
}
