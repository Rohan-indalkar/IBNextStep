import { useEffect, useState, useCallback } from 'react';
import AppShell from '../../components/AppShell';
import HrSidebar from '../../components/HrSidebar';
import DataTable from '../../components/DataTable';
import Modal from '../../components/Modal';
import { searchCompanies } from '../../api/company';
import { searchPlacements, createPlacement, updatePlacement, uploadPlacementPdf, publishPlacement, closePlacement } from '../../api/placement';

const TYPES = ['CAMPUS', 'OFF_CAMPUS'];

const EMPTY_ELIGIBILITY = { minAttendancePercentage: '', minQuizPercentage: '', minCodingPercentage: '', minMockInterviewRating: '', minStudentEvaluationScore: '', requireResumeApproved: false };
const EMPTY_FORM = {
  companyId: '', title: '', description: '', type: 'CAMPUS',
  eligibility: EMPTY_ELIGIBILITY, applicationDeadline: '', externalApplyLink: '',
  interviewRoundTemplates: [{ roundNumber: 1, name: '' }], packageLpa: '',
};

function StatusBadge({ status }) {
  const colors = { DRAFT: '#888', PUBLISHED: 'var(--color-success)', CLOSED: 'var(--color-danger)' };
  return <span style={{ fontSize: 12, fontWeight: 700, padding: '3px 10px', borderRadius: 999, color: '#fff', background: colors[status] || '#888' }}>{status}</span>;
}

export default function Placements() {
  const [companies, setCompanies] = useState([]);
  const [rows, setRows] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [pdfFile, setPdfFile] = useState(null);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    setError('');
    searchPlacements({ page, size: 10 })
      .then((res) => {
        const paged = res.data.data;
        setRows(paged.content);
        setTotalPages(paged.totalPages);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [page]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    searchCompanies({ active: true, page: 0, size: 100 })
      .then((res) => setCompanies(res.data.data.content))
      .catch(() => {});
  }, []);

  function openCreate() {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setPdfFile(null);
    setFormError('');
    setModalOpen(true);
  }

  function openEdit(p) {
    setEditingId(p.id);
    setForm({
      companyId: p.companyId,
      title: p.title,
      description: p.description || '',
      type: p.type,
      eligibility: p.eligibility
        ? Object.fromEntries(Object.entries(EMPTY_ELIGIBILITY).map(([k]) => [k, p.eligibility[k] ?? (k === 'requireResumeApproved' ? false : '')]))
        : EMPTY_ELIGIBILITY,
      applicationDeadline: p.applicationDeadline ? p.applicationDeadline.slice(0, 16) : '',
      externalApplyLink: p.externalApplyLink || '',
      interviewRoundTemplates: p.interviewRoundTemplates?.length ? p.interviewRoundTemplates : [{ roundNumber: 1, name: '' }],
      packageLpa: p.packageLpa ?? '',
    });
    setPdfFile(null);
    setFormError('');
    setModalOpen(true);
  }

  function updateRound(i, key, value) {
    setForm((f) => ({ ...f, interviewRoundTemplates: f.interviewRoundTemplates.map((r, idx) => (idx === i ? { ...r, [key]: value } : r)) }));
  }
  function addRound() {
    setForm((f) => ({ ...f, interviewRoundTemplates: [...f.interviewRoundTemplates, { roundNumber: f.interviewRoundTemplates.length + 1, name: '' }] }));
  }
  function removeRound(i) {
    setForm((f) => ({ ...f, interviewRoundTemplates: f.interviewRoundTemplates.filter((_, idx) => idx !== i) }));
  }

  async function handleSave(e) {
    e.preventDefault();
    setFormError('');
    setSaving(true);
    try {
      const eligibility = form.type === 'CAMPUS'
        ? {
            minAttendancePercentage: form.eligibility.minAttendancePercentage === '' ? null : Number(form.eligibility.minAttendancePercentage),
            minQuizPercentage: form.eligibility.minQuizPercentage === '' ? null : Number(form.eligibility.minQuizPercentage),
            minCodingPercentage: form.eligibility.minCodingPercentage === '' ? null : Number(form.eligibility.minCodingPercentage),
            minMockInterviewRating: form.eligibility.minMockInterviewRating === '' ? null : Number(form.eligibility.minMockInterviewRating),
            minStudentEvaluationScore: form.eligibility.minStudentEvaluationScore === '' ? null : Number(form.eligibility.minStudentEvaluationScore),
            requireResumeApproved: form.eligibility.requireResumeApproved,
          }
        : null;
      const rounds = form.interviewRoundTemplates.filter((r) => r.name.trim()).map((r, i) => ({ roundNumber: i + 1, name: r.name }));

      let id = editingId;
      if (editingId) {
        await updatePlacement(editingId, {
          title: form.title,
          description: form.description || null,
          eligibility,
          applicationDeadline: form.applicationDeadline ? new Date(form.applicationDeadline).toISOString() : null,
          externalApplyLink: form.externalApplyLink || null,
          interviewRoundTemplates: rounds,
          packageLpa: form.packageLpa === '' ? null : Number(form.packageLpa),
        });
      } else {
        const res = await createPlacement({
          companyId: form.companyId,
          title: form.title,
          description: form.description || null,
          type: form.type,
          eligibility,
          applicationDeadline: form.applicationDeadline ? new Date(form.applicationDeadline).toISOString() : null,
          externalApplyLink: form.externalApplyLink || null,
          interviewRoundTemplates: rounds,
          packageLpa: form.packageLpa === '' ? null : Number(form.packageLpa),
        });
        id = res.data.data.id;
      }
      if (pdfFile) await uploadPlacementPdf(id, pdfFile);
      setModalOpen(false);
      load();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleAction(p, action) {
    setBusyId(p.id);
    setError('');
    try {
      if (action === 'publish') await publishPlacement(p.id);
      else if (action === 'close') {
        if (!window.confirm(`Close "${p.title}"? No new applications after this.`)) return;
        await closePlacement(p.id);
      }
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  const selectStyle = { padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', fontSize: 14 };
  const companyNameById = Object.fromEntries(companies.map((c) => [c.id, c.name]));

  const columns = [
    { key: 'title', header: 'Title' },
    { key: 'company', header: 'Company', render: (r) => r.companyName || companyNameById[r.companyId] || '—' },
    { key: 'type', header: 'Type', render: (r) => r.type.replace('_', ' ') },
    { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    { key: 'applications', header: 'Applications', render: (r) => `${r.totalApplications ?? 0} (${r.selected ?? 0} selected)` },
    {
      key: 'actions',
      header: '',
      render: (r) => (
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {r.status === 'DRAFT' && (
            <>
              <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} onClick={() => openEdit(r)}>Edit</button>
              <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} disabled={busyId === r.id} onClick={() => handleAction(r, 'publish')}>Publish</button>
            </>
          )}
          {r.status === 'PUBLISHED' && (
            <>
              <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} onClick={() => openEdit(r)}>Edit</button>
              <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12, color: 'var(--color-danger)' }} disabled={busyId === r.id} onClick={() => handleAction(r, 'close')}>Close</button>
            </>
          )}
        </div>
      ),
    },
  ];

  return (
    <AppShell roleLabel="HR / Recruiter" sidebar={<HrSidebar />}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
        <h1 style={{ fontSize: 24 }}>Placement drives</h1>
        <button className="btn btn-primary" onClick={openCreate}>+ New drive</button>
      </div>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      <DataTable columns={columns} rows={rows} loading={loading} emptyLabel="No placement drives yet." page={page} totalPages={totalPages} onPageChange={setPage} />

      <Modal open={modalOpen} title={editingId ? 'Edit placement drive' : 'New placement drive'} onClose={() => setModalOpen(false)}>
        <form onSubmit={handleSave} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {!editingId && (
            <div className="field">
              <label htmlFor="pcompany">Company</label>
              <select id="pcompany" required value={form.companyId} onChange={(e) => setForm((f) => ({ ...f, companyId: e.target.value }))} style={selectStyle}>
                <option value="">Select…</option>
                {companies.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
          )}
          <div className="field">
            <label htmlFor="ptitle">Title</label>
            <input id="ptitle" required value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="pdesc">Description</label>
            <input id="pdesc" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
          </div>
          {!editingId && (
            <div className="field">
              <label htmlFor="ptype">Type</label>
              <select id="ptype" value={form.type} onChange={(e) => setForm((f) => ({ ...f, type: e.target.value }))} style={selectStyle}>
                {TYPES.map((t) => <option key={t} value={t}>{t.replace('_', ' ')}</option>)}
              </select>
            </div>
          )}

          {form.type === 'CAMPUS' && (
            <div className="field">
              <label>Eligibility criteria (leave blank to skip a rule)</label>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                <input placeholder="Min attendance %" type="number" value={form.eligibility.minAttendancePercentage} onChange={(e) => setForm((f) => ({ ...f, eligibility: { ...f.eligibility, minAttendancePercentage: e.target.value } }))} />
                <input placeholder="Min quiz %" type="number" value={form.eligibility.minQuizPercentage} onChange={(e) => setForm((f) => ({ ...f, eligibility: { ...f.eligibility, minQuizPercentage: e.target.value } }))} />
                <input placeholder="Min coding %" type="number" value={form.eligibility.minCodingPercentage} onChange={(e) => setForm((f) => ({ ...f, eligibility: { ...f.eligibility, minCodingPercentage: e.target.value } }))} />
                <input placeholder="Min mock interview (0-10)" type="number" value={form.eligibility.minMockInterviewRating} onChange={(e) => setForm((f) => ({ ...f, eligibility: { ...f.eligibility, minMockInterviewRating: e.target.value } }))} />
                <input placeholder="Min evaluation score (0-10)" type="number" value={form.eligibility.minStudentEvaluationScore} onChange={(e) => setForm((f) => ({ ...f, eligibility: { ...f.eligibility, minStudentEvaluationScore: e.target.value } }))} />
              </div>
              <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, marginTop: 8 }}>
                <input type="checkbox" checked={form.eligibility.requireResumeApproved} onChange={(e) => setForm((f) => ({ ...f, eligibility: { ...f.eligibility, requireResumeApproved: e.target.checked } }))} />
                Require approved resume
              </label>
            </div>
          )}

          <div className="field">
            <label htmlFor="pdeadline">Application deadline</label>
            <input id="pdeadline" type="datetime-local" value={form.applicationDeadline} onChange={(e) => setForm((f) => ({ ...f, applicationDeadline: e.target.value }))} />
          </div>
          <div className="field">
            <label htmlFor="plink">External apply link {form.type === 'OFF_CAMPUS' ? '' : '(optional)'}</label>
            <input id="plink" required={form.type === 'OFF_CAMPUS'} value={form.externalApplyLink} onChange={(e) => setForm((f) => ({ ...f, externalApplyLink: e.target.value }))} placeholder="https://…" />
          </div>
          <div className="field">
            <label htmlFor="ppackage">Package (LPA)</label>
            <input id="ppackage" type="number" step="0.1" value={form.packageLpa} onChange={(e) => setForm((f) => ({ ...f, packageLpa: e.target.value }))} />
          </div>

          <div className="field">
            <label>Interview round templates</label>
            {form.interviewRoundTemplates.map((r, i) => (
              <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
                <input value={r.name} onChange={(e) => updateRound(i, 'name', e.target.value)} placeholder={`Round ${i + 1} name`} style={{ flex: 1 }} />
                {form.interviewRoundTemplates.length > 1 && (
                  <button type="button" onClick={() => removeRound(i)} style={{ background: 'none', border: 'none', color: 'var(--color-danger)', cursor: 'pointer' }}>×</button>
                )}
              </div>
            ))}
            <button type="button" className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} onClick={addRound}>+ Add round</button>
          </div>

          <div className="field">
            <label htmlFor="ppdf">JD / brochure PDF (optional)</label>
            <input id="ppdf" type="file" accept="application/pdf" onChange={(e) => setPdfFile(e.target.files?.[0] || null)} />
          </div>

          {formError && <p className="error-text">{formError}</p>}
          <button className="btn btn-primary" type="submit" disabled={saving}>
            {saving ? 'Saving…' : editingId ? 'Save changes' : 'Create drive (draft)'}
          </button>
        </form>
      </Modal>
    </AppShell>
  );
}
