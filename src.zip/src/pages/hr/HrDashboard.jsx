import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import AppShell from '../../components/AppShell';
import HrSidebar from '../../components/HrSidebar';
import StatCard from '../../components/StatCard';
import { getHrDashboard } from '../../api/hrDashboard';

export default function HrDashboard() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getHrDashboard()
      .then((res) => setData(res.data.data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <AppShell roleLabel="HR / Recruiter" sidebar={<HrSidebar />}>
      <h1 style={{ fontSize: 24, marginBottom: 24 }}>Overview</h1>

      {error && <p className="error-text" style={{ marginBottom: 16 }}>{error}</p>}

      {loading ? (
        <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
      ) : data ? (
        <>
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 24 }}>
            <StatCard label="Companies" value={data.totalCompanies} />
            <StatCard label="Active companies" value={data.activeCompanies} />
            <StatCard label="Active drives" value={data.activePlacementDrives} accent />
            <StatCard label="Campus / Off-campus" value={`${data.campusDrives} / ${data.offCampusDrives}`} />
          </div>
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 32 }}>
            <StatCard label="Applications" value={data.applicationsReceived} />
            <StatCard label="Shortlisted" value={data.shortlisted} />
            <StatCard label="Interview scheduled" value={data.interviewScheduled} />
            <StatCard label="Selected" value={data.selected} accent />
            <StatCard label="Rejected" value={data.rejected} />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 20, marginBottom: 24 }}>
            <div className="card" style={{ padding: 24 }}>
              <h2 style={{ fontSize: 16, marginBottom: 14 }}>Interviews today</h2>
              <p style={{ fontSize: 28, fontWeight: 800, color: 'var(--color-accent)' }}>{data.todaysInterviews}</p>
              <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>{data.upcomingInterviews} upcoming overall</p>
            </div>
            <div className="card" style={{ padding: 24 }}>
              <h2 style={{ fontSize: 16, marginBottom: 14 }}>Company-wise hiring</h2>
              {Object.keys(data.companyWiseHiring || {}).length === 0 ? (
                <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>No selections yet.</p>
              ) : (
                Object.entries(data.companyWiseHiring).map(([k, v]) => (
                  <div key={k} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 4 }}>
                    <span>{k}</span><span style={{ fontWeight: 600 }}>{v}</span>
                  </div>
                ))
              )}
            </div>
          </div>

          {data.nextUpcomingInterviews?.length > 0 && (
            <div className="card" style={{ padding: 24, marginBottom: 24 }}>
              <h2 style={{ fontSize: 16, marginBottom: 14 }}>Next up</h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {data.nextUpcomingInterviews.map((i, idx) => (
                  <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 13 }}>
                    <span>{i.studentName} — {i.companyName} ({i.roundType})</span>
                    <span style={{ color: 'var(--color-text-muted)' }}>{i.scheduledAt ? new Date(i.scheduledAt).toLocaleString() : '—'}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      ) : null}

      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        <Link to="/app/hr/companies" className="btn btn-primary">Manage companies</Link>
        <Link to="/app/hr/placements" className="btn btn-ghost">Placement drives</Link>
        <Link to="/app/hr/applications" className="btn btn-ghost">Applications</Link>
      </div>
    </AppShell>
  );
}
