import { useEffect, useState } from 'react';
import AppShell from '../../components/AppShell';
import StudentSidebar from '../../components/StudentSidebar';
import { getMyMonthlyAttendance, downloadMonthlyReport } from '../../api/studentAttendance';

export default function Attendance() {
  const [year, setYear] = useState(new Date().getFullYear());
  const [month, setMonth] = useState(new Date().getMonth() + 1);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [exporting, setExporting] = useState(false);

  function load() {
    setLoading(true);
    setError('');
    getMyMonthlyAttendance(year, month)
      .then((res) => setData(res.data.data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, [year, month]);

  async function handleExport() {
    setExporting(true);
    try {
      await downloadMonthlyReport(year, month);
    } catch (err) {
      setError(err.message);
    } finally {
      setExporting(false);
    }
  }

  const statusColor = { PRESENT: 'var(--color-success)', ABSENT: 'var(--color-danger)', LATE: 'var(--color-warning)' };

  return (
    <AppShell roleLabel="Student" sidebar={<StudentSidebar />}>
      <h1 style={{ fontSize: 24, marginBottom: 20 }}>Attendance</h1>

      <div style={{ display: 'flex', gap: 10, marginBottom: 20, alignItems: 'flex-end', flexWrap: 'wrap' }}>
        <div className="field">
          <label htmlFor="year">Year</label>
          <input id="year" type="number" value={year} onChange={(e) => setYear(Number(e.target.value))} style={{ width: 100 }} />
        </div>
        <div className="field">
          <label htmlFor="month">Month</label>
          <input id="month" type="number" min={1} max={12} value={month} onChange={(e) => setMonth(Number(e.target.value))} style={{ width: 80 }} />
        </div>
        <button className="btn btn-ghost" onClick={handleExport} disabled={exporting} style={{ height: 44 }}>
          {exporting ? 'Exporting…' : 'Download report'}
        </button>
      </div>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      {loading ? (
        <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
      ) : data ? (
        <>
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 24 }}>
            <div className="card" style={{ padding: '20px 24px' }}>
              <div style={{ fontSize: 30, fontWeight: 800, color: 'var(--color-accent)' }}>{data.attendancePercentage}%</div>
              <div style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Attendance this month</div>
            </div>
            <div className="card" style={{ padding: '20px 24px' }}>
              <div style={{ fontSize: 30, fontWeight: 800, color: 'var(--color-primary)' }}>{data.presentCount}/{data.totalDays}</div>
              <div style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Present days ({data.absentCount} absent, {data.lateCount} late)</div>
            </div>
          </div>

          <div className="card" style={{ padding: 20 }}>
            {data.records?.length === 0 ? (
              <p style={{ color: 'var(--color-text-muted)', fontSize: 14 }}>No records for this month.</p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {data.records.map((r, i) => (
                  <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 13 }}>
                    <span>{r.date}</span>
                    <span style={{ color: statusColor[r.status] || 'var(--color-text-muted)', fontWeight: 700 }}>{r.status}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      ) : null}
    </AppShell>
  );
}
