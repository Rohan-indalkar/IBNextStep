import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AppShell from '../../components/AppShell';
import StudentSidebar from '../../components/StudentSidebar';
import Modal from '../../components/Modal';
import { listAssignedAssessments } from '../../api/studentAssessment';

function StatusBadge({ status }) {
  const colors = { PUBLISHED: 'var(--color-success)', COMPLETED: 'var(--color-text-muted)', ARCHIVED: '#888' };
  return <span style={{ fontSize: 12, fontWeight: 700, padding: '3px 10px', borderRadius: 999, color: '#fff', background: colors[status] || '#888' }}>{status}</span>;
}

export default function CodingAssessments() {
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [confirmItem, setConfirmItem] = useState(null);

  useEffect(() => {
    listAssignedAssessments()
      .then((res) => setItems(res.data.data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  const now = Date.now();

  return (
    <AppShell roleLabel="Student" sidebar={<StudentSidebar />}>
      <h1 style={{ fontSize: 24, marginBottom: 20 }}>Coding assessments</h1>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      {loading ? (
        <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
      ) : items.length === 0 ? (
        <p style={{ color: 'var(--color-text-muted)' }}>No assessments assigned yet.</p>
      ) : (
        <div className="card" style={{ overflow: 'hidden' }}>
          {items.map((a) => {
            const started = new Date(a.startTime).getTime();
            const ended = new Date(a.endTime).getTime();
            const isOpen = a.status === 'PUBLISHED' && now >= started && now <= ended;
            return (
              <div key={a.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 18px', borderBottom: '1px solid var(--color-border)' }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{a.title}</div>
                  <div style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>
                    {a.questionIds?.length ?? 0} questions · {a.durationMinutes} min · {new Date(a.startTime).toLocaleString()} – {new Date(a.endTime).toLocaleString()}
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <StatusBadge status={a.status} />
                  {isOpen ? (
                    <button className="btn btn-primary" style={{ padding: '6px 16px', fontSize: 13 }} onClick={() => setConfirmItem(a)}>
                      Start
                    </button>
                  ) : (
                    <span style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>{now < started ? 'Not open yet' : now > ended ? 'Closed' : a.status}</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal open={Boolean(confirmItem)} title={`Start "${confirmItem?.title || ''}"?`} onClose={() => setConfirmItem(null)}>
        <p style={{ fontSize: 14, color: 'var(--color-text-muted)', marginBottom: 16 }}>
          You'll have {confirmItem?.durationMinutes} minutes. Tab switches, fullscreen exits, and copy/paste
          attempts are recorded. Submitting a question grades it against hidden test cases immediately — you can't undo it.
        </p>
        <button className="btn btn-primary" onClick={() => navigate(`/app/student/assessments/${confirmItem.id}/attempt`)}>
          Start now
        </button>
      </Modal>
    </AppShell>
  );
}
