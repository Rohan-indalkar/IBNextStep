import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AppShell from '../../components/AppShell';
import StudentSidebar from '../../components/StudentSidebar';
import Modal from '../../components/Modal';
import { listAssignedQuizzes, getMyResults } from '../../api/studentQuiz';

function StatusBadge({ status }) {
  const colors = { SCHEDULED: 'var(--color-warning)', ACTIVE: 'var(--color-success)', COMPLETED: 'var(--color-text-muted)', EXPIRED: 'var(--color-danger)' };
  return <span style={{ fontSize: 12, fontWeight: 700, padding: '3px 10px', borderRadius: 999, color: '#fff', background: colors[status] || '#888' }}>{status}</span>;
}

export default function Quizzes() {
  const navigate = useNavigate();
  const [tab, setTab] = useState('assigned');
  const [quizzes, setQuizzes] = useState([]);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [confirmQuiz, setConfirmQuiz] = useState(null);

  useEffect(() => {
    setLoading(true);
    Promise.all([listAssignedQuizzes(), getMyResults()])
      .then(([q, r]) => {
        setQuizzes(q.data.data);
        setResults(r.data.data);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  const resultByQuizId = Object.fromEntries(results.map((r) => [r.quizId, r]));

  return (
    <AppShell roleLabel="Student" sidebar={<StudentSidebar />}>
      <h1 style={{ fontSize: 24, marginBottom: 20 }}>Quizzes</h1>

      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        {['assigned', 'results'].map((t) => (
          <button key={t} onClick={() => setTab(t)} className={tab === t ? 'btn btn-primary' : 'btn btn-ghost'} style={{ padding: '8px 18px', fontSize: 13, textTransform: 'capitalize' }}>
            {t === 'assigned' ? 'Assigned' : 'My results'}
          </button>
        ))}
      </div>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      {loading ? (
        <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
      ) : tab === 'assigned' ? (
        quizzes.length === 0 ? (
          <p style={{ color: 'var(--color-text-muted)' }}>No quizzes assigned yet.</p>
        ) : (
          <div className="card" style={{ overflow: 'hidden' }}>
            {quizzes.map((q) => {
              const result = resultByQuizId[q.id];
              return (
                <div key={q.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 18px', borderBottom: '1px solid var(--color-border)' }}>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{q.title}</div>
                    <div style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>
                      {q.topic} · {q.questionCount} questions · {q.durationMinutes} min · pass {q.passingPercentage}%
                    </div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <StatusBadge status={q.status} />
                    {result ? (
                      <span style={{ fontSize: 13, fontWeight: 700, color: result.passed ? 'var(--color-success)' : 'var(--color-danger)' }}>
                        {result.percentage}% {result.passed ? 'Passed' : 'Failed'}
                      </span>
                    ) : q.status === 'ACTIVE' ? (
                      <button className="btn btn-primary" style={{ padding: '6px 16px', fontSize: 13 }} onClick={() => setConfirmQuiz(q)}>
                        Start
                      </button>
                    ) : (
                      <span style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>Not open</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )
      ) : results.length === 0 ? (
        <p style={{ color: 'var(--color-text-muted)' }}>No quiz attempts yet.</p>
      ) : (
        <div className="card" style={{ overflow: 'hidden' }}>
          {results.map((r) => (
            <div key={r.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '14px 18px', borderBottom: '1px solid var(--color-border)', fontSize: 14 }}>
              <span>{r.obtainedMarks}/{r.totalMarks} marks · {r.correctAnswers} correct, {r.wrongAnswers} wrong</span>
              <span style={{ fontWeight: 700, color: r.passed ? 'var(--color-success)' : 'var(--color-danger)' }}>{r.percentage}%</span>
            </div>
          ))}
        </div>
      )}

      <Modal open={Boolean(confirmQuiz)} title={`Start "${confirmQuiz?.title || ''}"?`} onClose={() => setConfirmQuiz(null)}>
        <p style={{ fontSize: 14, color: 'var(--color-text-muted)', marginBottom: 16 }}>
          You'll have {confirmQuiz?.durationMinutes} minutes once you start. Tab switches, fullscreen exits, and
          copy/paste attempts are recorded. The quiz auto-submits when time runs out.
        </p>
        <button className="btn btn-primary" onClick={() => navigate(`/app/student/quizzes/${confirmQuiz.id}/attempt`)}>
          Start now
        </button>
      </Modal>
    </AppShell>
  );
}
