import { useEffect, useRef, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Logo from '../../components/Logo';
import {
  listAssignedAssessments,
  startAssessment,
  getQuestion,
  navigate as navigateQuestion,
  saveDraft,
  runCode,
  submitQuestion,
  reviewSubmissions,
  completeAssessment,
  reportWarning,
} from '../../api/studentAssessment';

const TEMPLATES = {
  JAVA: 'public class Main {\n    public static void main(String[] args) {\n        \n    }\n}',
  PYTHON3: '# your code here\n',
  CPP: '#include <bits/stdc++.h>\nusing namespace std;\n\nint main() {\n    \n    return 0;\n}',
  C: '#include <stdio.h>\n\nint main() {\n    \n    return 0;\n}',
  JAVASCRIPT: '// your code here\n',
};

export default function AssessmentAttempt() {
  const { id } = useParams();
  const navigate = useNavigate();
  const containerRef = useRef(null);

  const [assessment, setAssessment] = useState(null);
  const [session, setSession] = useState(null);
  const [question, setQuestion] = useState(null);
  const [language, setLanguage] = useState('');
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [running, setRunning] = useState(false);
  const [runResult, setRunResult] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [submitResult, setSubmitResult] = useState(null);
  const [warningCount, setWarningCount] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(null);
  const [submissions, setSubmissions] = useState(null);

  const codeRef = useRef('');
  codeRef.current = code;
  const languageRef = useRef('');
  languageRef.current = language;
  const doneRef = useRef(false);

  useEffect(() => {
    listAssignedAssessments()
      .then((res) => {
        const a = res.data.data.find((x) => x.id === id);
        setAssessment(a);
      })
      .catch((err) => setError(err.message));

    startAssessment(id)
      .then((res) => setSession(res.data.data))
      .catch((err) => setError(err.message));

    containerRef.current?.requestFullscreen?.().catch(() => {});
  }, [id]);

  const loadQuestion = useCallback(
    (questionId, drafts) => {
      getQuestion(id, questionId)
        .then((res) => {
          const q = res.data.data;
          setQuestion(q);
          const draft = drafts?.[questionId];
          const lang = draft?.language || q.allowedLanguages[0];
          setLanguage(lang);
          setCode(draft?.code || TEMPLATES[lang] || '');
          setRunResult(null);
          setSubmitResult(null);
        })
        .catch((err) => setError(err.message));
    },
    [id]
  );

  useEffect(() => {
    if (!session || !assessment?.questionIds) return;
    const qid = assessment.questionIds[session.currentQuestionIndex];
    if (qid) loadQuestion(qid, session.drafts);
  }, [session, assessment, loadQuestion]);

  useEffect(() => {
    if (!assessment || secondsLeft !== null) return;
    setSecondsLeft(assessment.durationMinutes * 60);
  }, [assessment, secondsLeft]);

  const handleComplete = useCallback(async () => {
    if (doneRef.current) return;
    doneRef.current = true;
    try {
      await completeAssessment(id);
      const res = await reviewSubmissions(id);
      setSubmissions(res.data.data);
    } catch (err) {
      setError(err.message);
    } finally {
      if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {});
    }
  }, [id]);

  useEffect(() => {
    if (secondsLeft === null || submissions) return;
    if (secondsLeft <= 0) {
      handleComplete();
      return;
    }
    const t = setTimeout(() => setSecondsLeft((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [secondsLeft, submissions, handleComplete]);

  useEffect(() => {
    if (!question || submissions) return;
    const interval = setInterval(() => {
      saveDraft(id, question.id, languageRef.current, codeRef.current).catch(() => {});
    }, 10000);
    return () => clearInterval(interval);
  }, [id, question, submissions]);

  const logWarning = useCallback(
    (type) => {
      if (doneRef.current) return;
      reportWarning(id, type).catch(() => {});
      setWarningCount((c) => c + 1);
    },
    [id]
  );

  useEffect(() => {
    if (submissions) return;
    function onVisibility() {
      if (document.hidden) logWarning('TAB_SWITCH');
    }
    function onFullscreenChange() {
      if (!document.fullscreenElement) logWarning('FULLSCREEN_EXIT');
    }
    function onCopy(e) {
      e.preventDefault();
      logWarning('COPY_ATTEMPT');
    }
    function onPaste(e) {
      e.preventDefault();
      logWarning('PASTE_ATTEMPT');
    }
    document.addEventListener('visibilitychange', onVisibility);
    document.addEventListener('fullscreenchange', onFullscreenChange);
    document.addEventListener('copy', onCopy);
    document.addEventListener('paste', onPaste);
    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      document.removeEventListener('fullscreenchange', onFullscreenChange);
      document.removeEventListener('copy', onCopy);
      document.removeEventListener('paste', onPaste);
    };
  }, [logWarning, submissions]);

  async function handleRun() {
    setRunning(true);
    setError('');
    try {
      const res = await runCode(id, question.id, language, code);
      setRunResult(res.data.data);
    } catch (err) {
      setError(err.message);
    } finally {
      setRunning(false);
    }
  }

  async function handleSubmitQuestion() {
    if (!window.confirm('Submit this question? It will be graded against all test cases, including hidden ones.')) return;
    setSubmitting(true);
    setError('');
    try {
      const res = await submitQuestion(id, question.id, language, code);
      setSubmitResult(res.data.data);
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  async function goToIndex(idx) {
    try {
      await saveDraft(id, question.id, language, code);
      const res = await navigateQuestion(id, idx);
      setSession(res.data.data);
    } catch (err) {
      setError(err.message);
    }
  }

  function formatTime(s) {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${String(sec).padStart(2, '0')}`;
  }

  if (submissions) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20, background: 'var(--color-bg)' }}>
        <div className="card" style={{ padding: 40, maxWidth: 480, textAlign: 'center' }}>
          <Logo size={32} withWordmark={false} />
          <h1 style={{ fontSize: 22, margin: '20px 0 16px' }}>Assessment complete</h1>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 24, textAlign: 'left' }}>
            {submissions.map((s) => (
              <div key={s.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 13 }}>
                <span>{s.language}</span>
                <span style={{ fontWeight: 700, color: s.status === 'ACCEPTED' ? 'var(--color-success)' : 'var(--color-danger)' }}>{s.status} — {s.marksAwarded} marks</span>
              </div>
            ))}
          </div>
          <button className="btn btn-primary" onClick={() => navigate('/app/student/assessments')}>Back to assessments</button>
        </div>
      </div>
    );
  }

  if (error && !question) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
        <div className="card" style={{ padding: 32, maxWidth: 420, textAlign: 'center' }}>
          <p className="error-text" style={{ marginBottom: 16 }}>{error}</p>
          <button className="btn btn-primary" onClick={() => navigate('/app/student/assessments')}>Back</button>
        </div>
      </div>
    );
  }

  if (!assessment || !session || !question) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <p style={{ color: 'var(--color-text-muted)' }}>Loading assessment…</p>
      </div>
    );
  }

  return (
    <div ref={containerRef} style={{ minHeight: '100vh', background: 'var(--color-bg)' }}>
      <header style={{ background: 'var(--color-surface)', borderBottom: '1px solid var(--color-border)', padding: '14px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'sticky', top: 0, zIndex: 10 }}>
        <div>
          <strong style={{ fontSize: 15 }}>{assessment.title}</strong>
          {warningCount > 0 && <span style={{ marginLeft: 12, fontSize: 12, color: 'var(--color-danger)' }}>{warningCount} warning(s) logged</span>}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <span style={{ fontSize: 18, fontWeight: 800, color: secondsLeft < 60 ? 'var(--color-danger)' : 'var(--color-primary)' }}>{formatTime(secondsLeft ?? 0)}</span>
          <button className="btn btn-ghost" style={{ padding: '6px 14px', fontSize: 12 }} onClick={handleComplete}>
            Finish assessment
          </button>
        </div>
      </header>

      <div style={{ display: 'flex', gap: 0, minHeight: 'calc(100vh - 61px)' }}>
        <div style={{ width: 90, borderRight: '1px solid var(--color-border)', padding: 16, display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'center' }}>
          {assessment.questionIds.map((qid, i) => (
            <button
              key={qid}
              onClick={() => goToIndex(i)}
              style={{
                width: 36,
                height: 36,
                borderRadius: '50%',
                border: '1.5px solid var(--color-border)',
                background: i === session.currentQuestionIndex ? 'var(--color-primary)' : session.drafts?.[qid] ? 'var(--color-surface-alt)' : 'transparent',
                color: i === session.currentQuestionIndex ? '#fff' : 'var(--color-text)',
                fontSize: 13,
                cursor: 'pointer',
              }}
            >
              {i + 1}
            </button>
          ))}
        </div>

        <div style={{ flex: 1, padding: 24, overflowY: 'auto', borderRight: '1px solid var(--color-border)', maxWidth: 420 }}>
          <p style={{ fontSize: 11, fontWeight: 700, color: 'var(--color-accent)', textTransform: 'uppercase', marginBottom: 6 }}>
            {question.difficulty} · {question.marks} marks
          </p>
          <h2 style={{ fontSize: 18, marginBottom: 14 }}>{question.title}</h2>
          <p style={{ fontSize: 14, whiteSpace: 'pre-wrap', marginBottom: 14 }}>{question.problemStatement}</p>
          {question.inputFormat && <p style={{ fontSize: 13, marginBottom: 8 }}><strong>Input:</strong> {question.inputFormat}</p>}
          {question.outputFormat && <p style={{ fontSize: 13, marginBottom: 8 }}><strong>Output:</strong> {question.outputFormat}</p>}
          {question.constraints && <p style={{ fontSize: 13, marginBottom: 14 }}><strong>Constraints:</strong> {question.constraints}</p>}
          {question.publicTestCases?.map((tc) => (
            <div key={tc.id} style={{ padding: '10px 12px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 12, marginBottom: 8, fontFamily: 'monospace' }}>
              <div>Input: {tc.input}</div>
              <div>Expected: {tc.expectedOutput}</div>
            </div>
          ))}
        </div>

        <div style={{ flex: 1.4, display: 'flex', flexDirection: 'column', padding: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
            <select
              value={language}
              onChange={(e) => {
                setLanguage(e.target.value);
                if (!code || code === TEMPLATES[language]) setCode(TEMPLATES[e.target.value] || '');
              }}
              style={{ padding: '8px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', fontSize: 13 }}
            >
              {question.allowedLanguages.map((l) => (
                <option key={l} value={l}>{l}</option>
              ))}
            </select>
            {submitResult ? (
              <span style={{ fontSize: 13, fontWeight: 700, color: submitResult.status === 'ACCEPTED' ? 'var(--color-success)' : 'var(--color-danger)' }}>
                {submitResult.status} — {submitResult.marksAwarded} marks
              </span>
            ) : (
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn btn-ghost" style={{ padding: '7px 16px', fontSize: 12 }} onClick={handleRun} disabled={running}>
                  {running ? 'Running…' : 'Run'}
                </button>
                <button className="btn btn-primary" style={{ padding: '7px 16px', fontSize: 12 }} onClick={handleSubmitQuestion} disabled={submitting}>
                  {submitting ? 'Submitting…' : 'Submit'}
                </button>
              </div>
            )}
          </div>

          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            spellCheck={false}
            style={{
              flex: 1,
              minHeight: 320,
              fontFamily: 'monospace',
              fontSize: 13,
              padding: 16,
              borderRadius: 'var(--radius-sm)',
              border: '1.5px solid var(--color-border)',
              background: '#1e1e1e',
              color: '#d4d4d4',
              resize: 'vertical',
            }}
          />

          {error && <p className="error-text" style={{ marginTop: 10 }}>{error}</p>}

          {runResult && (
            <div style={{ marginTop: 14 }}>
              {!runResult.compiled && (
                <pre style={{ fontSize: 12, color: 'var(--color-danger)', whiteSpace: 'pre-wrap', background: 'var(--color-surface-alt)', padding: 12, borderRadius: 'var(--radius-sm)' }}>
                  {runResult.compilationOutput}
                </pre>
              )}
              {runResult.results?.map((r) => (
                <div key={r.testCaseId} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 12px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 12, marginBottom: 6 }}>
                  <span>Input: {r.input}</span>
                  <span style={{ fontWeight: 700, color: r.passed ? 'var(--color-success)' : 'var(--color-danger)' }}>{r.passed ? 'Passed' : 'Failed'}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
