import { useEffect, useState } from 'react';
import AppShell from '../../components/AppShell';
import StudentSidebar from '../../components/StudentSidebar';
import { getMyEvaluations, getMyCombinedEvaluation } from '../../api/studentEvaluationView';

function RubricSide({ label, evaluation }) {
  if (!evaluation) {
    return (
      <div className="card" style={{ padding: 20 }}>
        <h3 style={{ fontSize: 15, marginBottom: 8 }}>{label}</h3>
        <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Not evaluated yet.</p>
      </div>
    );
  }
  return (
    <div className="card" style={{ padding: 20 }}>
      <h3 style={{ fontSize: 15, marginBottom: 10 }}>{label}</h3>
      <p style={{ fontSize: 28, fontWeight: 800, color: 'var(--color-accent)', marginBottom: 6 }}>
        {evaluation.overallRubricScore ?? '—'}/10
      </p>
      <p style={{ fontSize: 13, fontWeight: 700, color: evaluation.finalEligible ? 'var(--color-success)' : 'var(--color-danger)', marginBottom: 10 }}>
        {evaluation.finalEligible ? 'Eligible' : 'Not eligible'}
      </p>
      {evaluation.skillScores && Object.entries(evaluation.skillScores).map(([k, v]) => (
        <div key={k} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 3 }}>
          <span>{k}</span><span style={{ fontWeight: 600 }}>{v}/10</span>
        </div>
      ))}
      {evaluation.remarks && <p style={{ fontSize: 13, marginTop: 10, color: 'var(--color-text-muted)' }}>{evaluation.remarks}</p>}
    </div>
  );
}

export default function Evaluations() {
  const [combined, setCombined] = useState(null);
  const [history, setHistory] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getMyCombinedEvaluation(), getMyEvaluations()])
      .then(([c, h]) => {
        setCombined(c.data.data);
        setHistory(h.data.data);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <AppShell roleLabel="Student" sidebar={<StudentSidebar />}>
      <h1 style={{ fontSize: 24, marginBottom: 20 }}>Evaluations</h1>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      {loading ? (
        <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
      ) : (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 16, marginBottom: 24 }}>
            <RubricSide label="Technical" evaluation={combined?.technical} />
            <RubricSide label="Soft Skill" evaluation={combined?.softSkill} />
          </div>

          {combined?.combinedRubricScore != null && (
            <div className="card" style={{ padding: 20, marginBottom: 24 }}>
              <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Combined score</p>
              <p style={{ fontSize: 26, fontWeight: 800, color: 'var(--color-primary)' }}>{combined.combinedRubricScore}/10</p>
              {combined.combinedFinalEligible != null && (
                <p style={{ fontSize: 13, fontWeight: 700, color: combined.combinedFinalEligible ? 'var(--color-success)' : 'var(--color-danger)' }}>
                  {combined.combinedFinalEligible ? 'Eligible overall' : 'Not eligible overall'}
                </p>
              )}
            </div>
          )}

          <div className="card" style={{ padding: 20 }}>
            <h2 style={{ fontSize: 16, marginBottom: 14 }}>Full history</h2>
            {history.length === 0 ? (
              <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>No evaluations yet.</p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {history.map((h) => (
                  <div key={h.id} style={{ padding: '10px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 13 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ fontWeight: 600 }}>{h.trainerType?.replace('_', ' ')} by {h.trainerName}</span>
                      <span>{h.overallRubricScore}/10</span>
                    </div>
                    <p style={{ color: 'var(--color-text-muted)' }}>{h.evaluatedAt ? new Date(h.evaluatedAt).toLocaleDateString() : ''}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </AppShell>
  );
}
