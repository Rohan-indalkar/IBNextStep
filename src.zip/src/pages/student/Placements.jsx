import { useEffect, useState } from 'react';
import AppShell from '../../components/AppShell';
import StudentSidebar from '../../components/StudentSidebar';
import DataTable from '../../components/DataTable';
import Modal from '../../components/Modal';
import { browsePlacements, getPlacement, applyToPlacement, getMyApplications, downloadPlacementPdf } from '../../api/studentPlacement';

function StatusBadge({ status }) {
  const colors = { APPLIED: '#888', SHORTLISTED: 'var(--color-warning)', REJECTED: 'var(--color-danger)', INTERVIEW_SCHEDULED: 'var(--color-info)', SELECTED: 'var(--color-success)', NOT_SELECTED: 'var(--color-danger)' };
  return <span style={{ fontSize: 12, fontWeight: 700, padding: '3px 10px', borderRadius: 999, color: '#fff', background: colors[status] || '#888' }}>{status?.replace('_', ' ')}</span>;
}

export default function Placements() {
  const [tab, setTab] = useState('browse');
  const [rows, setRows] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [applications, setApplications] = useState([]);

  const [detail, setDetail] = useState(null);
  const [applying, setApplying] = useState(false);

  function loadBrowse() {
    setLoading(true);
    setError('');
    browsePlacements(page, 10)
      .then((res) => {
        const paged = res.data.data;
        setRows(paged.content);
        setTotalPages(paged.totalPages);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  function loadApplications() {
    setLoading(true);
    getMyApplications()
      .then((res) => setApplications(res.data.data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    if (tab === 'browse') loadBrowse();
    else loadApplications();
  }, [tab, page]);

  function openDetail(p) {
    getPlacement(p.id)
      .then((res) => setDetail(res.data.data))
      .catch((err) => setError(err.message));
  }

  async function handleApply() {
    setApplying(true);
    setError('');
    try {
      await applyToPlacement(detail.id);
      const res = await getPlacement(detail.id);
      setDetail(res.data.data);
      loadBrowse();
    } catch (err) {
      setError(err.message);
    } finally {
      setApplying(false);
    }
  }

  async function handleDownloadPdf() {
    try {
      await downloadPlacementPdf(detail.id, detail.pdfFileName);
    } catch (err) {
      setError(err.message);
    }
  }

  const columns = [
    { key: 'title', header: 'Title' },
    { key: 'company', header: 'Company', render: (r) => r.companyName },
    { key: 'type', header: 'Type', render: (r) => r.type.replace('_', ' ') },
    { key: 'package', header: 'Package', render: (r) => (r.packageLpa ? `${r.packageLpa} LPA` : '—') },
    { key: 'eligible', header: 'Eligible', render: (r) => (r.eligible ? <span style={{ color: 'var(--color-success)', fontWeight: 700 }}>Yes</span> : <span style={{ color: 'var(--color-text-muted)' }}>No</span>) },
    {
      key: 'status',
      header: 'Status',
      render: (r) => (r.alreadyApplied ? <StatusBadge status={r.myApplicationStatus} /> : '—'),
    },
    {
      key: 'actions',
      header: '',
      render: (r) => (
        <button className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} onClick={() => openDetail(r)}>
          View
        </button>
      ),
    },
  ];

  return (
    <AppShell roleLabel="Student" sidebar={<StudentSidebar />}>
      <h1 style={{ fontSize: 24, marginBottom: 20 }}>Placements</h1>

      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        {['browse', 'applications'].map((t) => (
          <button key={t} onClick={() => setTab(t)} className={tab === t ? 'btn btn-primary' : 'btn btn-ghost'} style={{ padding: '8px 18px', fontSize: 13, textTransform: 'capitalize' }}>
            {t === 'browse' ? 'Browse drives' : 'My applications'}
          </button>
        ))}
      </div>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      {tab === 'browse' ? (
        <DataTable columns={columns} rows={rows} loading={loading} emptyLabel="No placement drives available." page={page} totalPages={totalPages} onPageChange={setPage} />
      ) : loading ? (
        <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
      ) : applications.length === 0 ? (
        <p style={{ color: 'var(--color-text-muted)' }}>You haven't applied to any drives yet.</p>
      ) : (
        <div className="card" style={{ overflow: 'hidden' }}>
          {applications.map((a) => (
            <div key={a.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 18px', borderBottom: '1px solid var(--color-border)' }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14 }}>{a.placementTitle}</div>
                <div style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>{a.companyName} · applied {a.appliedAt ? new Date(a.appliedAt).toLocaleDateString() : ''}</div>
              </div>
              <StatusBadge status={a.status} />
            </div>
          ))}
        </div>
      )}

      <Modal open={Boolean(detail)} title={detail?.title || ''} onClose={() => setDetail(null)}>
        {detail && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <p style={{ fontSize: 14, color: 'var(--color-text-muted)' }}>{detail.description}</p>
            <p style={{ fontSize: 13 }}>
              {detail.companyName} · {detail.type.replace('_', ' ')} {detail.packageLpa && `· ${detail.packageLpa} LPA`}
            </p>
            {detail.applicationDeadline && (
              <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Deadline: {new Date(detail.applicationDeadline).toLocaleString()}</p>
            )}

            {!detail.eligible && detail.eligibility?.failedCriteria?.length > 0 && (
              <div style={{ padding: '12px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 13 }}>
                <p style={{ fontWeight: 700, color: 'var(--color-danger)', marginBottom: 6 }}>Not eligible:</p>
                {detail.eligibility.failedCriteria.map((c, i) => (
                  <p key={i}>{c.criterion}: need {c.required}, you have {c.current}</p>
                ))}
              </div>
            )}

            <div style={{ display: 'flex', gap: 10 }}>
              {detail.pdfDownloadEnabled && (
                <button className="btn btn-ghost" onClick={handleDownloadPdf}>Download JD</button>
              )}
              {detail.externalApplyLink && (
                <a href={detail.externalApplyLink} target="_blank" rel="noreferrer" className="btn btn-ghost">
                  External link
                </a>
              )}
            </div>

            {detail.alreadyApplied ? (
              <p style={{ fontSize: 13, fontWeight: 700 }}>You've applied — status: <StatusBadge status={detail.myApplicationStatus} /></p>
            ) : detail.applyEnabled ? (
              <button className="btn btn-primary" onClick={handleApply} disabled={applying}>
                {applying ? 'Applying…' : 'Apply now'}
              </button>
            ) : (
              <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Applications aren't open for this drive.</p>
            )}
          </div>
        )}
      </Modal>
    </AppShell>
  );
}
