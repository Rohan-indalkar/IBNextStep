import { useEffect, useState } from 'react';
import AppShell from '../../components/AppShell';
import StudentSidebar from '../../components/StudentSidebar';
import { getMyResume, uploadResume } from '../../api/studentResume';

function StatusBadge({ status }) {
  const colors = { PENDING_REVIEW: 'var(--color-warning)', NEEDS_CHANGES: 'var(--color-danger)', APPROVED: 'var(--color-success)' };
  return <span style={{ fontSize: 12, fontWeight: 700, padding: '3px 10px', borderRadius: 999, color: '#fff', background: colors[status] || '#888' }}>{status?.replace('_', ' ')}</span>;
}

export default function Resume() {
  const [resume, setResume] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);

  function load() {
    setLoading(true);
    getMyResume()
      .then((res) => setResume(res.data.data))
      .catch((err) => {
        if (err.response?.status !== 404) setError(err.message);
      })
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function handleUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError('');
    try {
      await uploadResume(file);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  }

  const latest = resume?.versions?.[resume.versions.length - 1];

  return (
    <AppShell roleLabel="Student" sidebar={<StudentSidebar />}>
      <h1 style={{ fontSize: 24, marginBottom: 20 }}>Resume</h1>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      <div style={{ marginBottom: 24 }}>
        <input id="resumeUpload" type="file" accept=".pdf,.doc,.docx" onChange={handleUpload} style={{ display: 'none' }} />
        <label htmlFor="resumeUpload" className="btn btn-primary" style={{ cursor: 'pointer', display: 'inline-flex' }}>
          {uploading ? 'Uploading…' : latest ? 'Upload new version' : 'Upload resume'}
        </label>
      </div>

      {loading ? (
        <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
      ) : !resume ? (
        <p style={{ color: 'var(--color-text-muted)' }}>You haven't uploaded a resume yet.</p>
      ) : (
        <div className="card" style={{ padding: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div>
              <p style={{ fontWeight: 600, fontSize: 15 }}>{latest.fileName}</p>
              <p style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>Version {latest.versionNumber} · uploaded {latest.uploadedAt ? new Date(latest.uploadedAt).toLocaleDateString() : ''}</p>
            </div>
            <StatusBadge status={resume.currentStatus} />
          </div>

          {latest.status && (
            <div style={{ padding: '12px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 13, marginBottom: 16 }}>
              {latest.score != null && <p style={{ fontWeight: 700, marginBottom: 6 }}>Score: {latest.score}/100</p>}
              {latest.suggestions && <p>{latest.suggestions}</p>}
              {latest.reviewedByTrainerName && <p style={{ color: 'var(--color-text-muted)', marginTop: 6 }}>Reviewed by {latest.reviewedByTrainerName}</p>}
            </div>
          )}

          {resume.versions.length > 1 && (
            <div>
              <strong style={{ fontSize: 13 }}>Previous versions</strong>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 8 }}>
                {resume.versions.slice(0, -1).reverse().map((v) => (
                  <div key={v.versionNumber} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 12px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 12 }}>
                    <span>v{v.versionNumber} · {v.fileName}</span>
                    <span>{v.status || 'Not reviewed'}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </AppShell>
  );
}
