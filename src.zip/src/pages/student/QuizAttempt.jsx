import { useEffect, useRef, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Logo from '../../components/Logo';
import { startQuiz, autoSaveQuiz, submitQuiz, reportViolation, getQuizInstructions } from '../../api/studentQuiz';

export default function QuizAttempt() {
  const { id } = useParams();
  const navigate = useNavigate();
  const containerRef = useRef(null);

  const [quiz, setQuiz] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [current, setCurrent] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState(null);
  const [violationCount, setViolationCount] = useState(0);

  const answersRef = useRef(answers);
  answersRef.current = answers;
  const submittedRef = useRef(false);

  useEffect(() => {
    getQuizInstructions(id)
      .then((res) => setQuiz(res.data.data))
      .catch((err) => setError(err.message));

    startQuiz(id)
      .then((res) => {
        setQuestions(res.data.data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });

    containerRef.current?.requestFullscreen?.().catch(() => {});
  }, [id]);

  useEffect(() => {
    if (!quiz) return;
    setSecondsLeft(quiz.durationMinutes * 60);
  }, [quiz]);

  const handleSubmit = useCallback(
    async () => {
      if (submittedRef.current) return;
      submittedRef.current = true;
      setSubmitting(true);
      try {
        const res = await submitQuiz(id, answersRef.current);
        setResult(res.data.data);
      } catch (err) {
        setError(err.message);
        submittedRef.current = false;
      } finally {
        setSubmitting(false);
        if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {});
      }
    },
    [id]
  );

  useEffect(() => {
    if (secondsLeft === null || result) return;
    if (secondsLeft <= 0) {
      handleSubmit();
      return;
    }
    const t = setTimeout(() => setSecondsLeft((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [secondsLeft, result, handleSubmit]);

  useEffect(() => {
    if (result || loading) return;
    const interval = setInterval(() => {
      autoSaveQuiz(id, answersRef.current).catch(() => {});
    }, 15000);
    return () => clearInterval(interval);
  }, [id, result, loading]);

  const logViolation = useCallback(
    (type) => {
      if (submittedRef.current) return;
      reportViolation(id, type).catch(() => {});
      setViolationCount((c) => c + 1);
    },
    [id]
  );

  useEffect(() => {
    if (result) return;
    function onVisibility() {
      if (document.hidden) logViolation('TAB_SWITCH');
    }
    function onFullscreenChange() {
      if (!document.fullscreenElement) logViolation('FULLSCREEN_EXIT');
    }
    function onCopy(e) {
      e.preventDefault();
      logViolation('COPY_ATTEMPT');
    }
    function onPaste(e) {
      e.preventDefault();
      logViolation('PASTE_ATTEMPT');
    }
    function onContextMenu(e) {
      e.preventDefault();
      logViolation('RIGHT_CLICK_ATTEMPT');
    }
    document.addEventListener('visibilitychange', onVisibility);
    document.addEventListener('fullscreenchange', onFullscreenChange);
    document.addEventListener('copy', onCopy);
    document.addEventListener('paste', onPaste);
    document.addEventListener('contextmenu', onContextMenu);
    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      document.removeEventListener('fullscreenchange', onFullscreenChange);
      document.removeEventListener('copy', onCopy);
      document.removeEventListener('paste', onPaste);
      document.removeEventListener('contextmenu', onContextMenu);
    };
  }, [logViolation, result]);

  function setAnswer(qid, values) {
    setAnswers((a) => ({ ...a, [qid]: values }));
  }

  function toggleOption(qid, option, multi) {
    setAnswers((a) => {
      const existing = a[qid] || [];
      if (multi) {
        return { ...a, [qid]: existing.includes(option) ? existing.filter((o) => o !== option) : [...existing, option] };
      }
      return { ...a, [qid]: [option] };
    });
  }

  function formatTime(s) {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${String(sec).padStart(2, '0')}`;
  }

  if (error && !questions.length) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
        <div className="card" style={{ padding: 32, maxWidth: 420, textAlign: 'center' }}>
          <p className="error-text" style={{ marginBottom: 16 }}>{error}</p>
          <button className="btn btn-primary" onClick={() => navigate('/app/student/quizzes')}>Back to quizzes</button>
        </div>
      </div>
    );
  }

  if (result) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20, background: 'var(--color-bg)' }}>
        <div className="card" style={{ padding: 40, maxWidth: 440, textAlign: 'center' }}>
          <Logo size={32} withWordmark={false} />
          <h1 style={{ fontSize: 22, margin: '20px 0 8px' }}>{result.passed ? 'Quiz passed!' : 'Quiz submitted'}</h1>
          <p style={{ fontSize: 40, fontWeight: 800, color: result.passed ? 'var(--color-success)' : 'var(--color-danger)', margin: '10px 0' }}>
            {result.percentage}%
          </p>
          <p style={{ fontSize: 14, color: 'var(--color-text-muted)', marginBottom: 24 }}>
            {result.obtainedMarks}/{result.totalMarks} marks · {result.correctAnswers} correct, {result.wrongAnswers} wrong
            {result.pendingManualGrading > 0 && ` · ${result.pendingManualGrading} pending manual grading`}
          </p>
          <button className="btn btn-primary" onClick={() => navigate('/app/student/quizzes')}>Back to quizzes</button>
        </div>
      </div>
    );
  }

  if (loading || !quiz) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <p style={{ color: 'var(--color-text-muted)' }}>Loading quiz…</p>
      </div>
    );
  }

  const q = questions[current];
  const isMulti = q?.type === 'MULTIPLE_SELECT';
  const isText = q?.type === 'FILL_BLANK' || q?.type === 'SHORT_ANSWER';

  return (
    <div ref={containerRef} style={{ minHeight: '100vh', background: 'var(--color-bg)' }}>
      <header style={{ background: 'var(--color-surface)', borderBottom: '1px solid var(--color-border)', padding: '14px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'sticky', top: 0, zIndex: 10 }}>
        <div>
          <strong style={{ fontSize: 15 }}>{quiz.title}</strong>
          {violationCount > 0 && <span style={{ marginLeft: 12, fontSize: 12, color: 'var(--color-danger)' }}>{violationCount} violation(s) logged</span>}
        </div>
        <span style={{ fontSize: 18, fontWeight: 800, color: secondsLeft < 60 ? 'var(--color-danger)' : 'var(--color-primary)' }}>
          {formatTime(secondsLeft ?? 0)}
        </span>
      </header>

      <div className="container" style={{ padding: '32px 24px', maxWidth: 720 }}>
        <p style={{ fontSize: 13, color: 'var(--color-text-muted)', marginBottom: 8 }}>
          Question {current + 1} of {questions.length} · {q?.marks} mark{q?.marks !== 1 ? 's' : ''}
        </p>
        <div className="card" style={{ padding: 28, marginBottom: 20 }}>
          <p style={{ fontSize: 16, marginBottom: 20 }}>{q?.questionText}</p>

          {isText ? (
            <input
              value={(answers[q.assignmentId] || [''])[0]}
              onChange={(e) => setAnswer(q.assignmentId, [e.target.value])}
              placeholder="Your answer"
              style={{ width: '100%' }}
            />
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {(q?.options || []).map((opt) => {
                const selected = (answers[q.assignmentId] || []).includes(opt);
                return (
                  <label
                    key={opt}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 10,
                      padding: '12px 16px',
                      borderRadius: 'var(--radius-sm)',
                      border: `1.5px solid ${selected ? 'var(--color-accent)' : 'var(--color-border)'}`,
                      background: selected ? 'var(--color-surface-alt)' : 'transparent',
                      cursor: 'pointer',
                    }}
                  >
                    <input type={isMulti ? 'checkbox' : 'radio'} checked={selected} onChange={() => toggleOption(q.assignmentId, opt, isMulti)} />
                    {opt}
                  </label>
                );
              })}
            </div>
          )}
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10 }}>
          <button className="btn btn-ghost" disabled={current === 0} onClick={() => setCurrent((c) => c - 1)}>
            Previous
          </button>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {questions.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: '50%',
                  border: '1.5px solid var(--color-border)',
                  background: i === current ? 'var(--color-primary)' : answers[questions[i].assignmentId] ? 'var(--color-surface-alt)' : 'transparent',
                  color: i === current ? '#fff' : 'var(--color-text)',
                  fontSize: 12,
                  cursor: 'pointer',
                }}
              >
                {i + 1}
              </button>
            ))}
          </div>
          {current < questions.length - 1 ? (
            <button className="btn btn-ghost" onClick={() => setCurrent((c) => c + 1)}>
              Next
            </button>
          ) : (
            <button className="btn btn-primary" onClick={() => handleSubmit()} disabled={submitting}>
              {submitting ? 'Submitting…' : 'Submit quiz'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
