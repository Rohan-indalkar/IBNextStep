import { useEffect, useState } from 'react';
import AppShell from '../../components/AppShell';
import StudentSidebar from '../../components/StudentSidebar';
import Modal from '../../components/Modal';
import { listAvailableMaterials, downloadMaterialFile } from '../../api/studentMaterial';

export default function StudyMaterials() {
  const [materials, setMaterials] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [detail, setDetail] = useState(null);

  useEffect(() => {
    listAvailableMaterials()
      .then((res) => setMaterials(res.data.data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  async function handleDownload(materialId, file) {
    try {
      await downloadMaterialFile(materialId, file.fileId, file.fileName);
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <AppShell roleLabel="Student" sidebar={<StudentSidebar />}>
      <h1 style={{ fontSize: 24, marginBottom: 20 }}>Study materials</h1>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      {loading ? (
        <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
      ) : materials.length === 0 ? (
        <p style={{ color: 'var(--color-text-muted)' }}>Nothing published to your batch yet.</p>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 16 }}>
          {materials.map((m) => (
            <div key={m.id} className="card" style={{ padding: 20, cursor: 'pointer' }} onClick={() => setDetail(m)}>
              <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--color-accent)', textTransform: 'uppercase' }}>{m.contentType?.replace('_', ' ')}</span>
              <h3 style={{ fontSize: 16, margin: '6px 0' }}>{m.title}</h3>
              <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>{m.courseName} {m.topic && `· ${m.topic}`}</p>
            </div>
          ))}
        </div>
      )}

      <Modal open={Boolean(detail)} title={detail?.title || ''} onClose={() => setDetail(null)}>
        {detail && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {detail.description && <p style={{ fontSize: 14, color: 'var(--color-text-muted)' }}>{detail.description}</p>}
            <p style={{ fontSize: 13 }}>{detail.courseName} {detail.module && `· ${detail.module}`} {detail.topic && `· ${detail.topic}`}</p>
            {detail.externalUrl && (
              <a href={detail.externalUrl} target="_blank" rel="noreferrer" className="btn btn-primary" style={{ textAlign: 'center' }}>
                Open link
              </a>
            )}
            {detail.files?.length > 0 && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {detail.files.map((f) => (
                  <button key={f.fileId} className="btn btn-ghost" style={{ justifyContent: 'space-between' }} onClick={() => handleDownload(detail.id, f)}>
                    <span>{f.fileName}</span>
                    <span style={{ fontSize: 11, color: 'var(--color-text-muted)' }}>{Math.round(f.fileSizeBytes / 1024)} KB</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </Modal>
    </AppShell>
  );
}
