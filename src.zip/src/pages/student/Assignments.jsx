import { useEffect, useState } from 'react';
import AppShell from '../../components/AppShell';
import StudentSidebar from '../../components/StudentSidebar';
import Modal from '../../components/Modal';
import { listAvailableAssignments, getAssignmentDetail, submitAssignment, downloadReferenceFile } from '../../api/studentAssignment';

function StatusBadge({ status }) {
  if (!status) return <span style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>Not submitted</span>;
  const colors = { SUBMITTED: 'var(--color-warning)', LATE: 'var(--color-danger)', GRADED: 'var(--color-success)' };
  return <span style={{ fontSize: 12, fontWeight: 700, padding: '3px 10px', borderRadius: 999, color: '#fff', background: colors[status] || '#888' }}>{status}</span>;
}

export default function Assignments() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [detail, setDetail] = useState(null);
  const [answers, setAnswers] = useState({});
  const [files, setFiles] = useState([]);
  const [saving, setSaving] = useState(false);

  function load() {
    setLoading(true);
    listAvailableAssignments()
      .then((res) => setItems(res.data.data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  function openDetail(item) {
    setError('');
    getAssignmentDetail(item.assignmentId)
      .then((res) => {
        setDetail(res.data.data);
        const initial = {};
        (res.data.data.questions || []).forEach((q) => {
          initial[q.id] = res.data.data.mySubmission?.answers?.find((a) => a.questionId === q.id)?.textAnswer || '';
        });
        setAnswers(initial);
        setFiles([]);
      })
      .catch((err) => setError(err.message));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      const payload = {
        answers: detail.questions.map((q) => ({ questionId: q.id, textAnswer: answers[q.id] || '' })),
      };
      await submitAssignment(detail.assignmentId, payload, files);
      setDetail(null);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleDownloadRef(file) {
    try {
      await downloadReferenceFile(detail.assignmentId, file.fileId, file.fileName);
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <AppShell roleLabel="Student" sidebar={<StudentSidebar />}>
      <h1 style={{ fontSize: 24, marginBottom: 20 }}>Assignments</h1>

      {error && <p className="error-text" style={{ marginBottom: 12 }}>{error}</p>}

      {loading ? (
        <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
      ) : items.length === 0 ? (
        <p style={{ color: 'var(--color-text-muted)' }}>No assignments yet.</p>
      ) : (
        <div className="card" style={{ overflow: 'hidden' }}>
          {items.map((a) => (
            <div key={a.assignmentId} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 18px', borderBottom: '1px solid var(--color-border)' }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14 }}>{a.title}</div>
                <div style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>
                  {a.courseName} · {a.questionCount} questions {a.dueDate && `· due ${new Date(a.dueDate).toLocaleDateString()}`}
                  {a.rating != null && ` · rated ${a.rating}/5`}
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <StatusBadge status={a.submissionStatus} />
                <button className="btn btn-ghost" style={{ padding: '6px 14px', fontSize: 12 }} onClick={() => openDetail(a)}>
                  {a.submissionStatus ? 'View' : 'Open'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={Boolean(detail)} title={detail?.title || ''} onClose={() => setDetail(null)}>
        {detail && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {detail.description && <p style={{ fontSize: 14, color: 'var(--color-text-muted)' }}>{detail.description}</p>}

            {detail.referenceFiles?.length > 0 && (
              <div>
                <strong style={{ fontSize: 13 }}>Reference files</strong>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 6 }}>
                  {detail.referenceFiles.map((f) => (
                    <button key={f.fileId} className="btn btn-ghost" style={{ justifyContent: 'space-between', padding: '6px 12px', fontSize: 12 }} onClick={() => handleDownloadRef(f)}>
                      {f.fileName}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {detail.mySubmission ? (
              <div style={{ padding: '12px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 13 }}>
                <p style={{ fontWeight: 700, marginBottom: 6 }}>Your submission — {detail.mySubmission.status}</p>
                {detail.mySubmission.answers.map((a, i) => (
                  <p key={i} style={{ marginBottom: 4 }}>{a.textAnswer}</p>
                ))}
                {detail.mySubmission.rating != null && <p style={{ marginTop: 8, color: 'var(--color-success)', fontWeight: 700 }}>Rated {detail.mySubmission.rating}/5</p>}
                {detail.mySubmission.feedback && <p style={{ marginTop: 4 }}><strong>Feedback:</strong> {detail.mySubmission.feedback}</p>}
              </div>
            ) : (
              <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                {detail.questions.map((q) => (
                  <div key={q.id} className="field">
                    <label htmlFor={`q-${q.id}`}>{q.questionText}</label>
                    <textarea
                      id={`q-${q.id}`}
                      rows={3}
                      value={answers[q.id] || ''}
                      onChange={(e) => setAnswers((a) => ({ ...a, [q.id]: e.target.value }))}
                      style={{ fontFamily: 'var(--font-body)', fontSize: 14, padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--color-border)', resize: 'vertical' }}
                    />
                  </div>
                ))}
                <div className="field">
                  <label htmlFor="submitFiles">Attach file(s) (optional)</label>
                  <input id="submitFiles" type="file" multiple onChange={(e) => setFiles(Array.from(e.target.files || []))} />
                </div>
                <button className="btn btn-primary" type="submit" disabled={saving}>
                  {saving ? 'Submitting…' : 'Submit assignment'}
                </button>
              </form>
            )}
          </div>
        )}
      </Modal>
    </AppShell>
  );
}
