import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import AppShell from '../../components/AppShell';
import StudentSidebar from '../../components/StudentSidebar';
import StatCard from '../../components/StatCard';
import { getStudentPlacementDashboard } from '../../api/studentDashboard';

export default function StudentDashboard() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getStudentPlacementDashboard()
      .then((res) => setData(res.data.data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <AppShell roleLabel="Student" sidebar={<StudentSidebar />}>
      <h1 style={{ fontSize: 24, marginBottom: 24 }}>My dashboard</h1>

      {error && <p className="error-text" style={{ marginBottom: 16 }}>{error}</p>}

      {loading ? (
        <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
      ) : data ? (
        <>
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 32 }}>
            <StatCard label="Applications" value={data.appliedCount} />
            <StatCard label="Selected" value={data.selectedCount} accent />
            <StatCard label="Rejected" value={data.rejectedCount} />
            <StatCard label="Open campus drives" value={data.campusOpenCount} />
            <StatCard label="Open off-campus drives" value={data.offCampusOpenCount} />
          </div>

          {data.upcomingInterviews?.length > 0 && (
            <div className="card" style={{ padding: 24, marginBottom: 24 }}>
              <h2 style={{ fontSize: 16, marginBottom: 14 }}>Upcoming interviews</h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {data.upcomingInterviews.map((i, idx) => (
                  <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 13 }}>
                    <span>{i.companyName} — {i.roundType} (Round {i.roundNumber})</span>
                    <span style={{ color: 'var(--color-text-muted)' }}>{i.scheduledAt ? new Date(i.scheduledAt).toLocaleString() : '—'}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {data.interviewHistory?.length > 0 && (
            <div className="card" style={{ padding: 24, marginBottom: 24 }}>
              <h2 style={{ fontSize: 16, marginBottom: 14 }}>Interview history</h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {data.interviewHistory.map((i, idx) => (
                  <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 14px', background: 'var(--color-surface-alt)', borderRadius: 'var(--radius-sm)', fontSize: 13 }}>
                    <span>{i.companyName} — {i.roundType}</span>
                    <span style={{ color: i.result === 'QUALIFIED' ? 'var(--color-success)' : 'var(--color-text-muted)' }}>{i.result}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      ) : null}

      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        <Link to="/app/student/placements" className="btn btn-primary">Browse placements</Link>
        <Link to="/app/student/assignments" className="btn btn-ghost">Assignments</Link>
        <Link to="/app/student/quizzes" className="btn btn-ghost">Quizzes</Link>
      </div>
    </AppShell>
  );
}
