import AppShell from '../../components/AppShell';

const LABELS = {
  ADMIN: 'Administrator',
  HR: 'HR / Recruiter',
  TRAINER: 'Trainer',
  STUDENT: 'Student',
};

export default function RoleDashboard({ role }) {
  return (
    <AppShell roleLabel={LABELS[role] || role}>
      <div className="card" style={{ padding: 40, textAlign: 'center' }}>
        <h2 style={{ fontSize: 22, marginBottom: 10 }}>You're in — {LABELS[role]} dashboard</h2>
        <p style={{ color: 'var(--color-text-muted)', maxWidth: 480, margin: '0 auto' }}>
          Authentication is fully wired to the real backend. This is where the {LABELS[role]?.toLowerCase()}
          {' '}modules (courses, batches, attendance, placements, and the rest) get built next.
        </p>
      </div>
    </AppShell>
  );
}
