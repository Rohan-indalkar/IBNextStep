import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Logo from '../components/Logo';

const pillars = [
  {
    title: 'Structured Learning',
    body: 'Batches, courses and study material organised the way a real training program runs — not a generic LMS.',
    glyph: '📘',
  },
  {
    title: 'Practice That Counts',
    body: 'Coding assessments, quizzes and mock interviews with instant, AI-assisted feedback before it matters.',
    glyph: '🧠',
  },
  {
    title: 'A Real Next Step',
    body: 'Attendance, evaluations and resume readiness roll up into one placement pipeline — through to the offer.',
    glyph: '🎯',
  },
];

const roles = [
  { title: 'Students', body: 'Learn, practice, get evaluated, and apply to placement drives — all in one place.' },
  { title: 'Trainers', body: 'Run the classroom: materials, attendance, assignments, quizzes, and evaluations.' },
  { title: 'HR', body: 'Post drives, manage companies, and move candidates through the interview pipeline.' },
  { title: 'Admins', body: 'Set up departments, batches and courses, and keep the whole program running.' },
];

export default function Home() {
  const navigate = useNavigate();

  return (
    <div style={{ background: 'var(--color-bg)', minHeight: '100vh' }}>
      <header style={{ borderBottom: '1px solid var(--color-border)', background: 'var(--color-surface)', position: 'sticky', top: 0, zIndex: 20 }}>
        <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 76 }}>
          <Logo size={36} />
          <button className="btn btn-ghost" onClick={() => navigate('/auth/login')}>
            Log in
          </button>
        </div>
      </header>

      {/* Hero — editorial two-column composition, InfoBeans-Foundation-inspired warmth and whitespace */}
      <section style={{ padding: '72px 0' }}>
        <div className="container home-hero-grid">
          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}>
            <span
              style={{
                display: 'inline-block', padding: '6px 16px', borderRadius: 999, background: 'var(--color-surface-alt)',
                color: 'var(--color-primary)', fontSize: 13, fontWeight: 600, marginBottom: 24,
              }}
            >
              InfoBeans Foundation · Training &amp; Placement Platform
            </span>
            <h1 style={{ fontSize: 'clamp(32px, 5vw, 50px)', lineHeight: 1.1, marginBottom: 20 }}>
              From first class to <span style={{ color: 'var(--color-accent)' }}>offer letter</span> — one platform.
            </h1>
            <p style={{ fontSize: 17, color: 'var(--color-text-muted)', marginBottom: 32, maxWidth: 480 }}>
              IBNextStep carries a trainee through the full journey — coursework, practice, evaluation, and
              placement — as one connected program instead of scattered tools.
            </p>
            <div style={{ display: 'flex', gap: 14 }}>
              <button className="btn btn-primary" style={{ padding: '14px 30px', fontSize: 16 }} onClick={() => navigate('/auth/login')}>
                Get started →
              </button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            aria-hidden="true"
            className="home-hero-art"
          >
            <svg viewBox="0 0 420 420" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
              <circle cx="210" cy="210" r="200" fill="var(--color-surface-alt)" />
              <circle cx="210" cy="210" r="150" fill="none" stroke="var(--color-border)" strokeWidth="1.5" strokeDasharray="4 8" />
              <rect x="110" y="100" width="200" height="130" rx="18" fill="var(--color-surface)" stroke="var(--color-border)" strokeWidth="1.5" />
              <rect x="130" y="122" width="120" height="10" rx="5" fill="var(--color-border)" />
              <rect x="130" y="144" width="160" height="10" rx="5" fill="var(--color-border)" />
              <rect x="130" y="166" width="90" height="10" rx="5" fill="var(--color-accent)" opacity="0.5" />
              <circle cx="150" cy="270" r="34" fill="var(--color-primary)" />
              <path d="M138 270l8 8 16-16" stroke="var(--color-text-inverse)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" fill="none" />
              <rect x="210" y="245" width="110" height="50" rx="14" fill="var(--color-accent)" opacity="0.14" />
              <text x="265" y="276" textAnchor="middle" fontFamily="Sora, sans-serif" fontWeight="700" fontSize="15" fill="var(--color-accent)">
                Next Step
              </text>
            </svg>
          </motion.div>
        </div>
      </section>

      {/* Pillars */}
      <section style={{ padding: '20px 0 90px' }}>
        <div className="container">
          <h2 style={{ textAlign: 'center', fontSize: 28, marginBottom: 44 }}>Built around three commitments</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 24 }}>
            {pillars.map((p, i) => (
              <motion.div
                key={p.title}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.5 }}
                className="card"
                style={{ padding: 32 }}
              >
                <div style={{ fontSize: 28, marginBottom: 16 }} aria-hidden="true">{p.glyph}</div>
                <h3 style={{ fontSize: 18, marginBottom: 10 }}>{p.title}</h3>
                <p style={{ color: 'var(--color-text-muted)', fontSize: 14 }}>{p.body}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Who it's for */}
      <section style={{ padding: '0 0 100px' }}>
        <div className="container">
          <h2 style={{ textAlign: 'center', fontSize: 28, marginBottom: 44 }}>One platform, four roles</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 20 }}>
            {roles.map((r, i) => (
              <motion.div
                key={r.title}
                initial={{ opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08, duration: 0.45 }}
                style={{ padding: '4px 0', borderLeft: '3px solid var(--color-accent)', paddingLeft: 18 }}
              >
                <h3 style={{ fontSize: 16, marginBottom: 6 }}>{r.title}</h3>
                <p style={{ color: 'var(--color-text-muted)', fontSize: 13.5 }}>{r.body}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <footer style={{ borderTop: '1px solid var(--color-border)', padding: '28px 0' }}>
        <div className="container" style={{ textAlign: 'center', color: 'var(--color-text-muted)', fontSize: 13 }}>
          © {new Date().getFullYear()} IBNextStep · InfoBeans Foundation
        </div>
      </footer>
    </div>
  );
}
